      program main
      implicit none
      integer,parameter::ndata=1,natom=5
      real*8 xct(3,5)
      real*8 v0,v,rmse
      integer i,j,k,x
      character symb
      
      rmse=0d0
      open(8,file='coh2o-test.xyz')
      call pes_init

!===> calculate the total root mean square error(RMSE)
      do i=1,ndata
       read(8,*)
       read(8,*)v0
       do j=1,natom
        read(8,*)symb,xct(:,j)
       enddo  
       call evvdvdx(xct,v)
       rmse=rmse+(v-v0)**2
      enddo

      rmse=dsqrt(rmse/ndata)*1000d0   !==>to meV
      
      write(*,'(a6,f6.3,a3)')'RMSE=',rmse, 'meV'
      write(*,*)' done*******'
      end program main
