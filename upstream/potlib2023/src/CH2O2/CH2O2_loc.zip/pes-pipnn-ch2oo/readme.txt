!********************************************************************** 
!   System:                     CH2O2
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                CH2O2 (local)
!   Number of derivatives:      0
!   Number of bodies:           5
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: see below
!
!   Notes: see below
!
!**********************************************************************

1. what is it?
This code is to get the potential energy for some cartesian coordinate ct(3,5), 
in the order HHOOC, angstrom. Currently it is only for the local minimum around
the Criegee intermediate. See details in our papers:

“High-level, first-principles, full-dimensional quantum calculation of the 
ro-vibrational spectrum of the simplest Criegee intermediate (CH2OO)”, 
Jun Li, Stuart Carter, Joel M. Bowman, Richard Dawes, Daiqian Xie, and Hua Guo*, 
Journal of Physical Chemistry Letters, 2014, 5, 2364-2369

“Infrared spectrum of the simplest Criegee intermediate CH2OO at resolution 
0.25 cm-1 and new assignments of bands 2ν9 and ν5”, 
Yu-Hsuan Huang, Jun Li*, Hua Guo, and Yuan-Pern Lee*, 
Journal of Chemical Physics, 2015, 142, 214301.

“Vibrational energy levels of the simplest Criegee intermediate (CH2OO) 
from full-dimensional Lanczos, MCTDH, and MULTIMODE calculations”, 
Hua-Gen Yu*, Steve Ndengue, Jun Li, Richard Dawes*, and Hua Guo*, 
Journal of Chemical Physics, 2015, 143, 084311.

“Ro-vibrational Spectra of the Simplest Deuterated Criegee Intermediate CD2OO”, 
Jun Li*, 
Chinese Journal of Chemical Physics, 2020, 33, 65-68

2. what are included?
It includes the following files:
1) readme.txt: this file
2) ch2oo-pipnn.f and main.f: two fortran files, one example was given in main.f
   to get the potential energy of some CH2OO configuration;
3) weights.txt and biases.txt: two files for parameters used in the PES;
4) test.xyz and test.xyz-err: two files for the input geomtries and results.

3. how to use it?
just 
pgf90 *.f 
to get the executive file: a.out, and then
./a.out 
to test the example. Note that the initialization of the PES was called once and 
only once in the main code, as shown in the example main.f file.

4. contact:
hguo@unm.edu
Prof. H. Guo
Department of Chemistry and Chemical Biology
University of New Mexico
Albuquerque, NM 87131
Phone: 505 2771716
Fax: 505 2772609
www.unm.edu/~hguo

Professor, Jun Li
School of Chemistry and Chemical Engineering, Chongqing University
No.55 Daxuecheng South Rd., Shapingba, Chongqing, 401331, China
Email: jli15@cqu.edu.cn
ResearchGate: https://www.researchgate.net/profile/Jun_Li51


