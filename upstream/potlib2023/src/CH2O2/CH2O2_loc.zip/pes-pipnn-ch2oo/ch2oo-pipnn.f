!-->  program to get potential energy for a given geometry after NN fitting
!-->  global variables are declared in this module
       module nnparam
       implicit none
       real*8,parameter::alpha=1.0d0,PI=3.1415926d0,radian=PI/180.0d0
       integer,parameter::nbasis=102,ndim=10,natom=5
       real*8,parameter::vpesmin=-189.39622611d0
       integer ninput,noutput,nhid,nlayer,ifunc,nwe,nodemax
       integer nscale
       integer, allocatable::nodes(:)

       real*8, allocatable::weighta(:,:,:),biasa(:,:)
       real*8, allocatable::pdela(:),pavga(:)
       real*8, allocatable::weightb(:,:,:),biasb(:,:)
       real*8, allocatable::pdelb(:),pavgb(:)
       real*8, allocatable::weightc(:,:,:),biasc(:,:)
       real*8, allocatable::pdelc(:),pavgc(:)

       end module nnparam

       subroutine ch2oopipNN(ct,vpes,vpesa,vpesb,vpesc) !ct in HHOOC order and angstrom
       use nnparam
       implicit none
       integer i,j,k,lpes
       real*8 rb(ndim),xbond(ndim),basis(nbasis),tmp1,txinput(nbasis-1)
       real*8 ct(3,natom),xvec(3,ndim),cx(3,natom),cy(3,natom)
       real*8 vpes,vpesa,vpesb,vpesc,vpesH,vnn

       basis=0.d0

       cx=ct

       k=0
       do i=1,natom-1
        do j=i+1,natom
         k=k+1
!        write(*,*)k,i,j
         xvec(:,k)=cx(:,i)-cx(:,j)
        enddo
       enddo
       if(k.ne.10)stop 'error in bond dimension'
       do i=1,ndim
        rb(i)=dsqrt(dot_product(xvec(:,i),xvec(:,i)))
       enddo

       xbond(:)=dexp(-rb(:)/alpha)
       call bemsav(xbond,basis)

       do j=1,nbasis-1
        txinput(j)=basis(j+1)
       enddo

       call getpota(txinput,vpesa)
       call getpotb(txinput,vpesb)
       call getpotc(txinput,vpesc)
       vnn=(vpesa+vpesb+vpesc)/3.0d0

       vpes=min(vnn,6.0d0)
       return

       end subroutine ch2oopipNN

!-->  read NN weights and biases from matlab output
!-->  weights saved in 'weights.txt'
!-->  biases saved in 'biases.txt'
!-->  one has to call this subroutine one and only one before calling the getpot() subroutine
      subroutine pes_init
      use nnparam
      implicit none
      integer i,ihid,iwe,inode1,inode2,ilay1,ilay2
      integer ibasis,npd,iterm,ib,nfile
      character f1*80,line*80

      open(4,file='biases.txt',status='old')
      read(4,'(a80)')line
      write(*,*)line

        nfile=7
        open(nfile,file='weights.txt')
        read(nfile,'(a80)')line
      write(*,*)line
        read(nfile,*)ninput,nhid,noutput
        nscale=ninput+noutput
        nlayer=nhid+2 !additional one for input layer and one for output 
        allocate(nodes(nlayer),pdela(nscale),pavga(nscale))
        nodes(1)=ninput
        nodes(nlayer)=noutput
        read(nfile,*)(nodes(ihid),ihid=2,nhid+1)
        nodemax=0
        do i=1,nlayer
         nodemax=max(nodemax,nodes(i))
        enddo
        allocate(weighta(nodemax,nodemax,2:nlayer),
     %   biasa(nodemax,2:nlayer))
        read(nfile,*)ifunc,nwe
!-->....ifunc hence controls the type of transfer function used for hidden layers
!-->....At this time, only an equivalent transfer function can be used for all hidden layers
!-->....and the pure linear function is always applid to the output layer.
!-->....see function tranfun() for details
        read(nfile,*)(pdela(i),i=1,nscale)
        read(nfile,*)(pavga(i),i=1,nscale)
        iwe=0
        do ilay1=2,nlayer
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        do inode2=1,nodes(ilay2) !
        read(nfile,*)weighta(inode2,inode1,ilay1)
        iwe=iwe+1
        enddo
        read(4,*)biasa(inode1,ilay1)
        iwe=iwe+1
        enddo
        enddo
        
        if (iwe.ne.nwe) then
           write(*,*)'provided number of parameters ',nwe
           write(*,*)'actual number of parameters ',iwe
           write(*,*)'nwe not equal to iwe, check input files or code'
           stop
        endif

        read(4,'(a80)')line
        write(*,*)line
        read(nfile,'(a80)')line
        write(*,*)line
        read(nfile,*)ninput,nhid,noutput
        nscale=ninput+noutput
        nlayer=nhid+2 !additional one for input layer and one for output 
        allocate(pdelb(nscale),pavgb(nscale))
        nodes(1)=ninput
        nodes(nlayer)=noutput
        read(nfile,*)(nodes(ihid),ihid=2,nhid+1)
        nodemax=0
        do i=1,nlayer
         nodemax=max(nodemax,nodes(i))
        enddo
        allocate(weightb(nodemax,nodemax,2:nlayer),
     %   biasb(nodemax,2:nlayer))
        read(nfile,*)ifunc,nwe
!-->....ifunc hence controls the type of transfer function used for hidden layers
!-->....At this time, only an equivalent transfer function can be used for all hidden layers
!-->....and the pure linear function is always applid to the output layer.
!-->....see function tranfun() for details
        read(nfile,*)(pdelb(i),i=1,nscale)
        read(nfile,*)(pavgb(i),i=1,nscale)
        iwe=0
        do ilay1=2,nlayer
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        do inode2=1,nodes(ilay2) !
        read(nfile,*)weightb(inode2,inode1,ilay1)
        iwe=iwe+1
        enddo
        read(4,*)biasb(inode1,ilay1)
        iwe=iwe+1
        enddo
        enddo
        
        if (iwe.ne.nwe) then
           write(*,*)'provided number of parameters ',nwe
           write(*,*)'actual number of parameters ',iwe
           write(*,*)'nwe not equal to iwe, check input files or code'
           stop
        endif


        read(4,'(a80)')line
      write(*,*)line
        read(nfile,'(a80)')line
      write(*,*)line
        read(nfile,*)ninput,nhid,noutput
        nscale=ninput+noutput
        nlayer=nhid+2 !additional one for input layer and one for output 
        allocate(pdelc(nscale),pavgc(nscale))
        nodes(1)=ninput
        nodes(nlayer)=noutput
        read(nfile,*)(nodes(ihid),ihid=2,nhid+1)
        nodemax=0
        do i=1,nlayer
         nodemax=max(nodemax,nodes(i))
        enddo
        allocate(weightc(nodemax,nodemax,2:nlayer),
     % biasc(nodemax,2:nlayer))
        read(nfile,*)ifunc,nwe
!-->....ifunc hence controls the type of transfer function used for hidden layers
!-->....At this time, only an equivalent transfer function can be used for all hidden layers
!-->....and the pure linear function is always applid to the output layer.
!-->....see function tranfun() for details
        read(nfile,*)(pdelc(i),i=1,nscale)
        read(nfile,*)(pavgc(i),i=1,nscale)
        iwe=0
        do ilay1=2,nlayer
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        do inode2=1,nodes(ilay2) !
        read(nfile,*)weightc(inode2,inode1,ilay1)
        iwe=iwe+1
        enddo
        read(4,*)biasc(inode1,ilay1)
        iwe=iwe+1
        enddo
        enddo
        
        if (iwe.ne.nwe) then
           write(*,*)'provided number of parameters ',nwe
           write(*,*)'actual number of parameters ',iwe
           write(*,*)'nwe not equal to iwe, check input files or code'
           stop
        endif
        close(nfile)
        close(4)

        return
        end 

        subroutine getpota(x,vpot)
        use nnparam
        implicit none
        integer i,inode1,inode2,ilay1,ilay2
        real*8 x(ninput),y(nodemax,nlayer),vpot
        real*8, external :: tranfun
!-->....set up the normalized input layer
c       write(*,*)ninput
        do i=1,ninput
          y(i,1)=(x(i)-pavga(i))/pdela(i)
        enddo

!-->....evaluate the hidden layer
        do ilay1=2,nlayer-1
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        y(inode1,ilay1)=biasa(inode1,ilay1)
        do inode2=1,nodes(ilay2)
        y(inode1,ilay1)=y(inode1,ilay1)+y(inode2,ilay2)
     &*weighta(inode2,inode1,ilay1)
        enddo
        y(inode1,ilay1)=tranfun(y(inode1,ilay1),ifunc)
        enddo
        enddo

!-->....now evaluate the output
        ilay1=nlayer
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        y(inode1,ilay1)=biasa(inode1,ilay1)
        do inode2=1,nodes(ilay2)
        y(inode1,ilay1)=y(inode1,ilay1)+y(inode2,ilay2)
     &*weighta(inode2,inode1,ilay1)
        enddo
!-->....the transfer function is linear y=x for output layer
!-->....so no operation is needed here
        enddo

!-->....the value of output layer is the fitted potntial 
        vpot=y(nodes(nlayer),nlayer)*pdela(nscale)+pavga(nscale)
        return
        end subroutine getpota

        subroutine getpotb(x,vpot)
        use nnparam
        implicit none
        integer i,inode1,inode2,ilay1,ilay2
        real*8 x(ninput),y(nodemax,nlayer),vpot
        real*8, external :: tranfun
!-->....set up the normalized input layer
c       write(*,*)ninput
        do i=1,ninput
          y(i,1)=(x(i)-pavgb(i))/pdelb(i)
        enddo

!-->....evaluate the hidden layer
        do ilay1=2,nlayer-1
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        y(inode1,ilay1)=biasb(inode1,ilay1)
        do inode2=1,nodes(ilay2)
        y(inode1,ilay1)=y(inode1,ilay1)+y(inode2,ilay2)
     &*weightb(inode2,inode1,ilay1)
        enddo
        y(inode1,ilay1)=tranfun(y(inode1,ilay1),ifunc)
        enddo
        enddo

!-->....now evaluate the output
        ilay1=nlayer
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        y(inode1,ilay1)=biasb(inode1,ilay1)
        do inode2=1,nodes(ilay2)
        y(inode1,ilay1)=y(inode1,ilay1)+y(inode2,ilay2)
     &*weightb(inode2,inode1,ilay1)
        enddo
!-->....the transfer function is linear y=x for output layer
!-->....so no operation is needed here
        enddo

!-->....the value of output layer is the fitted potntial 
        vpot=y(nodes(nlayer),nlayer)*pdelb(nscale)+pavgb(nscale)
        return
        end subroutine getpotb

        subroutine getpotc(x,vpot)
        use nnparam
        implicit none
        integer i,inode1,inode2,ilay1,ilay2
        real*8 x(ninput),y(nodemax,nlayer),vpot
        real*8, external :: tranfun
!-->....set up the normalized input layer
!       write(*,*)ninput
        do i=1,ninput
          y(i,1)=(x(i)-pavgc(i))/pdelc(i)
        enddo

!-->....evaluate the hidden layer
        do ilay1=2,nlayer-1
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        y(inode1,ilay1)=biasc(inode1,ilay1)
        do inode2=1,nodes(ilay2)
        y(inode1,ilay1)=y(inode1,ilay1)+y(inode2,ilay2)
     &*weightc(inode2,inode1,ilay1)
        enddo
        y(inode1,ilay1)=tranfun(y(inode1,ilay1),ifunc)
        enddo
        enddo

!-->....now evaluate the output
        ilay1=nlayer
        ilay2=ilay1-1
        do inode1=1,nodes(ilay1)
        y(inode1,ilay1)=biasc(inode1,ilay1)
        do inode2=1,nodes(ilay2)
        y(inode1,ilay1)=y(inode1,ilay1)+y(inode2,ilay2)
     &*weightc(inode2,inode1,ilay1)
        enddo
!-->....the transfer function is linear y=x for output layer
!-->....so no operation is needed here
        enddo

!-->....the value of output layer is the fitted potntial 
        vpot=y(nodes(nlayer),nlayer)*pdelc(nscale)+pavgc(nscale)
        return
        end subroutine getpotc

        function tranfun(x,ifunc)
        implicit none
        integer ifunc
        real*8 tranfun,x
c    ifunc=1, transfer function is hyperbolic tangent function, 'tansig'
c    ifunc=2, transfer function is log sigmoid function, 'logsig'
c    ifunc=3, transfer function is pure linear function, 'purelin'. It is imposed to the output layer by default
        if (ifunc.eq.1) then
        tranfun=dtanh(x)
        else if (ifunc.eq.2) then
        tranfun=1d0/(1d0+exp(-x))
        else if (ifunc.eq.3) then
        tranfun=x
        endif
        return
        end
!-->!-->!-->!-->!-->!-->!-->!-->!-->!-->subroutine to accelerate~~~~~~
      function emsav(x,c) result(v)
      implicit none
      real*8,dimension(1:10)::x
      real*8,dimension(0:101)::c
      real*8::v
      ! ::::::::::::::::::::
      real*8,dimension(0:101)::p
      call bemsav(x,p)
      v = dot_product(p,c)
      return
      end function emsav

      subroutine bemsav(x,p)
      implicit none
      real*8,dimension(1:10),intent(in)::x
      real*8,dimension(0:101),intent(out)::p
      ! ::::::::::::::::::::
      real*8,dimension(0:38)::m
      call evmono(x,m)
      call evpoly(m,p)
      return
      end subroutine bemsav

      subroutine evmono(x,m)
      implicit none
      real*8,dimension(1:10),intent(in)::x
      real*8,dimension(0:38),intent(out)::m

      m(0)=1.D0
      m(1)=x(10)
      m(2)=x(9)
      m(3)=x(8)
      m(4)=x(7)
      m(5)=x(4)
      m(6)=x(6)
      m(7)=x(5)
      m(8)=x(3)
      m(9)=x(2)
      m(10)=x(1)
      m(11)=m(1)*m(2)
      m(12)=m(4)*m(5)
      m(13)=m(2)*m(6)
      m(14)=m(1)*m(7)
      m(15)=m(2)*m(8)
      m(16)=m(1)*m(9)
      m(17)=m(5)*m(6)
      m(18)=m(5)*m(7)
      m(19)=m(4)*m(8)
      m(20)=m(4)*m(9)
      m(21)=m(7)*m(8)
      m(22)=m(6)*m(9)
      m(23)=m(6)*m(8)
      m(24)=m(7)*m(9)
      m(25)=m(6)*m(7)
      m(26)=m(8)*m(9)
      m(27)=m(2)*m(17)
      m(28)=m(1)*m(18)
      m(29)=m(2)*m(19)
      m(30)=m(1)*m(20)
      m(31)=m(2)*m(23)
      m(32)=m(1)*m(24)
      m(33)=m(5)*m(25)
      m(34)=m(4)*m(26)
      m(35)=m(6)*m(21)
      m(36)=m(6)*m(24)
      m(37)=m(6)*m(26)
      m(38)=m(7)*m(26)

      return
      end subroutine evmono

      subroutine evpoly(m,p)
      implicit none
      real*8,dimension(0:38),intent(in)::m
      real*8,dimension(0:101),intent(out)::p

      p(0)=m(0)
      p(1)=m(1)+m(2)
      p(2)=m(3)
      p(3)=m(4)+m(5)
      p(4)=m(6)+m(7)+m(8)+m(9)
      p(5)=m(10)
      p(6)=m(11)
      p(7)=p(2)*p(1)
      p(8)=p(1)*p(3)
      p(9)=p(2)*p(3)
      p(10)=m(12)
      p(11)=m(13)+m(14)+m(15)+m(16)
      p(12)=p(1)*p(4)-p(11)
      p(13)=p(2)*p(4)
      p(14)=m(17)+m(18)+m(19)+m(20)
      p(15)=m(21)+m(22)
      p(16)=m(23)+m(24)
      p(17)=p(3)*p(4)-p(14)
      p(18)=m(25)+m(26)
      p(19)=p(5)*p(1)
      p(20)=p(2)*p(5)
      p(21)=p(5)*p(3)
      p(22)=p(5)*p(4)
      p(23)=p(1)*p(1)-p(6)-p(6)
      p(24)=p(2)*p(2)
      p(25)=p(3)*p(3)-p(10)-p(10)
      p(26)=p(4)*p(4)-p(18)-p(16)-p(15)-p(18)-p(16)-p(15)
      p(27)=p(5)*p(5)
      p(28)=p(2)*p(6)
      p(29)=p(6)*p(3)
      p(30)=p(2)*p(8)
      p(31)=p(10)*p(1)
      p(32)=p(2)*p(10)
      p(33)=p(6)*p(4)
      p(34)=p(2)*p(11)
      p(35)=p(2)*p(12)
      p(36)=m(27)+m(28)+m(29)+m(30)
      p(37)=p(1)*p(14)-p(36)
      p(38)=p(2)*p(14)
      p(39)=p(1)*p(15)
      p(40)=p(2)*p(15)
      p(41)=m(31)+m(32)
      p(42)=p(1)*p(16)-p(41)
      p(43)=p(2)*p(16)
      p(44)=p(3)*p(11)-p(36)
      p(45)=p(1)*p(17)-p(44)
      p(46)=p(2)*p(17)
      p(47)=p(10)*p(4)
      p(48)=p(3)*p(15)
      p(49)=p(3)*p(16)
      p(50)=p(1)*p(18)
      p(51)=p(2)*p(18)
      p(52)=m(33)+m(34)
      p(53)=m(35)+m(36)+m(37)+m(38)
      p(54)=p(3)*p(18)-p(52)
      p(55)=p(5)*p(6)
      p(56)=p(2)*p(19)
      p(57)=p(5)*p(8)
      p(58)=p(2)*p(21)
      p(59)=p(5)*p(10)
      p(60)=p(5)*p(11)
      p(61)=p(5)*p(12)
      p(62)=p(2)*p(22)
      p(63)=p(5)*p(14)
      p(64)=p(5)*p(15)
      p(65)=p(5)*p(16)
      p(66)=p(5)*p(17)
      p(67)=p(5)*p(18)
      p(68)=p(6)*p(1)
      p(69)=p(2)*p(23)
      p(70)=p(2)*p(7)
      p(71)=p(3)*p(23)
      p(72)=p(2)*p(9)
      p(73)=p(1)*p(25)
      p(74)=p(2)*p(25)
      p(75)=p(10)*p(3)
      p(76)=p(1)*p(11)-p(33)
      p(77)=p(1)*p(12)-p(33)
      p(78)=p(2)*p(13)
      p(79)=p(3)*p(14)-p(47)
      p(80)=p(3)*p(17)-p(47)
      p(81)=p(4)*p(11)-p(50)-p(41)-p(39)-p(41)
      p(82)=p(1)*p(26)-p(81)
      p(83)=p(2)*p(26)
      p(84)=p(4)*p(14)-p(52)-p(49)-p(48)-p(52)
      p(85)=p(4)*p(15)-p(53)
      p(86)=p(4)*p(16)-p(53)
      p(87)=p(3)*p(26)-p(84)
      p(88)=p(4)*p(18)-p(53)
      p(89)=p(5)*p(23)
      p(90)=p(2)*p(20)
      p(91)=p(5)*p(25)
      p(92)=p(5)*p(26)
      p(93)=p(5)*p(19)
      p(94)=p(2)*p(27)
      p(95)=p(5)*p(21)
      p(96)=p(5)*p(22)
      p(97)=p(1)*p(23)-p(68)
      p(98)=p(2)*p(24)
      p(99)=p(3)*p(25)-p(75)
      p(100)=p(4)*p(26)-p(88)-p(86)-p(85)
      p(101)=p(5)*p(27)

      return
      end subroutine evpoly
