
      program main
      implicit none
      real*8 ct(3,5),vpes,vab,v1,v2,v3
      real*8 rmse,maxerr
      integer i,j,ndata,nsmall
      character*8 asymb
 
      ndata=2
      maxerr=-1d0
      call pes_init

      rmse=0d0
      open(3,file='test.xyz')
      open(6,file='test.xyz-err')
      nsmall=0
      do i=1,ndata
        read(3,*)j
        read(3,*)vab
        vab=(vab--189.39622611d0)*27.2114d0
        read(3,*)asymb,ct(:,1)
        read(3,*)asymb,ct(:,2)
        read(3,*)asymb,ct(:,3)
        read(3,*)asymb,ct(:,4)
        read(3,*)asymb,ct(:,5)
        call ch2oopipNN(ct,vpes,v1,v2,v3) 
        write(6,*)vab,vpes,vpes-vab
      enddo


      end program main
