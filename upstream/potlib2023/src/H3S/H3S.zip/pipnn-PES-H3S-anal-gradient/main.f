      program main
      implicit none
      integer,parameter::ndata=2
      real*8,parameter::vref=-399.45863953d0
      real*8 ct(3,4),vfit1,rb(6),cy(3,4),cr(3,4),vfit2,diff(ndata)
      real*8 vab,rmse,maxd,dvdx(12),ta,tb,t1,t2,vdriv(3,4),vb,rb1
      real*8 maxdd(ndata)
      real*8 hinc,t3,tc,maxddd
      integer i,j,k,m
      character*8 asymb

      call pes_init

      rmse=0d0
      maxd=-1d0
      ta=0d0;tb=0d0;tc=0d0;hinc=1d-4
      k=0
      open(11,file='test-h3s.xyz',status='old')
      open(99999,file='test.out')
      do i=1,ndata
        read(11,*)m
        read(11,*)vab,rb1,vb
        read(11,*)asymb,ct(:,1)
        read(11,*)asymb,ct(:,2)
        read(11,*)asymb,ct(:,3)
        read(11,*)asymb,ct(:,4)

        cy(:,1)=ct(:,1)
        cy(:,2)=ct(:,2)
        cy(:,3)=ct(:,3)
        cy(:,4)=ct(:,4)
        
        vab=(vab-vref)*27.2114d0
        cy=cy/0.5291772d0
        do j=1,4
         do k=1,3
          cy(k,j)=cy(k,j)+hinc
          cy=cy*0.5291772d0
          call evvdvdx(cy,vfit1,dvdx,0)
          cy=cy/0.5291772d0
          cy(k,j)=cy(k,j)-hinc

          cy(k,j)=cy(k,j)-hinc
          cy=cy*0.5291772d0
          call evvdvdx(cy,vfit2,dvdx,0) 
          cy=cy/0.5291772d0
          cy(k,j)=cy(k,j)+hinc

          vdriv(k,j)=(vfit1-vfit2)/627.5095d0/2d0/hinc
         enddo
        enddo
        cy=cy*0.5291772d0
        call evvdvdx(cy,vfit1,dvdx,0) 
        tc=t2-t1+tc

        call evvdvdx(cy,vfit2,dvdx,1)
        dvdx=dvdx/627.5095d0*0.5291772d0

        maxdd(i)=0d0
        maxdd(i)=max(dabs(dvdx(1)-vdriv(1,1)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(2)-vdriv(2,1)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(3)-vdriv(3,1)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(4)-vdriv(1,2)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(5)-vdriv(2,2)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(6)-vdriv(3,2)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(7)-vdriv(1,3)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(8)-vdriv(2,3)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(9)-vdriv(3,3)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(10)-vdriv(1,4)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(11)-vdriv(2,4)),maxdd(i))
        maxdd(i)=max(dabs(dvdx(12)-vdriv(3,4)),maxdd(i))

        rmse=rmse+(vfit2-vab)**2
        maxd=max(maxd,dabs(vfit1-vab))
        write(99999,'(i7,5f16.8)')m
        write(99999,'(5f16.8)')vab,vfit1,vfit2,maxdd(i)
        write(99999,'(a3,9E16.8)')'H',ct(:,1),dvdx(1:3),vdriv(:,1)
        write(99999,'(a3,9E16.8)')'H',ct(:,2),dvdx(4:6),vdriv(:,2)
        write(99999,'(a3,9E16.8)')'H',ct(:,3),dvdx(7:9),vdriv(:,3)
        write(99999,'(a3,9E16.8)')'S',ct(:,4),dvdx(10:12),vdriv(:,4)
      enddo
      maxddd=maxval(maxdd(:))
      write(99999,*)'maxd=',maxd
      write(99999,*)'rmse=',dsqrt(rmse/dble(ndata)),ndata
      write(99999,*)'maxddd=',maxddd

      end


