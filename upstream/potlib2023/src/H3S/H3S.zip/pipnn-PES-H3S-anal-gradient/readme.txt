!********************************************************************** 
!   System:                     H3S
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                H3S
!   Number of derivatives:      1 
!   Number of bodies:           4
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: 
!   “Full-dimensional global potential energy surfaces describing abstraction 
!    and exchange for the H+H2S reaction”
!   Dandan Lu, Jun Li*,  
!   Journal of Chemical Physics, 2016, 145, 014303
!
!   Notes: see below
!
!**********************************************************************

****************************************************************************
* PIP-NN PES for H + H2S system at CCSD(T)-F12a/AVTZ level with 
* analytical gradients for PIP-NN
* Reference: Journal of Chemical Physics, 2016, 145, 014303.
****************************************************************************
                            
These files are for the PES of H + H2S reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: h3s-pipnn.f

To use this PES, as shown in the main.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call evvdvdx(cy,vfit2,dvdx,1)
     where,
       cy: XYZ cartesian coordinate in HHHS order and angstrom unit, shown in test-h3s.xyz
       vfit2:  the potential energy(in eV) relative to the reactant asymptote.
	   dvdx: the corresponding gradients determined analytically if the last input is 1.
