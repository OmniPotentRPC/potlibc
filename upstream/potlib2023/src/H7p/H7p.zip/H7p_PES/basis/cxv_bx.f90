SUBROUTINE cxv_bx (nki, nkj, pc, r, w)
integer, intent (in) :: nki(0:), nkj(0:)
type (cx_t), intent (in) :: pc
real (kind=wp), intent (in) :: r(0:,0:)
real (kind=wp), intent (out) :: w(0:,0:)
!-----------------------------------------------------------------------
integer :: ikv(0:size(nkj)-1), len
if (size(nki).lt.size(nkj)) then
 stop 'cxv_bx: bad dimension nki, nkj'
else if (size(r,1).ne.sum(nki).or.size(r,2).ne.sum(nki)) then
 stop 'cxv_bx: bad dimension nki, r'
else if (size(w,1).ne.sum(nki)) then
 stop 'cxv_bx: bad dimension w (1)'
!! else if (size(w,2).ne....) then
!!  stop 'cxv_bx: bad dimension w (2)'
endif
w = 0
if (any(nki(0:size(nkj)-1).lt.nkj)) then
 return
else if (2.le.sum(nkj).and.pc%dg.lt.0) then
 return
endif
ikv = cx_sort(nkj)
len = count(nkj.ne.0)
select case (mgx_id(nkj))
case (0)
case (1)
 call cxv_b1 (nki, ikv(0:len-1), w)
case (mg7_id)
 call cxv_b7 (nki, ikv(0:len-1), pc, r, w)
case default
 stop 'cxv_bx: bad nkj'
end select
return
END SUBROUTINE cxv_bx
