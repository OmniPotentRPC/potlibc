MODULE pes1_xyz
use pes_x1
use pes_x7
public
END MODULE pes1_xyz
