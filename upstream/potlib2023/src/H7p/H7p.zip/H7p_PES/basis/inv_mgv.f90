MODULE inv_mgv
use inv_mgv7
public
END MODULE inv_mgv
