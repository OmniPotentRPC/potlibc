module pes_shell
  use pes0
  use pes1c
  use pes_x7
  use inv_wp
  implicit none
  real(kind=wp),parameter::auang=0.5291772083
contains
  !==================================================
  subroutine pes_init()
    character (len=*), parameter :: dname='./coefs/'
    call pes0_init (dname)
    call pes1_init (pes_x7_sysall)
    return
  end subroutine pes_init
  !==================================================
  function f(x)
    real(kind=wp),dimension(:,:)::x
    real(kind=wp)::f

    f=pes_x7_pot(x)

    return
  end function f
end module pes_shell
