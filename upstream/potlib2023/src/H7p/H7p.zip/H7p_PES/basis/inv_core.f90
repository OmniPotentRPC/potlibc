MODULE inv_core
use inv_wp
use inv_cg7
use inv_cg6
use inv_sym6
public
END MODULE inv_core
