PURE FUNCTION px_x7_nbase () RESULT (nb)
integer :: nb
!-----------------------------------------------------------------------
nb = cx_nbase(pes_x7_nki,pes_x7_sysnew,px_pcv)
return
END FUNCTION px_x7_nbase
