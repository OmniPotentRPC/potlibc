MODULE inv_cxy
use inv_cx1
use inv_cx7
use inv_cxv1
use inv_cxv7
public
END MODULE inv_cxy
