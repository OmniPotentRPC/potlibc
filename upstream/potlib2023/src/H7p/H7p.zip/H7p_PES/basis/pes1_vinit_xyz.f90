SUBROUTINE pes1_vinit_xyz (sys)
! Read vpcf data files for XYZ systems.
character (len=*), intent (in) :: sys
!------------------------------------------------------------------------
integer :: iun, l0, l1
call pes_getiun (iun)
l0 = len_trim(pes_dir)
l1 = len_trim(sys)
! Read vpcf data for the one-body systems
if (cx_substr(sys(1:l1),'x1')) then
 write (*,*) ' reading vpcf-x1.dat'
 call pes_x1_vread (iun, pes_dir(1:l0)//'vpcf-x1.dat')
else
 pes_x1_vcf = 0
endif
if (cx_substr(sys(1:l1),'x7')) then
 write (*,*) ' reading vpcf-x7.dat'
 call pes_x7_vread (iun, pes_dir(1:l0)//'vpcf-x7.dat')
else
 pes_x7_vpc = cx_null ; allocate (pes_x7_vcf(0:-1))
endif
return
END SUBROUTINE pes1_vinit_xyz
