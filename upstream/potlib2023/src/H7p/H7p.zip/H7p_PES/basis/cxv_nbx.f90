PURE FUNCTION cxv_nbx (nkj, dg) RESULT (nb)
integer, intent (in) :: nkj(0:), dg
integer :: nb
!-----------------------------------------------------------------------
! Note: All error conditions are indicated by returning nb = -huge(0)
integer :: id
if (dg.lt.0) then
 nb = 0
 return
endif
select case (mgx_id(nkj))
case (0)
 nb = 0
case (1)
 nb = 1 !! must look into this
case (mg7_id)
 nb = mgv7_nb(dg)
case default
 nb = -huge(0)
end select
return
END FUNCTION cxv_nbx
