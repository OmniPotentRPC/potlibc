SUBROUTINE pes1_init_xyz (sys)
! Read pcf data files for XYZ systems.
character (len=*), intent (in) :: sys
!------------------------------------------------------------------------
integer :: iun, l0, l1
call pes_getiun (iun)
l0 = len_trim(pes_dir)
l1 = len_trim(sys)
! Read pcf data for the one-body systems
if (cx_substr(sys(1:l1),'x1')) then
 write (*,*) ' reading pcf-x1.dat'
 call pes_x1_read (iun, pes_dir(1:l0)//'pcf-x1.dat')
else
 pes_x1_cf = 0
endif
if (cx_substr(sys(1:l1),'x7')) then
 write (*,*) ' reading pcf-x7.dat'
 call pes_x7_read (iun, pes_dir(1:l0)//'pcf-x7.dat')
else
 pes_x7_pc = cx_null ; allocate (pes_x7_cf(0:-1))
endif
return
END SUBROUTINE pes1_init_xyz
