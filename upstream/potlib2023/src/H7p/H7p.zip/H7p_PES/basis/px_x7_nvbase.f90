PURE FUNCTION px_x7_nvbase () RESULT (nb)
integer :: nb
!-----------------------------------------------------------------------
nb = cxv_nbase(pes_x7_nki,pes_x7_sysnew,px_vpcv)
return
END FUNCTION px_x7_nvbase
