FUNCTION pes_x7_pot (xn) RESULT (f)
! Potential for generic X7
real (kind=wp), intent (in) :: xn(0:,0:)
real (kind=wp) :: f
!-----------------------------------------------------------------------
real (kind=wp) :: r(0:pes_x7_nk-1,0:pes_x7_nk-1)
integer, parameter :: nki(0:0)=pes_x7_nki
call pes_dists (xn, r)
f = pes_x1_cf*nki(0)+ &
  cx_f7(nki,r,pes_x7_pc,pes_x7_cf)
return
END FUNCTION pes_x7_pot
