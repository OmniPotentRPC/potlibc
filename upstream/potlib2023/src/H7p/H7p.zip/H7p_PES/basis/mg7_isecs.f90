SUBROUTINE mg7_isecs (mxd, r, pv)
integer, intent (in) :: mxd
real (kind=wp), intent (in) :: r(0:,0:)
real (kind=wp), intent (out) :: pv(0:)
!! Note: We don't have the secondaries at degrees 8; Magma ran out of
!! memory (4GB max) computing v(273:722).
!-----------------------------------------------------------------------
integer, parameter :: m=nk, m2=m*(m-1), m3=m2*(m-2), &
  m4=m3*(m-3), m5=m4*(m-4), mm=m5*(m-5)
integer :: i0, i1, i2, i3, i4, i5, i
real (kind=wp), dimension (0:nk-1,0:nk-1) :: d, d2, d3, d4, d5, d6, d7
integer, dimension(17) :: aa=(/0,1,8,9,10,33,34,35,36,37,38,103,104,105,106,107,108/)
integer, dimension(75) :: bb=(/2,3,4,5,6,11,12,13,14,15,16,17,18,19,20,21,39,40,41,&
   42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,109,110,111,112,113,114,&
   115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,&
   135,136,137,138,139,140,141,142,143,144,145/)
integer, dimension(125) :: cc=(/7,22,23,24,25,26,27,28,29,30,31,61,62,63,64,65,66,67,&
   68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,146,&
   147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,&
   167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,&
   187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,&
   207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225,226,&
   227/)
integer, dimension(55) :: dd=(/32,93,94,95,96,97,98,99,100,101,102,228,229,230,231,&
   232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,249,250,251,&
   252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271/)
if (size(r).ne.nk*nk) then
 stop 'mg7_isecs: bad dimensions'
endif
call mgx_setd (r, d, d2, d3, d4, d5, d6, d7)
pv = 0
!write(*,*)'This is new'
do i0 = 0, m-1
 do i1 = 0, m-1
  if (i1.ne.i0) then
   do i2 = 0, m-1
    if (i2.ne.i0.and.i2.ne.i1) then
     if (4.le.mxd) then
      pv(0) = pv(0)+d2(i0,i1)*d2(i0,i2)
      pv(1) = pv(1)+d2(i0,i1)*d(i0,i2)*d(i1,i2)
     endif
     if (5.le.mxd) then
      pv(8) = pv(8)+d3(i0,i1)*d2(i0,i2)
      pv(9) = pv(9)+d3(i0,i1)*d(i0,i2)*d(i1,i2)
      pv(10) = pv(10)+d2(i0,i1)*d2(i0,i2)*d(i1,i2)
     endif
     if (6.le.mxd) then
      pv(33) = pv(33)+d5(i0,i1)*d(i0,i2)
      pv(34) = pv(34)+d4(i0,i1)*d2(i0,i2)
      pv(35) = pv(35)+d3(i0,i1)*d3(i0,i2)
      pv(36) = pv(36)+d4(i0,i1)*d(i0,i2)*d(i1,i2)
      pv(37) = pv(37)+d3(i0,i1)*d2(i0,i2)*d(i1,i2)
      pv(38) = pv(38)+d2(i0,i1)*d2(i0,i2)*d2(i1,i2)
     endif
     if (7.le.mxd) then
      pv(103) = pv(103)+d5(i0,i1)*d2(i0,i2)
      pv(104) = pv(104)+d4(i0,i1)*d3(i0,i2)
      pv(105) = pv(105)+d5(i0,i1)*d(i0,i2)*d(i1,i2)
      pv(106) = pv(106)+d4(i0,i1)*d2(i0,i2)*d(i1,i2)
      pv(107) = pv(107)+d3(i0,i1)*d3(i0,i2)*d(i1,i2)
      pv(108) = pv(108)+d3(i0,i1)*d2(i0,i2)*d2(i1,i2)
     endif
     do i3 = 0, m-1
      if (i3.ne.i0.and.i3.ne.i1.and.i3.ne.i2) then
       if (4.le.mxd) then
        pv(2) = pv(2)+d2(i0,i1)*d(i0,i2)*d(i0,i3)
        pv(3) = pv(3)+d2(i0,i1)*d(i1,i2)*d(i0,i3)
        pv(4) = pv(4)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)
        pv(5) = pv(5)+d(i0,i1)*d2(i1,i2)*d(i0,i3)
        pv(6) = pv(6)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
       endif
       if (5.le.mxd) then
        pv(11) = pv(11)+d3(i0,i1)*d(i0,i2)*d(i0,i3)
        pv(12) = pv(12)+d2(i0,i1)*d2(i0,i2)*d(i0,i3)
        pv(13) = pv(13)+d3(i0,i1)*d(i1,i2)*d(i0,i3)
        pv(14) = pv(14)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)
        pv(15) = pv(15)+d2(i0,i1)*d2(i1,i2)*d(i0,i3)
        pv(16) = pv(16)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i0,i3)
        pv(17) = pv(17)+d(i0,i1)*d3(i1,i2)*d(i0,i3)
        pv(18) = pv(18)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d2(i0,i3)
        pv(19) = pv(19)+d(i0,i1)*d2(i1,i2)*d2(i0,i3)
        pv(20) = pv(20)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(21) = pv(21)+d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
       endif
       if (6.le.mxd) then
        pv(39) = pv(39)+d4(i0,i1)*d(i0,i2)*d(i0,i3)
        pv(40) = pv(40)+d3(i0,i1)*d2(i0,i2)*d(i0,i3)
        pv(41) = pv(41)+d4(i0,i1)*d(i1,i2)*d(i0,i3)
        pv(42) = pv(42)+d3(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)
        pv(43) = pv(43)+d2(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i0,i3)
        pv(44) = pv(44)+d3(i0,i1)*d2(i1,i2)*d(i0,i3)
        pv(45) = pv(45)+d2(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i0,i3)
        pv(46) = pv(46)+d2(i0,i1)*d3(i1,i2)*d(i0,i3)
        pv(47) = pv(47)+d(i0,i1)*d(i0,i2)*d3(i1,i2)*d(i0,i3)
        pv(48) = pv(48)+d(i0,i1)*d4(i1,i2)*d(i0,i3)
        pv(49) = pv(49)+d2(i0,i1)*d2(i0,i2)*d2(i0,i3)
        pv(50) = pv(50)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d2(i0,i3)
        pv(51) = pv(51)+d2(i0,i1)*d2(i1,i2)*d2(i0,i3)
        pv(52) = pv(52)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d2(i0,i3)
        pv(53) = pv(53)+d(i0,i1)*d3(i1,i2)*d2(i0,i3)
        pv(54) = pv(54)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d3(i0,i3)
        pv(55) = pv(55)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(56) = pv(56)+d(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(57) = pv(57)+d3(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(58) = pv(58)+d2(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(59) = pv(59)+d(i0,i2)*d2(i1,i2)*d2(i0,i3)*d(i1,i3)
        pv(60) = pv(60)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)
       endif
       if (7.le.mxd) then
        pv(109) = pv(109)+d5(i0,i1)*d(i0,i2)*d(i0,i3)
        pv(110) = pv(110)+d4(i0,i1)*d2(i0,i2)*d(i0,i3)
        pv(111) = pv(111)+d3(i0,i1)*d3(i0,i2)*d(i0,i3)
        pv(112) = pv(112)+d5(i0,i1)*d(i1,i2)*d(i0,i3)
        pv(113) = pv(113)+d4(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)
        pv(114) = pv(114)+d3(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i0,i3)
        pv(115) = pv(115)+d4(i0,i1)*d2(i1,i2)*d(i0,i3)
        pv(116) = pv(116)+d3(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i0,i3)
        pv(117) = pv(117)+d2(i0,i1)*d2(i0,i2)*d2(i1,i2)*d(i0,i3)
        pv(118) = pv(118)+d3(i0,i1)*d3(i1,i2)*d(i0,i3)
        pv(119) = pv(119)+d2(i0,i1)*d(i0,i2)*d3(i1,i2)*d(i0,i3)
        pv(120) = pv(120)+d2(i0,i1)*d4(i1,i2)*d(i0,i3)
        pv(121) = pv(121)+d(i0,i1)*d(i0,i2)*d4(i1,i2)*d(i0,i3)
        pv(122) = pv(122)+d(i0,i1)*d5(i1,i2)*d(i0,i3)
        pv(123) = pv(123)+d3(i0,i1)*d2(i0,i2)*d2(i0,i3)
        pv(124) = pv(124)+d3(i0,i1)*d(i0,i2)*d(i1,i2)*d2(i0,i3)
        pv(125) = pv(125)+d2(i0,i1)*d2(i0,i2)*d(i1,i2)*d2(i0,i3)
        pv(126) = pv(126)+d3(i0,i1)*d2(i1,i2)*d2(i0,i3)
        pv(127) = pv(127)+d2(i0,i1)*d(i0,i2)*d2(i1,i2)*d2(i0,i3)
        pv(128) = pv(128)+d2(i0,i1)*d3(i1,i2)*d2(i0,i3)
        pv(129) = pv(129)+d(i0,i1)*d(i0,i2)*d3(i1,i2)*d2(i0,i3)
        pv(130) = pv(130)+d(i0,i1)*d4(i1,i2)*d2(i0,i3)
        pv(131) = pv(131)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d3(i0,i3)
        pv(132) = pv(132)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d3(i0,i3)
        pv(133) = pv(133)+d(i0,i1)*d3(i1,i2)*d3(i0,i3)
        pv(134) = pv(134)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d4(i0,i3)
        pv(135) = pv(135)+d3(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(136) = pv(136)+d2(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(137) = pv(137)+d(i0,i1)*d3(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(138) = pv(138)+d4(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(139) = pv(139)+d(i0,i1)*d2(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(140) = pv(140)+d3(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)
        pv(141) = pv(141)+d(i0,i1)*d2(i0,i2)*d(i1,i2)*d2(i0,i3)*d(i1,i3)
        pv(142) = pv(142)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d2(i0,i3)*d(i1,i3)
        pv(143) = pv(143)+d2(i0,i2)*d2(i1,i2)*d2(i0,i3)*d(i1,i3)
        pv(144) = pv(144)+d(i0,i2)*d3(i1,i2)*d2(i0,i3)*d(i1,i3)
        pv(145) = pv(145)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)
       endif
       do i4 = 0, m-1
        if (i4.ne.i0.and.i4.ne.i1.and.i4.ne.i2.and.i4.ne.i3) then
         if (4.le.mxd) then
          pv(7) = pv(7)+d(i0,i1)*d(i1,i2)*d(i0,i3)*d(i0,i4)
         endif
         if (5.le.mxd) then
          pv(22) = pv(22)+d2(i0,i1)*d(i0,i2)*d(i0,i3)*d(i0,i4)
          pv(23) = pv(23)+d2(i0,i1)*d(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(24) = pv(24)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(25) = pv(25)+d(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(26) = pv(26)+d(i0,i1)*d(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(27) = pv(27)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(28) = pv(28)+d2(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(29) = pv(29)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(30) = pv(30)+d(i0,i1)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(31) = pv(31)+d(i1,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
         endif
         if (6.le.mxd) then
          pv(61) = pv(61)+d3(i0,i1)*d(i0,i2)*d(i0,i3)*d(i0,i4)
          pv(62) = pv(62)+d2(i0,i1)*d2(i0,i2)*d(i0,i3)*d(i0,i4)
          pv(63) = pv(63)+d3(i0,i1)*d(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(64) = pv(64)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(65) = pv(65)+d2(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(66) = pv(66)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(67) = pv(67)+d(i0,i1)*d3(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(68) = pv(68)+d2(i0,i1)*d(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(69) = pv(69)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(70) = pv(70)+d(i0,i1)*d2(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(71) = pv(71)+d(i0,i1)*d(i1,i2)*d3(i0,i3)*d(i0,i4)
          pv(72) = pv(72)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(73) = pv(73)+d(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(74) = pv(74)+d3(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(75) = pv(75)+d2(i0,i2)*d2(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(76) = pv(76)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(77) = pv(77)+d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(78) = pv(78)+d(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(79) = pv(79)+d(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(80) = pv(80)+d2(i1,i2)*d2(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(81) = pv(81)+d(i0,i1)*d2(i1,i2)*d2(i1,i3)*d(i0,i4)
          pv(82) = pv(82)+d(i0,i2)*d2(i1,i2)*d2(i1,i3)*d(i0,i4)
          pv(83) = pv(83)+d2(i0,i1)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(84) = pv(84)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(85) = pv(85)+d(i0,i1)*d2(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(86) = pv(86)+d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(87) = pv(87)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d2(i0,i4)
          pv(88) = pv(88)+d(i0,i1)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d2(i0,i4)
          pv(89) = pv(89)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i1,i4)
          pv(90) = pv(90)+d(i0,i1)*d(i0,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(91) = pv(91)+d(i0,i1)*d(i1,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(92) = pv(92)+d2(i1,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
         endif
         if (7.le.mxd) then
          pv(146) = pv(146)+d4(i0,i1)*d(i0,i2)*d(i0,i3)*d(i0,i4)
          pv(147) = pv(147)+d3(i0,i1)*d2(i0,i2)*d(i0,i3)*d(i0,i4)
          pv(148) = pv(148)+d4(i0,i1)*d(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(149) = pv(149)+d3(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(150) = pv(150)+d2(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(151) = pv(151)+d3(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(152) = pv(152)+d2(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(153) = pv(153)+d2(i0,i1)*d3(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(154) = pv(154)+d(i0,i1)*d(i0,i2)*d3(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(155) = pv(155)+d(i0,i1)*d4(i1,i2)*d(i0,i3)*d(i0,i4)
          pv(156) = pv(156)+d2(i0,i1)*d2(i0,i2)*d2(i0,i3)*d(i0,i4)
          pv(157) = pv(157)+d3(i0,i1)*d(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(158) = pv(158)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(159) = pv(159)+d2(i0,i1)*d2(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(160) = pv(160)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(161) = pv(161)+d(i0,i1)*d3(i1,i2)*d2(i0,i3)*d(i0,i4)
          pv(162) = pv(162)+d2(i0,i1)*d(i1,i2)*d3(i0,i3)*d(i0,i4)
          pv(163) = pv(163)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d3(i0,i3)*d(i0,i4)
          pv(164) = pv(164)+d(i0,i1)*d2(i1,i2)*d3(i0,i3)*d(i0,i4)
          pv(165) = pv(165)+d(i0,i1)*d(i1,i2)*d4(i0,i3)*d(i0,i4)
          pv(166) = pv(166)+d3(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(167) = pv(167)+d2(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(168) = pv(168)+d(i0,i1)*d3(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(169) = pv(169)+d4(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(170) = pv(170)+d(i0,i1)*d2(i0,i2)*d2(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(171) = pv(171)+d3(i0,i2)*d2(i1,i2)*d(i1,i3)*d(i0,i4)
          pv(172) = pv(172)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(173) = pv(173)+d(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(174) = pv(174)+d3(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(175) = pv(175)+d2(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(176) = pv(176)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(177) = pv(177)+d2(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(178) = pv(178)+d(i0,i1)*d3(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(179) = pv(179)+d(i0,i2)*d3(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(180) = pv(180)+d2(i0,i2)*d(i1,i2)*d2(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(181) = pv(181)+d(i0,i1)*d2(i1,i2)*d2(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(182) = pv(182)+d(i0,i2)*d2(i1,i2)*d2(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(183) = pv(183)+d3(i1,i2)*d2(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(184) = pv(184)+d2(i1,i2)*d3(i0,i3)*d(i1,i3)*d(i0,i4)
          pv(185) = pv(185)+d2(i0,i1)*d2(i1,i2)*d2(i1,i3)*d(i0,i4)
          pv(186) = pv(186)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d2(i1,i3)*d(i0,i4)
          pv(187) = pv(187)+d2(i0,i2)*d2(i1,i2)*d2(i1,i3)*d(i0,i4)
          pv(188) = pv(188)+d(i0,i1)*d3(i1,i2)*d2(i1,i3)*d(i0,i4)
          pv(189) = pv(189)+d(i0,i2)*d3(i1,i2)*d2(i1,i3)*d(i0,i4)
          pv(190) = pv(190)+d(i0,i2)*d2(i1,i2)*d(i0,i3)*d2(i1,i3)*d(i0,i4)
          pv(191) = pv(191)+d3(i1,i2)*d(i0,i3)*d2(i1,i3)*d(i0,i4)
          pv(192) = pv(192)+d3(i0,i1)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(193) = pv(193)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(194) = pv(194)+d2(i0,i1)*d2(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(195) = pv(195)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(196) = pv(196)+d(i0,i1)*d3(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(197) = pv(197)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)*&
            d(i0,i4)
          pv(198) = pv(198)+d(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(199) = pv(199)+d3(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(200) = pv(200)+d2(i1,i2)*d2(i0,i3)*d(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(201) = pv(201)+d(i0,i1)*d2(i1,i2)*d2(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(202) = pv(202)+d(i0,i2)*d2(i1,i2)*d2(i1,i3)*d(i2,i3)*d(i0,i4)
          pv(203) = pv(203)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d2(i0,i3)*d2(i0,i4)
          pv(204) = pv(204)+d(i0,i1)*d2(i1,i2)*d2(i0,i3)*d2(i0,i4)
          pv(205) = pv(205)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d2(i0,i4)
          pv(206) = pv(206)+d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d2(i0,i4)
          pv(207) = pv(207)+d(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d2(i0,i4)
          pv(208) = pv(208)+d(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d2(i0,i4)
          pv(209) = pv(209)+d2(i0,i1)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d2(i0,i4)
          pv(210) = pv(210)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d2(i0,i4)
          pv(211) = pv(211)+d(i0,i1)*d2(i1,i2)*d(i1,i3)*d(i2,i3)*d2(i0,i4)
          pv(212) = pv(212)+d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)*d2(i0,i4)
          pv(213) = pv(213)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d3(i0,i4)
          pv(214) = pv(214)+d(i0,i1)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d3(i0,i4)
          pv(215) = pv(215)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*&
            d(i1,i4)
          pv(216) = pv(216)+d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i1,i4)
          pv(217) = pv(217)+d2(i0,i1)*d(i0,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(218) = pv(218)+d2(i0,i1)*d(i1,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(219) = pv(219)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*&
            d(i1,i4)
          pv(220) = pv(220)+d(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(221) = pv(221)+d3(i1,i2)*d(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(222) = pv(222)+d(i0,i2)*d(i1,i2)*d2(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(223) = pv(223)+d2(i1,i2)*d2(i0,i3)*d(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(224) = pv(224)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)*d(i0,i4)*&
            d(i1,i4)
          pv(225) = pv(225)+d(i0,i1)*d(i0,i2)*d(i0,i3)*d2(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(226) = pv(226)+d(i0,i1)*d(i1,i2)*d(i0,i3)*d2(i2,i3)*d(i0,i4)*d(i1,i4)
          pv(227) = pv(227)+d2(i1,i2)*d(i0,i3)*d2(i2,i3)*d(i0,i4)*d(i1,i4)
         endif
         do i5 = 0, m-1
          if (i5.ne.i0.and.i5.ne.i1.and.i5.ne.i2.and.i5.ne.i3.and. &
            i5.ne.i4) then
           if (5.le.mxd) then
            pv(32) = pv(32)+d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
           endif
           if (6.le.mxd) then
            pv(93) = pv(93)+d2(i0,i1)*d(i0,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(94) = pv(94)+d2(i0,i1)*d(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(95) = pv(95)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(96) = pv(96)+d(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(97) = pv(97)+d2(i0,i1)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(98) = pv(98)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(99) = pv(99)+d2(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(100) = pv(100)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(101) = pv(101)+d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(102) = pv(102)+d(i0,i2)*d(i1,i2)*d(i1,i3)*d2(i0,i4)*d(i0,i5)
           endif
           if (7.le.mxd) then
            pv(228) = pv(228)+d3(i0,i1)*d(i0,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(229) = pv(229)+d2(i0,i1)*d2(i0,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(230) = pv(230)+d3(i0,i1)*d(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(231) = pv(231)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(232) = pv(232)+d2(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(233) = pv(233)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(234) = pv(234)+d(i0,i1)*d3(i1,i2)*d(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(235) = pv(235)+d2(i0,i1)*d(i1,i2)*d2(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(236) = pv(236)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d2(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(237) = pv(237)+d(i0,i1)*d2(i1,i2)*d2(i0,i3)*d(i0,i4)*d(i0,i5)
            pv(238) = pv(238)+d3(i0,i1)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(239) = pv(239)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(240) = pv(240)+d(i0,i1)*d2(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(241) = pv(241)+d3(i0,i2)*d(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(242) = pv(242)+d2(i0,i1)*d2(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(243) = pv(243)+d(i0,i1)*d(i0,i2)*d2(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(244) = pv(244)+d2(i0,i2)*d2(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(245) = pv(245)+d(i0,i2)*d3(i1,i2)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(246) = pv(246)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*&
              d(i0,i5)
            pv(247) = pv(247)+d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(248) = pv(248)+d(i0,i1)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(249) = pv(249)+d(i0,i2)*d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(250) = pv(250)+d3(i1,i2)*d(i0,i3)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(251) = pv(251)+d2(i1,i2)*d2(i0,i3)*d(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(252) = pv(252)+d(i0,i1)*d2(i1,i2)*d2(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(253) = pv(253)+d(i0,i2)*d2(i1,i2)*d2(i1,i3)*d(i0,i4)*d(i0,i5)
            pv(254) = pv(254)+d2(i0,i1)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)*d(i0,i5)
            pv(255) = pv(255)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)*&
              d(i0,i5)
            pv(256) = pv(256)+d(i0,i1)*d2(i1,i2)*d(i1,i3)*d(i2,i3)*d(i0,i4)*d(i0,i5)
            pv(257) = pv(257)+d2(i1,i2)*d(i0,i3)*d(i1,i3)*d(i2,i3)*d(i0,i4)*d(i0,i5)
            pv(258) = pv(258)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i1,i3)*d2(i0,i4)*d(i0,i5)
            pv(259) = pv(259)+d2(i0,i2)*d(i1,i2)*d(i1,i3)*d2(i0,i4)*d(i0,i5)
            pv(260) = pv(260)+d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d2(i0,i4)*d(i0,i5)
            pv(261) = pv(261)+d2(i1,i2)*d(i0,i3)*d(i1,i3)*d2(i0,i4)*d(i0,i5)
            pv(262) = pv(262)+d(i0,i2)*d(i1,i2)*d(i1,i3)*d3(i0,i4)*d(i0,i5)
            pv(263) = pv(263)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i1,i4)*&
              d(i0,i5)
            pv(264) = pv(264)+d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i1,i3)*d(i1,i4)*d(i0,i5)
            pv(265) = pv(265)+d2(i0,i1)*d2(i0,i2)*d(i2,i3)*d(i1,i4)*d(i0,i5)
            pv(266) = pv(266)+d2(i0,i1)*d(i0,i2)*d(i1,i2)*d(i2,i3)*d(i1,i4)*d(i0,i5)
            pv(267) = pv(267)+d2(i0,i1)*d(i0,i2)*d(i0,i3)*d(i2,i3)*d(i1,i4)*d(i0,i5)
            pv(268) = pv(268)+d(i0,i1)*d2(i0,i2)*d(i0,i3)*d(i2,i3)*d(i1,i4)*d(i0,i5)
            pv(269) = pv(269)+d2(i0,i1)*d(i1,i2)*d(i0,i3)*d(i2,i3)*d(i1,i4)*d(i0,i5)
            pv(270) = pv(270)+d(i0,i1)*d(i0,i2)*d(i1,i2)*d(i0,i3)*d(i2,i3)*d(i1,i4)*&
              d(i0,i5)
            pv(271) = pv(271)+d2(i0,i2)*d(i1,i2)*d(i0,i3)*d(i2,i3)*d(i1,i4)*d(i0,i5)
           endif
          endif
         enddo
        endif
       enddo
      endif
     enddo
    endif
   enddo
  endif
 enddo
enddo
pv(aa) = pv(aa)/m3
pv(bb) = pv(bb)/m4
pv(cc) = pv(cc)/m5
pv(dd) = pv(dd)/mm
return
END SUBROUTINE mg7_isecs
