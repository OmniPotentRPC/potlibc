MODULE px
!..use and access
use inv, wp=>inv_wp
use pes
implicit none
private
public :: &
  px_lsq, px_vlsq, px_lsqs, px_errf, px_errvf, &
  px_null_nbase, px_null_base
public &
  px_x7_nbase, px_x7_base, &
  px_x7_nvbase, px_x7_vbase
!..data
save
character (len=*), parameter, public :: &
  pes_x7_sysold_dflt='x1', &
  pes_x7_sysnew_dflt='7'
character (len=240), public :: &
  pes_x7_sysold=pes_x7_sysold_dflt, &
  pes_x7_sysnew=pes_x7_sysnew_dflt
integer, public :: px_ng=3, px_ng2=3
real (kind=wp), public :: &
  px_rcond=1.0e-11_wp, &
  px_wtgf=0.2_wp*pes_bohr, &
  px_wtg2f=0.05*pes_bohr**2
type (cx_t), public :: px_pcv(2:12)= &
  (/ cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null /)
type (cx_t), public :: px_vpcv(2:12)= &
  (/ cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null, &
  cx_null /)
!..procedures
CONTAINS
include 'px_lsq.f90'
include 'px_vlsq.f90'
include 'px_lsqs.f90'
include 'px_errf.f90'
include 'px_errvf.f90'
include 'px_null_nbase.f90'
include 'px_null_base.f90'
include 'px_x7_nbase.f90'
include 'px_x7_base.f90'
include 'px_x7_nvbase.f90'
include 'px_x7_vbase.f90'
END MODULE px