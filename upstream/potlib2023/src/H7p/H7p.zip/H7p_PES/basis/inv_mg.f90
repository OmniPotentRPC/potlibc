MODULE inv_mg
use inv_mgx
use inv_mg1
use inv_mg7
use inv_mg61
public
END MODULE inv_mg
