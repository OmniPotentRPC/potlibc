SUBROUTINE cx_bx (nki, nkj, pc, r, w)
integer, intent (in) :: nki(0:), nkj(0:)
type (cx_t), intent (in) :: pc
real (kind=wp), intent (in) :: r(0:,0:)
real (kind=wp), intent (out) :: w(0:)
!-----------------------------------------------------------------------
integer :: ikv(0:size(nkj)-1), len
if (size(nki).lt.size(nkj)) then
 stop 'cx_bx: bad dimension nki, nkj'
else if (size(r,1).ne.sum(nki).or.size(r,2).ne.sum(nki)) then
 stop 'cx_bx: bad dimension nki, r'
!! else if (size(w).ne....) then
!!  stop 'cx_bx: bad dimension w'
endif
if (any(nki(0:size(nkj)-1).lt.nkj)) then
 w = 0
 return
else if (2.le.sum(nkj).and.pc%dg.lt.0) then
 w = 0
 return
endif
ikv = cx_sort(nkj)
len = count(nkj.ne.0)
w = 0
select case (mgx_id(nkj))
case (0)
case (1)
 call cx_b1 (nki, ikv(0:len-1), w)
case (mg7_id)
 call cx_b7 (nki, ikv(0:len-1), pc, r, w)
case default
 stop 'cx_bx: bad nkj'
end select
return
END SUBROUTINE cx_bx
