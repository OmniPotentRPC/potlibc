module pes_shell
  use pes0
  use pes1c
  use pes_x7
  use inv_wp
  implicit none
  real(kind=wp),parameter::auang=0.5291772083
contains
  !==================================================
  subroutine pes_init() ! read the coefs from the fit
    character (len=*), parameter :: dname='./coefs/'
    call pes0_init (dname)
    call pes1_init (pes_x7_sysall)
    call pes1_vinit (pes_x7_sysall)
    return
  end subroutine pes_init
  !==================================================
  function f(x) ! compute potential, x(3,7) Cartesian coord. in bohr
                ! f: potential energy, in hartree (ie, atomic unit)
    real(kind=wp),dimension(:,:)::x
    real(kind=wp)::f

    f=pes_x7_pot(x)

    return
  end function f

  function g(x) ! compute dipole, x(3,7) Cartesian coord. in bohr
                ! g(3): x, y, z-dipole component, in atomic unit
    real(kind=wp),dimension(:,:)::x
    real(kind=wp)::q(7)
    real(kind=wp)::g(3)

    q=pes_x7_vfun(x)
    g=matmul(x,q)

    return
  end function g
end module pes_shell
