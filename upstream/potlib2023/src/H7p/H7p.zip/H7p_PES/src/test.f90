program main
  use pes_shell
  implicit none

  real(kind=wp)::xx(3,7),dp0(3),dp(3)
  character::symb
  integer::i,natm
  real(kind=wp)::pot,pot0

  call pes_init()

  read(*,*) natm
  read(*,*) pot0, dp0(:)
  do i=1,natm
     read(*,*) symb,xx(:,i)
  end do
  xx=xx/auang
  pot = f(xx)
  dp=g(xx)  ! Calculate the dipole
  write(*,'(A,F15.8,A)') "ab initio potential:", pot0, " hartree"
  write(*,'(A,F15.8,A)') "PES potential:", pot, " hartree"
  write(*,'(A,3F13.7,A)') "ab initio dipole:", dp0(:), " au"
  write(*,'(A,3F13.7,A)') "PES dipole:", dp(:), " au"

end program main
