****************************************************************************
* PIP-NN PES for ClH2O(X2A') system at UCCSD(T)-F12b/aug-cc-pVTZ level.    *
* Reference: Phys. Chem. Chem. Phys. 2017, 19 (15), 9770-9777.             *
****************************************************************************
                            
These files are for the PES of HCl+OH reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: hcloh_pes.f

To use this PES, as shown in the test.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call hcloh_pes_interface(q,vpes)
     where,
       q:    XYZ cartesian coordinate in HHClO order and angstrom unit.
       vpes: the potential in eV, relative to the post-reaction complex
             van der Waals well.
