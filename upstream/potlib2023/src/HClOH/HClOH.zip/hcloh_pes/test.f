        include 'hcloh_pes.f'

        program main
        implicit none
        integer :: i 
        character*2 :: atom(4)
        character*10 :: species       
        double precision :: q(3,4), vpes

        call pes_init
        
        open(51,file='test.xyz',status='old')
        open(61,file='test.txt',status='replace')
        do i=1,5
           read(51,*)
           read(51,*)species
           read(51,*)atom(1),q(:,1) !--> H
           read(51,*)atom(2),q(:,2) !--> H
           read(51,*)atom(3),q(:,3) !--> Cl
           read(51,*)atom(4),q(:,4) !--> O
           call hcloh_pes_interface(q,vpes) 
! vpes is energy relatived to post-reaction complex van der Waals wells
           vpes=vpes-0.9513794d0 ! energy related to reactant asymptote
           vpes=vpes*23.0605 ! eV to kcal/mol
           write(61,'(A4,f9.2)'),species,vpes
        enddo
        close(51)
        close(61)

        end program main
