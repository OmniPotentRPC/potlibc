      subroutine diJacobi_cart(r,c,amass,bmass,cmass,dmass)
      implicit none
      integer,parameter::Natom=4,Ndim=6
      real*8 r(Ndim),c(3,Natom),Mass(4),vec(3,6)
      real*8,intent(in)::amass,bmass,cmass,dmass
      real*8 XA,XB,YC,YD,Cxsin,Dxsin,dotp
      real*8 RX1,RX2,RX3,RX4,RX5,RX6
!     r(6)=PI-r(6)
      Mass(1)=AMass
      Mass(2)=BMass
      Mass(3)=CMass
      Mass(4)=DMass
      !-->diatomic Jacobi is
      !-->
      !-->   A/- r1                D\
      !-->     \                     \ r2
      !-->      \ th1    r3           \
      !-->      X\-------------------->\ Y---
      !-->        \                     \ th2
      !-->       B \                    -/ C

      !-->put ABY on xy plane, X origin point
      !-->          ^y
      !-->     A    |
      !-->     /\-  |
      !-->     r1\  |
      !-->        \ |
      !-->         \|     r3
      !--> ---------X--------->Y-->x
      !-->           \
      !-->            \
      !-->             B

      c=0.d0
      XA=Bmass/(Amass+Bmass)*r(1)
      XB=Amass/(Amass+Bmass)*r(1)
      c(1,1)= XA*dcos(r(4))
      c(2,1)= XA*dsin(r(4))
      c(1,2)=-XB*dcos(r(4))
      c(2,2)=-XB*dsin(r(4))
      !-->put ABY on xy plane, X origin point
      !-->          ^y
      !-->     A    |
      !-->     /\-  |
      !-->     r1\  |               \D
      !-->        \ |                \ |
      !-->         \|     r3          \|
      !--> ---------X----------------->Y-->x
      !-->           \                 |\
      !-->            \                |-\/C
      !-->             B
      !--> C in +z and -z phase is identical, so put it in +z
      YC=Dmass/(Cmass+Dmass)*r(2)
      YD=Cmass/(Cmass+Dmass)*r(2)
      c(1,3)=r(3)+YC*dcos(r(5))
      c(1,4)=r(3)-YD*dcos(r(5))
      Cxsin = YC*dsin(r(5))
      Dxsin =-YD*dsin(r(5))
      c(2,3)= Cxsin*dcos(r(6))
      c(3,3)= Cxsin*dsin(r(6))
      c(2,4)= Dxsin*dcos(r(6))
      c(3,4)= Dxsin*dsin(r(6))

        return
      end subroutine diJacobi_cart

