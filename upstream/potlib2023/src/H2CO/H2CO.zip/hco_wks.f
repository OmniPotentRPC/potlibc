*******************************************************
********** Suchen des HCO-Potential-Minimums **********
*******************************************************


      subroutine hcopot(f,RHC,RCO,ROH)
      IMPLICIT NONE
      integer j,loop,iv
      real*8 rmin(3),rmax(3),z1,z2,z3,m(3),h(3)
      real*8 pot,potmin,ma,mb,mc,au2ev,a0,pi
      parameter (au2ev = 27.2116d0)
      parameter (a0 = 0.52918d0)
      parameter (pi = 3.1415926536d0)
      real*8 pot3,c3,POTHCO,f
      REAL*8 V, RHC,RCO, CGAMMA, ROH
      integer istate


      ma =  1.0    !  H
      mb = 12.0    !  C
      mc = 16.0    !  O

      istate = 1      !  X-Flaeche



C       OPEN(10,FILE='pothco_hmk.para',status='old')


c ---------Initialisierung des Potentials----------
        call pot3in()
c -------------------------------------------------

c ----------Startwerte----------
c      rmin(1) = 2.5   !  R
c      rmax(1) = 3.5
c      rmin(2) = 2.0   !  r
c      rmax(2) = 3.0
c      rmin(3) = 2.0   !  gamma
c      rmax(3) = 3.0
c ------------------------------

       CGAMMA=(RHC*RHC+RCO*RCO-ROH*ROH)/(2*RHC*RCO)

   

        POT=0.0d0
C        POT= POTHCO(0.d0,0.d0,0.d0,0.d0)
c      iv = 5
      !do j = 1, 3
       ! m(j) = (rmax(j) + rmin(j))/2
       ! h(j) = (rmax(j) - rmin(j))/2
      !enddo
      !do loop = 1, 8
        !potmin = 9.9
        !do z1 = m(1)-h(1), m(1)+h(1), h(1)/iv
          !do z2 = m(2)-h(2), m(2)+h(2), h(2)/iv
           ! do z3 = m(3)-h(3), m(3)+h(3), h(3)/iv
c ----------Aufruf des Potentials---------------------
            !  c3 = dcos(z3)
             ! pot = pot3(z1,z2,c3,istate)
         POT= POTHCO(RHC,RCO,CGAMMA,ISTATE)
         pot=pot+.18140000
c ----------------------------------------------------
              !if (pot .lt. potmin) then
                !m(1) = z1
                !m(2) = z2
                !m(3) = z3
                !potmin = pot
              !endif
            !enddo
          !enddo
        !enddo
        !do j = 1, 3
         ! h(j) = h(j)/iv
        !enddo
      !enddo

       f=pot
c      write (6,'(a,f9.5,a)') 'V =', pot  !' eV'
c   write (6,66) 'R_min =', m(1), ' a.u. =', m(1)*a0,  ' A'
C      write (6,66) 'r_min =', m(2), ' a.u. =', m(2)*a0,  ' A'
C      write (6,66) 'g_min =', m(3), ' rad  =', m(3)*180/pi, ' deg.'
c      66   format (a,f9.5,a,f8.3,a)
      Return 
      end



* ------------------------------------------------------------
* ----------> ab hier kommt das Potential-Programm <----------
* ------------------------------------------------------------

c       FUNCTION POT3(R,RKLEIN,C,ISTATE)
c      IMPLICIT NONE
c      INTEGER ISTATE
c      REAL*8 POT3, R,RKLEIN,C, A
c      REAL*8 V, RHC,RCO,GAMMA, CGAMMA, X1, AU2EV, PI, POTHCO
c       EXTERNAL POTHCO
c      PARAMETER(AU2EV=27.2116D0,PI=3.141592654D0)
      !RCO= MAX(RKLEIN,1.6D0)         ! 14.1.94: frueher maximal 3.0 a.u.
      !X1= (16D0/28D0) * RCO
      !A= MAX( X1*X1 + R*R + 2D0*X1*R*C, 1D0 )
      !RHC= SQRT( A )                               ! ABSTAND RHC >= 1.
      !A= (R*R - RHC*RHC - X1*X1 ) / (-2D0*RHC*X1)  ! COS(GAMMA).
      !CGAMMA= MAX(MIN(A,1D0),-1D0)
      !GAMMA= 180D0/PI * ACOS( CGAMMA )
      !POT3= POTHCO(RHC,RCO,CGAMMA,ISTATE)
      !RETURN
      !END

       SUBROUTINE POT3IN()
       IMPLICIT NONE
       REAL*8 V, R/1D0/, RKL/1D0/, G/0D0/, POTHCO
       EXTERNAL POTHCO
       OPEN(10,FILE='pothco_hmk.para',status='old')
       V= POTHCO(0D0,0D0,0D0,0)
       CLOSE(10)
       RETURN
       END

C****************************************************************

      FUNCTION POTHCO(RHC,RCO,RCOS, ISTATE)
C
C   H-C-O Potential:
C   Ab-Initio-Daten:  Prof. Hans-Joachim Werner (Stuttgart).
C   Rationaler Fit:   Hans-Martin Keller (Goettingen).
C
C   Das H-C und H-O Diatom-Potential wurde aus der Literatur
C   entnommen (s.u.), das C-O-Potential zusammen mit dem H-C-O-Potential
C   gefittet Asymptotik nur in Richtung des H - CO Kanals korrekt !
C
C   Alle Einheiten in atomic units !
C
C   ISTATE = 0     Initialisierung beider Flaechen ( X und A ).
C          = -1    nur X-Flaeche initialisieren.
C          = -2    nur A-Flaeche initialisieren.
C          = 1     Potentialwert auf X-Flaeche berechnen.
C          = 2     Potentialwert auf A-Flaeche berechnen.
C
      IMPLICIT NONE

      INTEGER ISTATE                    ! Initialiserung falls <>0, INPUT
      REAL*8
     $     RHC,                         ! R_HC in a.u.,             INPUT
     $     RCO,                         ! R_CO in a.u.,             INPUT
     $     RCOS,                        ! COS(gamma_HCO),           INPUT
     $     POTHCO                       ! Potentialwert in a.u.,   OUTPUT

C
C Zur Initialisierung werden die Koeffizienten KK(MLIN) und die
C Parameter AA(MTAN) ueber Unit 10 eingelesen. Organisation wie in
C hmkfit.f. Die Initialisierungssequenz sieht wie folgt aus:
C
c      OPEN(10,'pothco_hmk.para')
C   A= POTHCO(0d0,0d0,0d0, 0)
C   CLOSE(10)             ===
C

*********************** KONSTANTEN (wie "hmkfit.common") **********

C**   > KONSTANTEN:
      REAL*8 AU2ANG, AU2EV, EV2CM, KC2EV, AU2CM
      PARAMETER(AU2ANG=0.529177D0)      ! a_0 / Angstroem
      PARAMETER(AU2EV=27.2116D0)        ! hartree / eV
      PARAMETER(EV2CM=8065.44D0)        ! eV / cm^-1
      PARAMETER(KC2EV=23.061D0)         ! {kcal/mol} / eV
      PARAMETER(AU2CM=AU2EV*EV2CM)      ! hartree / cm^-1

C**   > ORDNUNG DER 1D-POLYNOME FESTLEGEN:
      INTEGER NHC, NCO, NWIN            ! Anzahl der Datenpunkte.
      PARAMETER(NHC=12, NCO=9, NWIN=12)

C**   > ORDNUNG DER POLYNOME:
      INTEGER GZHC, GZCO, GZWIN, MLIN(2)   ! GRAD IM ZAEHLER
      INTEGER GNHC, GNCO, GNWIN, MTAN(2)   ! GRAD IM NENNER
      INTEGER IXHC, IXCO, IXOH          ! FESTE VORFAKTOREN IM NENNER.
      INTEGER GWHC, GWCO, GWWIN         ! POLYNOME VOR WURZEL (KONISCHE D.)
      INTEGER GZ2CO, GN2CO, IX2CO       ! DIATOM-POTENTIAL v. C-O.
      INTEGER GZ2HC, GN2HC, IX2HC       ! DIATOM-POTENTIAL v. H-C.
      INTEGER GZ2OH, GN2OH, IX2OH       ! DIATOM-POTENTIAL v. O-H.
      INTEGER MAXLIN, MAXTAN
      PARAMETER(MAXLIN=500, MAXTAN=200) ! Maximalwerte fuer MLIN und MTAN.
C      PARAMETER(
C     $     GZHC= 5, GZCO= 3, GZWIN= 6,     ***** werden eingelesen *****
C     $     GNHC= 2, GNCO= 2, GNWIN= 2,
C     $     IXHC= -7, IXCO= -5,  IXOH= -3
C     $     GWHC= 3, GWCO= 2, GWWIN= 1,
C     $     GZ2CO= 3, GN2CO= 1, IX2CO= -7,
C     $     GZ2HC= 3, GN2HC= 1, IX2HC= -7,
C     $     GZ2OH= 3, GN2OH= 1, IX2OH= -7,
C     $     MLIN=(GZHC+1)*(GZCO+1)*(GZWIN+1)
C     $         + (GWHC+1)*(GWCO+1)*(GWWIN+1)
C     $         + (GZ2HC+1) + (GZ2CO+1) + 1,
C     $     MTAN= 2*(GNHC+1)*(GNCO+1)*(GNWIN+1)-2 + 3
C     $         + 2*GN2HC + 2*GN2CO )

C**   > OFFSET IN WURZEL UND NENNER (SIEHE getvt5.f):
      REAL*8 WURADD, NENADD, EASYM
C      PARAMETER(                          ***** werden eingelesen *****
C     $     WURADD=1D-5,          ! rundet Spitze von konischer Durchschneidung.
C     $     NENADD=1D-3,          ! begrenzt Nenner nach unten.
C     $     EASYM=11.169D0/AU2EV ) ! Energie bei 3 einzelnen Atomen.

C**   > BASISPOLYNOME (1d):
C     ( "P_K(X)= Produkt_{J=1,K}(X-NU(J))" ALS ERSATZ FUER "X**K" ) :
      REAL*8
     $     NUHC(NHC)/2.3D0,2.5D0, 2.1D0,3.0D0, 1.9D0,3.5D0,
     $               1.7D0,4.0D0, 1.5D0,5.0D0, 1.3D0,7.0D0/,
     $     NUCO(NCO)/2.2d0,1.9d0, 2.5d0,1.7d0, 3.0d0,2.05d0,
     $               2.35d0,3.5d0, 4.0d0/,
     $     NUWIN(NWIN)/100d0,120d0, 80d0,140d0, 60d0,160d0,     ! NEUE NULLST.
     $                  40d0,170d0, 20d0,180d0, 10d0,0d0/
C     $     NUWIN(NWIN)/120D0,140D0, 100D0,160D0, 80D0,170D0, ! ALTE NULLST.
C     $                  40d0,170d0, 20d0,180d0, 10d0,  0d0/


C******************* Variablen *************************************

      REAL*8
     $     XCOS(NWIN), NUCOS(NWIN),     ! Umrechnung XWIN,NUWIN -> cos(winkel)
     $     KK(MAXLIN,2),                ! Koeffizienten zu VV
     $     AA(MAXTAN,2),                ! nichtlineare Parameter
     $     V2CH, V2OH                   ! Diatom-Potentiale
      EXTERNAL V2CH, V2OH


      INTEGER I, J,K,L, LL,JJ, J1,J2,J3, ! Diverser Krimskrams.
     $     KS,I1,I2                     ! Nummer d. Potentialflaeche.
      LOGICAL QINIT(2)/.false.,.false./ ! zeigt an ob Parameter initialisiert.
      REAL*8
     $     PQ,  A, B, C, NENN,
     $     RHCSIN,RHCCOS, KONUS,        ! Anteil der konischen Durchschneidung.
     $     PHC, PCO, PCOS, POH,         ! 1d-Polynome.
     $     RHCI, RCOI, RCOSI, ROHI,     ! lokale Kopien der aktuellen Parameter
     $     THY, ACO, AHC, VPLUS,        ! Fuer Skalierung.
     $     PI                           ! PI.
      COMPLEX*16
     $     QQ1, QQ2, QQ3, QQ4,          ! 3 Nenner
     $     WURZ                         ! konische Durchschneidung.

      SAVE


      IF(ISTATE.LT.-2.OR.ISTATE.GT.2)
     $     STOP 'POTHCO: ISTATE out of range'

C**** > Initialisierung falls ISTATE<=0:

      IF(ISTATE.LE.0) THEN

C       ******************************
C       *                            *
C       *     Parameter einlesen     *
C       *                            *
C       ******************************

        IF(ISTATE.EQ.0)THEN
          I1= 1                         ! 1. Flaeche in Datei (Unit 10).
          I2= 2                         ! letzte Flaeche     "           .
        ELSE IF(ISTATE.EQ.-1) THEN
          I1= 1                         ! 1. Flaeche in Datei (Unit 10).
          I2= 1                         ! letzte Flaeche        "        .
        ELSE IF(ISTATE.EQ.-2) THEN
          I1= 2                         ! 1. Flaeche in Datei (Unit 10).
          I2= 2                         ! letzte Flaeche        "        .
        END IF


C**** > INITIALISIERUNG UND AUSGABE DER PARAMETER:

        PI= ACOS(-1D0)

c        WRITE(6,'(/A)') ' Nullstellen R_HC:'
        DO J1=1,NHC
c          WRITE(6,'(A,I4,A,G14.6)')
c     $         ' J1=',J1,' NUHC=',NUHC(J1)
        END DO
c        WRITE(6,'(/A)') ' Nullstellen R_CO:'
        DO J2=1,NCO
c          WRITE(6,'(A,I4,A,G14.6)')
c     $         ' J2=',J2,' NUCO=',NUCO(J2)
        END DO
c        WRITE(6,'(/A)') ' Nullstellen GAMMA_HCO:'
        DO J3=1,NWIN
          NUCOS(J3)= COS(PI/180D0*NUWIN(J3)) ! Nullstellen d. 1d-Polynome.
c          WRITE(6,'(A,I4,A,G14.6)')
c     $       ' J3=',J3,' NUWIN=',NUWIN(J3)
        END DO

c         OPEN(10,FILE='hmkfit_u3.para')

C**     > GEMEINSAME PARAMETER DER FLAECHEN EINLESEN:
C
C   Achtung:
C     Beide Flaechen muessen mit dem gleichen Funktionenansatz
C     gefittet sein. Speziell muss der Grad aller Polynome uebereinstimmen.
C

        READ(10,*)
        READ(10,*)
        READ(10,*)   GZHC, GZCO, GZWIN
        READ(10,*)
        READ(10,*)   GNHC, GNCO, GNWIN
        READ(10,*)
        READ(10,*)   IXHC, IXCO, IXOH
        READ(10,*)
        READ(10,*)   GWHC, GWCO, GWWIN
        READ(10,*)
        READ(10,*)   GZ2HC,  GN2HC,  IX2HC
        READ(10,*)
        READ(10,*)   GZ2CO,  GN2CO,  IX2CO
        READ(10,*)
        READ(10,*)   GZ2OH,  GN2OH,  IX2OH
        READ(10,*)
        READ(10,*)   WURADD, NENADD, EASYM

c        WRITE(6,'(/A,21(/A,I5))') ' RATIONALE FIT BERECHNEN:',
c     $       ' GRAD DES ZAEHLERS IN R_HC: GZHC=', GZHC,
c     $       '        ...           R_CO: GZCO=', GZCO,
c     $       '        ...      GAMMA_HCO: GZWIN=', GZWIN,
c     $       ' GRAD DES NENNERS IN R_HC: GNHC=', GNHC,
c     $       '        ...          R_CO: GNCO=', GNCO,
c     $       '        ...         R_HCO: GNWIN=', GNWIN,
c     $       ' POTENZ VORFAKTOR IN R_HC: IXHC=', IXHC,
c     $       '        ....         R_CO: IXCO=', IXCO,
c     $       '        ....         R_OH: IXOH=', IXOH,
c     $       ' GRAD VORFAKTOR WURZEL IN R_HC: GWHC=', GWHC,
c     $       '        ...               R_CO: GWCO=', GWCO,
c     $       '        ...          GAMMA_HCO: GWWIN=', GWWIN,
c     $       ' DIATOM-POTENTIAL IN H-C, ZAEHLER: GZ2HC=', GZ2HC,
c     $       '        ...                NENNER: GN2HC=', GN2HC,
c     $       '        ...             VORFAKTOR: IX2HC=', IX2HC,
c     $       ' DIATOM-POTENTIAL IN C-O, ZAEHLER: GZ2CO=', GZ2CO,
c     $       '        ...                NENNER: GN2CO=', GN2CO,
c     $       '        ...             VORFAKTOR: IX2CO=', IX2CO,
c     $       ' DIATOM-POTENTIAL IN O-H, ZAEHLER: GZ2OH=', GZ2OH,
c     $       '        ...                NENNER: GN2OH=', GN2OH,
c     $       '        ...             VORFAKTOR: IX2OH=', IX2OH


C**     > Schleife ueber Flaechen:
        DO KS=I1,I2

C         > Initialisierung testen:
          IF(QINIT(KS)) THEN             ! Test ob schon mal initialisiert.
c            WRITE(6,'(/72(1H*)/A/72(1H*)/)')
c     $           ' HCO-Potential nochmal initialisisert !'
          ELSE
            QINIT(KS)=.true.
          END IF

C         > Parameter einlesen:
          MLIN(KS)=(GZHC+1)*(GZCO+1)*(GZWIN+1)
     $         + (GZ2CO+1)              ! + 1 ! + (GZ2HC+1) + (GZ2OH+1)
          MTAN(KS)= 2*(GNHC+1)*(GNCO+1)*(GNWIN+1)-2
     $         + 2*GN2CO                ! + 2*GN2HC + 2*GN2OH

          IF(KS.EQ.1) THEN               ! Mit Konus:
            MLIN(KS)= MLIN(KS) + (GWHC+1)*(GWCO+1)*(GWWIN+1)
            MTAN(KS)= MTAN(KS) + 4
          END IF

          IF(MLIN(KS).GT.MAXLIN)
     $         STOP ' pothco: Parameter MAXLIN ist zu klein !'
          IF(MTAN(KS).GT.MAXTAN)
     $         STOP ' pothco: Parameter MAXTAN ist zu klein !'

c          WRITE(6,'(/A,I2,A,2(/A,I5))') ' Flaeche Nr.', KS,' :',
c     $         ' ANZAHL KOEFFIZIENTEN IM ZAEHLER: MLIN=',MLIN(KS),
c     $         '        ...           IM NENNER: MTAN=',MTAN(KS)

          READ(10,*)
          DO I=1,MLIN(KS)
            READ(10,*) J, KK(I,KS)
            IF(I.NE.J) STOP ' POTHCO: INDEX FALSCH '
          END DO
          READ(10,*)
          DO I=1,MTAN(KS)
            READ(10,*) J, AA(I,KS)
            IF(I.NE.J) STOP ' POTHCO: INDEX FALSCH '
          END DO

        END DO

C       CLOSE(10)

        POTHCO= 0d0
C       GOTO 999                        ! ******** Ausgang ******

      ELSE

C       ******************************
C       *                            *
C       *  Potentialwert berechnen   *
C       *                            *
C       ******************************

C****   > Koordinaten nach (RHCI,RCOI,RCOSI) kopieren und skalieren:
        RHCI= RHC                                      ! interne Kopien.
        RCOI= RCO
        RCOSI= RCOS
        VPLUS= 0D0                                     ! Potential-Offset.

C**     > **** r_hc und r_co skalieren *****
        THY= TANH(1.1d0*(RHCI-4.4d0))                  ! innen -1, aussen 1.
        A= 0.75d0 - 0.25d0 * THY                       ! innen 1, aussen 1/2.
        AHC= 1d0 + (-0.002d0 + 0.014d0 * RCOSI ) * A   ! Skalierung in R_HC.
        ACO= 1d0 +         0.012d0           * A       ! Skalierung in R_CO.
        RHCI= AHC * (RHCI-2.11d0) + 2.11d0
        RCOI= ACO * (RCOI-2.23d0) + 2.23d0
        VPLUS= ( 0.5d0 * THY - 0.5d0 ) * 50d-3 / 27.2116d0 ! innen -50 meV.
C
C       bei gamma= 120 Grad ( cos()=-0.5, etwa Potentialminimum ) gilt:
C         AHC= 1 - 0.009 = 0.991   (innen, aussen die halbe Verzerrung)
C         ACO= 1 + 0.012 = 1.012   (            "            )
C
C       bei gamma= 0 Grad ( O-H Seite ) gilt:
C         AHC= ACO = 1.012 innen (1.006 aussen) .
C

C**     > Datenbereich einschraenken:
        RHCI= MAX(RHCI,1.3d0)            ! R_HC > 1.3 a.u.
        RCOI= MAX(RCOI,1.5d0)            ! R_CO > 1.5 a.u.
C	  Write(6,*) "About to Sqrt"
        ROHI= SQRT( RHCI**2 + RCOI**2 - 2d0*RHCI*RCOI*RCOSI )
C	  Write(6,*) "Finished the Sqrt"
        ROHI= MAX(ROHI,0.01d0)          ! zur numerischen Stabilitaet.

        KS= ISTATE
        IF(.NOT.QINIT(KS))
     $     STOP 'POTHCO: Flaeche nicht initialisiert !'

C****   > ALLE NENNER BERECHNEN:
        JJ= 1                           ! Index in AA(JJ,KS) (Nenner).

C      QQ1=(1d0,0d0)                     ! *** QQ_HC(R_HC)
C      PHC= 1d0
C      DO J=1,GN2HC
C        PHC= PHC * ( RHCI - NUHC(J) )   ! P_{HC,J}(R_HC)
C        QQ1= QQ1 + DCMPLX( AA(JJ,KS)*PHC, AA(JJ+1,KS)*PHC )
C        JJ= JJ + 2
C      END DO

        QQ2=(1d0,0d0)                   ! *** QQ_CO(R_CO)
        PCO= 1d0
        DO J=1,GN2CO
          PCO= PCO * ( RCOI - NUCO(J) ) ! P_{CO,J}(R_CO)
          QQ2= QQ2 + DCMPLX( AA(JJ,KS)*PCO, AA(JJ+1,KS)*PCO )
          JJ= JJ + 2
        END DO

C      QQ3=(1d0,0d0)                     ! *** QQ_OH(R_OH)
C      POH= 1d0
C      DO J=1,GN2OH
C        POH= POH * ( ROHI - NUHC(J) )   ! P_{OH,J}(R_OH)
C        QQ3= QQ3 + DCMPLX( AA(JJ,KS)*POH, AA(JJ+1,KS)*POH )
C        JJ= JJ + 2
C      END DO

        QQ4=(1d0,0d0)                   ! *** QQ_HCO(R_HC,R_CO,COS())
        PHC= 1d0
        DO J=0,GNHC
          PCO= PHC
          DO K=0,GNCO
            PCOS= PCO
            IF(J.GT.0.OR.K.GT.0) THEN
              QQ4= QQ4 + DCMPLX( AA(JJ,KS)*PCO, AA(JJ+1,KS)*PCO )
C		Write(6,*) "AA(JJ,KS),AA(JJ+1,KS) =",AA(JJ,KS),"  ",AA(JJ+1,KS)
C		Write(6,*) "ABS(QQ4)**2 =",ABS(QQ4)**2
              JJ= JJ + 2
            END IF
            DO L=1,GNWIN
              PCOS= PCOS * ( RCOSI - NUCOS(L) )
              QQ4= QQ4 + DCMPLX( AA(JJ,KS)*PCOS, AA(JJ+1,KS)*PCOS )
C		Write(6,*) "PCOS,RCOSI,NUCOS(L) =",PCOS,"  ",RCOSI,"  ",NUCOS(L)
C		Write(6,*) "AA(JJ,KS),AA(JJ+1,KS) =",AA(JJ,KS),"  ",AA(JJ+1,KS)
C		Write(6,*) "ABS(QQ4)**2 =",ABS(QQ4)**2

              JJ= JJ + 2
            END DO
            PCO= PCO * ( RCOI - NUCO(K+1) )
          END DO
          PHC= PHC * ( RHCI - NUHC(J+1) )
        END DO

C	Write(6,*) "ABS(QQ4)**2 =",ABS(QQ4)**2

C                                       ! *** konische Durchschneidung
        IF(KS.EQ.1) THEN
          RHCCOS= RHCI * RCOSI              ! R_HC * cos(gamma)
          RHCSIN= RHCI * SQRT(1d0-RCOSI**2) ! R_HC * sin(gamma)
          A= 1D0 + AA(JJ+1,KS)*RHCCOS                   ! 1 + a2*RHCCOS +
     $      + ( AA(JJ+2,KS) + AA(JJ+3,KS)*RCOI ) * RCOI ! + a3*RCOI+a4*RCOI**2
          WURZ= SQRT( A**2 + (AA(JJ,KS)*RHCSIN)**2 + WURADD ) ! WURADD ist PARAMETER.
C	Write(6,*) "A,AA(JJ,KS),RHCSIN,WURADD =",A,"  ",AA(JJ,KS),"  ",
C    $    RHCSIN,"  ",WURADD
C	Write(6,*) "WURZ = ",WURZ
          JJ= JJ + 4
        END IF


        IF(JJ.NE.MTAN(KS)+1) STOP 'POTHCO: MTAN FALSCH !'


C**     > ALLE BRUECHE ZUSAMMENRECHNEN:
        LL= 1

C      PQ= KK(LL,KS)                      ! Konstante ALPHA, 3 einzelne Teilchen.
C      LL= LL + 1
        PQ= EASYM
C	  Write(6,*) "PQ =",PQ
C      PHC= RHCI**IX2HC / ABS(QQ1)**2     ! *** PP_HC(R_HC)
C      DO J=0,GZ2HC
C        PQ= PQ + KK(LL,KS) * PHC
C        LL= LL + 1
C        PHC= PHC * ( RHCI - NUHC(J+1) ) ! P_{HC,J}(R_HC)
C      END DO
        PQ= PQ + V2CH(RHCI)
C	  Write(6,*) "PQ =",PQ


        PCO= RCOI**IX2CO / ABS(QQ2)**2  ! *** PP_CO(R_CO)
        DO J=0,GZ2CO
          PQ= PQ + KK(LL,KS) * PCO
          LL= LL + 1
          PCO= PCO * ( RCOI - NUCO(J+1) ) ! P_{CO,J}(R_CO)
        END DO


C      POH= ROHI**IX2OH / ABS(QQ3)**2     ! *** PP_OH(R_OH)
C      DO J=0,GZ2OH
C        PQ= PQ + KK(LL,KS) * POH
C        LL= LL + 1
C        POH= POH * ( ROHI - NUHC(J+1) ) ! P_{OH,J}(R_OH)
C      END DO
        PQ= PQ + V2OH(ROHI)
C	  Write(6,*) "PQ =",PQ


        NENN= RHCI**(IXHC-IXOH) * RCOI**(IXCO-IXOH) * ROHI**IXOH
     $       / ( ABS(QQ4)**2 + NENADD ) ! *** PP_HCO(R_HC,R_CO,COS())
C	Write(6,*) "NENN =",NENN
C	Write(6,*) "NENADD =",NENADD
C	Write(6,*) "RHCI,RCOI,ROHI =",RHCI,"  ",RCOI,"  ",ROHI
C	Write(6,*) "IXHC,IXOH,IXCO =",IXHC,IXOH,IXCO
C	Write(6,*) "ABS(QQ4)**2 =",ABS(QQ4)**2
        KONUS= 0d0                      ! Konische Durchschneidung:
        IF(KS.EQ.1) THEN                ! (nur auf 1. Flaeche)
          PHC= WURZ * NENN
C		Write(6,*) "PHC,WURZ,NENN =",PHC,"  ",WURZ,"  ",NENN
          DO J=0,GWHC
            PCO= PHC
            DO K=0,GWCO
              PCOS= PCO
              DO L=0,GWWIN
                KONUS= KONUS + KK(LL,KS) * PCOS
C	 Write(6,*) "KONUS,KK(LL,KS),PCOS =",KONUS,"  ",KK(LL,KS),"  ",PCOS
                LL= LL + 1
                PCOS= PCOS * ( RCOSI - NUCOS(L+1) )
              END DO
              PCO= PCO * ( RCOI - NUCO(K+1) )
            END DO
            PHC= PHC * ( RHCI - NUHC(J+1) )
          END DO
          PQ= PQ + KONUS
        END IF
C	Write(6,*) "PHC,PCO,PCOS =",PHC,"  ",PCO,"  ",PCOS
C	Write(6,*) "PQ =",PQ

        PHC= NENN
        DO J=0,GZHC                     ! normale Polynome:
          PCO= PHC
          DO K=0,GZCO
            PCOS= PCO
            DO L=0,GZWIN
              PQ= PQ + KK(LL,KS) * PCOS
              LL= LL + 1
              PCOS= PCOS * ( RCOSI - NUCOS(L+1) )
            END DO
            PCO= PCO * ( RCOI - NUCO(K+1) )
          END DO
          PHC= PHC * ( RHCI - NUHC(J+1) )
        END DO

        IF(LL.NE.MLIN(KS)+1) STOP ' POTHCO: MLIN FALSCH '


c      WRITE(6,'(A,2F6.2,F6.1, A,4G9.2,A,F10.2,F10.4)')
c     $        ' R=',RHCI, RCOI, ACOS(RCOSI)/3.14159*180d0,
c     $       ' Ne:',
c     $       ABS(QQ1)**2, ABS(QQ2)**2, ABS(QQ3)**2, ABS(QQ4)**2,
c     $       ' KO,V[eV]=',KONUS*AU2EV,PQ*AU2EV

C**     > Potential abschliessend justieren:

C        PQ= PQ + 0.0529d0/AU2EV + VPLUS        ! OFFSET(Oct.1994)
        PQ= PQ + 0.055d0/AU2EV + VPLUS         ! OFFSET(Dez.1994)
C	  Write(6,*) "PQ =",PQ

C       > kritische Bereich auf mindestens 6 eV begrenzen:
        IF (ROHI.LT.1.1d0.OR.RHCI.LT.1.3d0.OR.
     $       RCOI.LT.1.5d0.OR.RCOI+ROHI.LT.2.9d0) THEN
          PQ= MAX( 6d0/AU2EV, PQ )      ! >= 6 eV.
        END IF
        POTHCO= MIN( 20d0/AU2EV, PQ )   ! nach oben begrenzen (20eV)

      END IF

 999  RETURN
      END
C*************************************************************
C
      FUNCTION V2OH(R)
C
C  Lit:
C  P. Huxley and J. N. Murell, J. Chem. Soc., Faraday Trans. 2, 79, 323 (1983)
C  K.P.Huber and G.Herzberg, "Molecular Spectra and Nolecular Structure,
C      vol. 4, Constants of Diatomic Molecules"
C      (Van Nostrand Reinhold, New York, 1979)
C  D.H.Mordaunt, M.N.R.Ashfort and R.N. Dixon, J.Chem.Phys, 100, p7360 (1994)
C

      IMPLICIT NONE
      REAL*8
     $     V2OH,                        ! O-H-Potential in a.u.         OUTPUT
     $     R                            ! O-H-Abstand in a.u.           INPUT

C**   > KONSTANTEN:
      REAL*8 AU2ANG, AU2EV
      PARAMETER(AU2ANG=0.529177D0)      ! a_0 / ANGSTROEM
      PARAMETER(AU2EV=27.2116D0)        ! HARTREE / EV

C**   > PARAMETER ZUM EXTENDED RYDBERG-POTENTIAL:
      REAL*8 A1, A2, A3, DE, RE, RHO

C     O-H POTENTIAL:  Ang. -> EV
C     ==============
      A1= 4.507                    ! Huxley etc. nach Daten aus Herzberg.
      A2= 4.884
      A3= 3.795
      DE= 4.621 / AU2EV
      RE= 0.9696

C      A1= 4.7665                 ! Mordaunt, Ashfort and Dixon
C      A2= 6.5122
C      A3= 5.9014
C      DE= 4.6210 / AU2EV
C      RE= 0.96966

      RHO= ( R*AU2ANG - RE )

      V2OH= -DE *
     $     ( 1 + A1*RHO + A2*RHO**2 + A3*RHO**3 ) *
     $     EXP(-A1*RHO)

      RETURN
      END
C***********************************************************
C
      FUNCTION V2CH(R)
C
C  Lit:
C  P. Huxley and J. N. Murell, J. Chem. Soc., Faraday Trans. 2, 79, 323 (1983)
C  K.P.Huber and G.Herzberg, "Molecular Spectra and Nolecular Structure,
C      vol. 4, Constants of Diatomic Molecules"
C      (Van Nostrand Reinhold, New York, 1979)
C

      IMPLICIT NONE
      REAL*8
     $     V2CH,                        ! C-H-Potential in a.u.         OUTPUT
     $     R                            ! C-H-Abstand in a.u.           INPUT

C**   > KONSTANTEN:
      REAL*8 AU2ANG, AU2EV
      PARAMETER(AU2ANG=0.529177D0)      ! a_0 / ANGSTROEM
      PARAMETER(AU2EV=27.2116D0)        ! HARTREE / EV

C**   > PARAMETER ZUM EXTENDED RYDBERG-POTENTIAL:
      REAL*8 A1, A2, A3, DE, RE, RHO

C     C-H Potential:  Ang. -> eV
C     ==============
      A1= 3.836
      A2= 3.511
      A3= 2.268
      DE= 3.631 / AU2EV
      RE= 1.1199

      RHO= ( R*AU2ANG - RE )

      V2CH= -DE *
     $     ( 1 + A1*RHO + A2*RHO**2 + A3*RHO**3 ) *
     $     EXP(-A1*RHO)

      RETURN
      END


c *********************  Mail Program Here  ***************
!	PROGRAM	HCO
!	Real*8 POTHCO
!	call pot3in()
!
!	Write(6,*) POTHCO(2.1159223d0, 2.2538912d0, -0.6053381d0,1)
!	Stop
!	End Program HCO
