module shell
  implicit none
  real,parameter::total=8
  integer,parameter::coff=1561
  integer,parameter ::wp=selected_real_kind(12,300)
  !real,parameter::alpha(4)=(/2.0,2.0,2.0,2.0/)
  real(kind=wp)::cof(coff),power(coff,6)
contains
subroutine pes_init()
   integer::i
   open(112,status='old',file='coeff8')
   open(113,status='old',file='index8')

   read(112,*)
   do i=1,coff
     read(112,*) cof(i)
!	 If(i.lt.10) write(6,*) cof(i)
   end do
   do i=1,coff
     read(113,*) power(i,1),power(i,2),power(i,3),power(i,4),power(i,5),power(i,6)
!	 If(i.lt.10) write(6,*)  power(i,1),power(i,2),power(i,3),power(i,4),power(i,5),power(i,6)
   end do
   close(113)
   close(112)

   return
 end subroutine pes_init

 function getpot(cood)
   implicit none
   integer::i
   real(kind=wp)::f,V,getpot
   real(kind=wp)::cood(3,4),com(3)  
   real(kind=wp)::y(6),r(6)
   real(kind=wp)::bas(coff)
   real*8 smallCH, smallOH
   real*8 S, x,z,x3,x2,z1,z2
!	This probram expects cood to be in the order C,O,H,H
   write(6,*) 'C ', (cood(i,1) ,i=1,3)
   write(6,*) 'O ', (cood(i,2) ,i=1,3)
   write(6,*) 'H ', (cood(i,3) ,i=1,3)
   write(6,*) 'H ', (cood(i,4) ,i=1,3)

    
   call edis(r(1),y(1),cood(:,3),cood(:,4))
   call edis(r(2),y(2),cood(:,2),cood(:,3))
   call edis(r(3),y(3),cood(:,1),cood(:,3))
   call edis(r(4),y(4),cood(:,1),cood(:,4))
   call edis(r(5),y(5),cood(:,2),cood(:,4))
   call edis(r(6),y(6),cood(:,1),cood(:,2))


   call basis(bas,y)

    if (r(3)< r(4)) then
       smallCH=r(3)	
       smallOH=r(2)
   else
       smallCH=r(4)
       smallOH=r(5)
    end if

! Switching function has been used here |
       x=r(1)
       z=x-8
       z1=10-8
       z2=z/z1
      x2=z2*z2
      x3=x2*z2

     if (x.ge. 10 ) then
         s=1.0
     else if (x.le. 8 ) then
         s=0.0d0
     else
         s=10*x3-15*x3*z2+6*x3*x2
     end if

     f=0
     do i=1,coff
        f=f+cof(i)*bas(i)
     end do
     f=f+114.332958863-1.059892782251382E-004

    if (x .ge. 8) then
       call hcopot(V,smallCH,r(6),smallOH)
       f= f*(1-s)+V*s
     end if 
!..................................................................|
 
    getpot=f
   return
 end function getpot

 subroutine edis(dis,edist,atomi,atomj)
   real(kind=wp)::atomi(3),atomj(3)
   real(kind=wp)::dis,alfa
   real(kind=wp),intent(out)::edist
   alfa=2.0
   dis=sqrt((atomi(1)-atomj(1))**2+(atomi(2)-atomj(2))**2+(atomi(3)-atomj(3))**2)
   edist=exp(-dis/alfa)
   return
 end subroutine edis

 subroutine basis(bas,y)
   integer m,n,p,q,i,j,k
   real(kind=wp)::bas(coff)
   real(kind=wp)::y(6)
   do k=1,coff
     bas(k)=(y(1)**power(k,1))*(y(6)**power(k,6))*((y(2)**power(k,2))*(y(3)**power(k,3))*(y(4)**power(k,4))*(y(5)**power(k,5))+(y(2)**power(k,5))*(y(3)**power(k,4))*(y(4)**power(k,3))*(y(5)**power(k,2)))
   end do
   return
 end subroutine



end module shell
!
!	***********************************************************************
!	***********************************************************************
!	Main program starts here
program main
	use shell
	real*8 coordlong(12),V
	call pes_init()

!  order of atoms expected is C, O,  H, H
		coordlong(7)= 2.250177405118508
		coordlong(8)= 1.7653861568698004
		coordlong(9)= 0.

		coordlong(4)= -1.1435386637561427
		coordlong(5)= 0.
		coordlong(6)= 0.

		coordlong(1)= 1.146269431829208
		coordlong(2)= 0.
		coordlong(3)= 0.

		coordlong(10)= coordlong(7)
		coordlong(11)= -coordlong(8)
		coordlong(12)= 0.

		V=getpot(coordlong)
		Write(6,*) 'V = ', V

!	second example
		coordlong(1)=0.13816352/0.529177
		coordlong(2)=0.08353517/0.529177
		coordlong(3)=0.68896560/0.529177
		coordlong(4)=-0.21397824/0.529177
		coordlong(5)=-0.04515096/0.529177   
		coordlong(6)=-0.63395658/0.529177
		coordlong(7)=0.43917937/0.529177   
		coordlong(8)=-1.10756533/0.529177    
		coordlong(9)=0.89917993/0.529177
		coordlong(10)=1.31172117/0.529177    
		coordlong(11)=0.82950497/0.529177    
		coordlong(12)=0.95877568/0.529177

		V=getpot(coordlong)
		Write(6,*) 'V = ', V


		Stop



end program main
