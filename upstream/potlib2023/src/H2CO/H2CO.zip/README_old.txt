This program calculates the H2CO potential using the surface described in
X. Wang, P. L. Houston, and J. M. Bowman, "A new (multi-reference configuration interaction) potential energy surface for H2CO and preliminary studies of roaming," Phil. Trans. Roy. Soc. A375, 20160194, http://dx.doi.org/10.1098/rsta.2016.0194.

The MAIN program, in pes_shell.f90 shows how to call the potential, given a list of corrdinates (and shows what order is expected).  

The input is in bohr
the output is in hartree

The output of the program (two examples) should be

 C    1.14626943182921       0.000000000000000E+000  0.000000000000000E+000
 O   -1.14353866375614       0.000000000000000E+000  0.000000000000000E+000
 H    2.25017740511851        1.76538615686980       0.000000000000000E+000
 H    2.25017740511851       -1.76538615686980       0.000000000000000E+000
 V =  -3.173133649170268E-006
 C   0.261091317271915       0.157858655988450        1.30195681218194
 O  -0.404360431386852      -8.532298266931480E-002  -1.19800478856791
 H   0.829929059653008       -2.09299597299202        1.69920448167626
 H    2.47879475109462        1.56753783705641        1.81182417225238
 V =   0.118666057409911


In the first example, the input is the Global Minimum geometry, so the output is nearly 0
In the second example, the input is far from equilibrium, and the output is
0.11866 hartree, or about 26045 wavenumbers.