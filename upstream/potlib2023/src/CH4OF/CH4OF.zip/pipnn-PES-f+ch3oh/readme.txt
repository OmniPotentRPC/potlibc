!********************************************************************** 
!   System:                     CH4OF
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                CH4OF
!   Number of derivatives:      0 
!   Number of bodies:           7
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: 
!   “Feshbach resonances in the exit channel of the F + CH3OH → HF + CH3O 
!   reaction via transition state spectroscopy”,
!   Marissa L. Weichman, Jessalyn A. DeVine, Mark C. Babin, Jun Li*,
!   Lifen Guo, Jianyi Ma, Hua Guo, and Daniel M. Neumark*, 
!   Nature Chemistry, 2017, 9, 950-955.
!
!   "Rate Coefficients and Branching Ratio for Multi-Channel Hydrogen 
!    Abstractions from CH3OH by F"
!   Dandan Lu, Changjian Xie, Jun Li*, and Hua Guo*,
!   Chinese Journal of Chemical Physics, 2019, 32, 84-88
!
!   "Stereodynamical Control of Product Branching in Multi-Channel Barrierless 
!   Hydrogen Abstraction of CH3OH by F"
!   Dandan Lu , Jun Li*, and Hua Guo*,
!   Chemical Science, 2019, 10, 7994-8001
!
!   Notes: see below
!
!**********************************************************************

****************************************************************************
* PIP-NN PES for F + CH3OH system at CCSD(T)-F12a/AVDZ level
* Reference: Nature Chemistry, 2017, 9, 950-955;
*            Chinese Journal of Chemical Physics, 2019, 32, 84-88;
*            Chemical Science, 2019, 10, 7994-8001
****************************************************************************
                            
These files are for the PES of F + CH3OH reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: h4cfo-pipnn.f

To use this PES, as shown in the main.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call fch3ohpipNN(ct,vpes)
     where,
       ct: XYZ cartesian coordinate in HHHHCFO order and angstrom unit, shown in test-fch3oh.xyz.
       vpes:  the potential energy(in eV) relative to the reactant asymptote.
