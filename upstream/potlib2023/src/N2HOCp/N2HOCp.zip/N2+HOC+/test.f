        implicit real*8(a-h,o-z)
        dimension r(6),coord(3,5)
        character fn*20
        ndim=10
        call pes_init

        open(1,file='test.in',status='old')
        open(2,file='test.out',status='unknown')
        read(1,*)fn,(coord(j,1),j=1,3)
        read(1,*)fn,(coord(j,2),j=1,3)
        read(1,*)fn,(coord(j,3),j=1,3)
        read(1,*)fn,(coord(j,4),j=1,3)
        read(1,*)fn,(coord(j,5),j=1,3)
        r(1)=distance(coord(:,1),coord(:,2))
        r(2)=distance(coord(:,1),coord(:,3))
        r(3)=distance(coord(:,1),coord(:,4))
        r(4)=distance(coord(:,1),coord(:,5))
        r(5)=distance(coord(:,2),coord(:,3))
        r(6)=distance(coord(:,2),coord(:,4))
        r(7)=distance(coord(:,2),coord(:,5))
        r(8)=distance(coord(:,3),coord(:,4))
        r(9)=distance(coord(:,3),coord(:,5))
        r(10)=distance(coord(:,4),coord(:,5))
        call N2CHOpipNN(r,vpes,vpesa,vpesb,vpesc)
        write(2,'(11f15.8)')(r(i),i=1,ndim),vpes
        close(1)
        close(2)
        end

        double precision function distance(a,b)
        implicit real*8(a-h,o-z)
        dimension a(3),b(3)

        distance=0.d0
        do i=1,3
        distance=distance+(a(i)-b(i))**2
        enddo
        distance=dsqrt(distance)

        return
        end
 
