!********************************************************************** 
!   System:                     ClH2O
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                ClH2O
!   Number of derivatives:      0
!   Number of bodies:           4
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: J. Li, R. Dawes, and H. Guo “Kinetic and dynamic studies of
!   the Cl(2Pu) + H2O(X1A1) → HCl (X1S+) + OH(X2P) reaction on an ab initio
!   based full-dimensional global potential energy surface of the ground
!   electronic state of ClH2O”, J. Chem. Phys., 139, 074302 (2013).
!   J. Li, H. Song, H. Guo “Insights into the bond-selective reaction of Cl
!   + HOD (nOH) → HCl + OD”,  Phys. Chem. Chem. Phys., 17, 4259 (2015).
!
!   Notes: see below
!
!   H  ct(1,1) ct(2,1) ct(3,1)
!   H  ct(1,2) ct(2,2) ct(3,2)
!   Cl ct(1,3) ct(2,3) ct(3,3)
!   O  ct(1,4) ct(2,4) ct(3,4)
!
!   Input: ct(3,4)                            in units of Angstrom
!   Output: vpes,vpesa,vpesb,vpesc            in units of eV 
!           vpes=(vpesa+vpesb+vpesc)/3.0d0
!
!**********************************************************************


