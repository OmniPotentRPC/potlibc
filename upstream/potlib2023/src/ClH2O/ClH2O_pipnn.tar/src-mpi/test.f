
      program main
      use nnparam
      implicit none
      integer,parameter::ndata=22245
      integer i,j,k,l,m,n,n1
      character*100 asymb
      real*8 v1,v2,v3,vab,vfit,rmse,errmax,rbasis(17)
      real*8 va,vb,vc
      real*8 c1(3,4),c2(3,4),jcb(6),ct(3,4),bt(6),vec(3,6)

      call pes_init

      call HOHCl_pes_interface(c1,vfit)
      end program main

