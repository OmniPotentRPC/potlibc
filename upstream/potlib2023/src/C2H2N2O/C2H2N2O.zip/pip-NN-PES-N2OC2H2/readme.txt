!********************************************************************** 
!   System:                     C2H2N2O
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                C2H2N2O
!   Number of derivatives:      0
!   Number of bodies:           7
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: 
!   “Quantitative Dynamics of the N2O + C2H2 → Oxadiazole Reaction: 
!   A Model for 1,3-Dipolar Cycloadditions”,
!   Yang Liu, Jun Li*, ACS Omega, 2020, 5, 23343-23350.
!
!   Notes: see below
!
!**********************************************************************

****************************************************************************
* PIP-NN PES for N2O + C2H2 system at CCSD(T)-F12a/AVDZ level.
* Reference: ACS Omega, 2020, 5, 23343-23350.
****************************************************************************
                            
These files are for the PES of N2O + C2H2 reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: pipnn.f

To use this PES, as shown in the interface.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call evvdvdx(xct,v)
     where,
       xct:    XYZ cartesian coordinate in HHCCNNN order and angstrom unit.
       vpes:   the potential energy(in eV)
