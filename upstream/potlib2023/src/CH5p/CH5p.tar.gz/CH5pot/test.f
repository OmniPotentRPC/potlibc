       program test

      implicit real*8 (a-h,o-z)
      parameter (natom = 6)
      parameter (nwalk = 1)
      double precision, dimension(nwalk,natom,3) :: x
      double precision, dimension(natom,3) :: xx
      double precision, dimension(nwalk) :: v,v0
      integer i,j,tmp
      character(len=1), dimension(natom) :: sym

      open(unit=10,file='C2v.xyz')
      read(10,*) tmp
      read(10,*) v0(1)
      do i=1,natom
      read(10,*) sym(i), xx(i,1),xx(i,2),xx(i,3)
      enddo

      do i=1,natom
      do j=1,3
      x(1,i,j)=xx(i,j)/0.5291772083d0
      enddo
      enddo

      call mycalcpot(x,nwalk,v)

      write(*,*) "v(1) ",v(1)

      end program test
