       program main    
       use nnparam
       implicit none
       real*8 vpes,vpesa,vpesb,vpesc,rmse,rmse1,rmse2,rmse3
       integer,parameter::ndata=1
       integer i
       real*8 vab,verr
       character*80 asymb(7)
       real*8 ct(3,natom)
       call pes_init
       open(11,file='test-clch3oh.xyz',status='old')
       open(21,file='test.out')
       do i=1,ndata
         read(11,*)
         read(11,*)vab
         read(11,*)asymb(1),ct(:,1)
         read(11,*)asymb(2),ct(:,2)
         read(11,*)asymb(3),ct(:,3)
         read(11,*)asymb(4),ct(:,4)
         read(11,*)asymb(5),ct(:,5)
         read(11,*)asymb(6),ct(:,6)
         read(11,*)asymb(7),ct(:,7)
         vab=(vab-vpesmin)*27.2114d0
         call clch3ohpipNN(ct,vpes)
         verr=vab-vpes
         write(21,'(3f15.8)')vab,vpes,verr
       enddo
      end program
