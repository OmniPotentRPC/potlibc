!********************************************************************** 
!   System:                     CH4OCl
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                CH4OCl
!   Number of derivatives:      0 
!   Number of bodies:           7
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: 
!   “Comprehensive Dynamical Investigations on the Cl + CH3OH → HCl + 
!   CH3O/CH2OH Reaction: Validation of Experiment and Dynamics Insights”, 
!   Dandan Lu, Jun Li*, and Hua Guo*, 
!   CCS Chemistry, 2020, 2, 882-894
!
!   Notes: see below
!
!**********************************************************************

****************************************************************************
* PIP-NN PES for Cl + CH3OH system at CCSD(T)-F12a/AVTZ level
* Reference: CCS Chemistry, 2020, 2, 882-894
*            https://www.chinesechemsoc.org/doi/10.31635/ccschem.020.202000195
****************************************************************************
                            
These files are for the PES of Cl + CH3OH reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: h4cfo-pipnn.f

To use this PES, as shown in the main.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call clch3ohpipNN(ct,vpes)
     where,
       ct: XYZ cartesian coordinate in HHHHCClO order and angstrom unit, shown in test-clch3oh.xyz.
       vpes:  the potential energy(in eV) relative to the reactant asymptote.
