program main
  use pes_shell
  implicit none
  real,parameter::auang=0.5291772083

  real,dimension(:),allocatable::xx
  character(len=2)::symb
  character(len=32)::filename
  integer::i,natm
  real::pot

  call getarg(1,filename)
  open(21,status='old',file=filename)
  read(21,*) natm
  read(21,*)
  allocate(xx(3*natm))

  do i=1,natm
     read(21,*) symb,xx(i*3-2:i*3)
  end do
  xx=xx/auang
  call pes_init()

  pot=f(xx)

  write(*,'(A,E)') "POT (hartree) =",pot


end program main

