module pes_shell
  use constants
  implicit none

contains
  !=================================================!
  ! Initializing HBB water potential                !
  !=================================================!
  subroutine pes_init()

    ! 2-body init
    call prepot('./coefs/h4o2.pes4.coeff.dat')
    call predip('./coefs/h4o2.dms4.coeff.dat')

    return
  end subroutine pes_init

  !==================================================!
  ! water dipole moment                              !
  !==================================================!
  subroutine dipole(x,dp)
    ! x(1:18) cartesian coordinates in bohr, must in order H H H H O O
    ! dp(3): dipole, in atomic unit
    real,dimension(:),intent(in)::x
    real,dimension(3),intent(out)::dp
    ! ::::::::::::::::::::
    real,dimension(3,6)::xn
    real,dimension(6)::chg
    integer::natm

    xn = reshape(x,(/3,6/))
    call calcdip(dp,chg,xn)

    return
  end subroutine dipole

  !==================================================!
  ! water potential                                  !
  !==================================================!
  function f(x)
    ! x(1:18) Cartesian coordinates in bohr, must in order H H H H O O
    ! f: potential in hartree
    real,dimension(:),intent(in)::x
    ! ::::::::::::::::::::
    real,dimension(3,6)::xn
    real::pot,f

    xn = reshape(x,(/3,6/))
    call calcpot(pot,xn)
    f = pot

    return
  end function f

end module pes_shell
