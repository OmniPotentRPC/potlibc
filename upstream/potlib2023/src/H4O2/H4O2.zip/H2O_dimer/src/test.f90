program main
  use pes_shell
  implicit none

  real,dimension(18)::x
  integer::i,j,natm
  real::pot,dp(3)
  character::symb

  call pes_init()

  read(*,*) natm
  read(*,*)
  do j=1,natm
     read(*,*) symb,x(j*3-2:j*3)
  end do
  x=x/auang

  pot=f(x)
  call dipole(x,dp)
  write(*,'(A,F15.8,A)') "potential energy:", pot, " hartree"
  write(*,'(A,3F13.6,A)') "dipole moments:", dp(:), " au"

end program main

