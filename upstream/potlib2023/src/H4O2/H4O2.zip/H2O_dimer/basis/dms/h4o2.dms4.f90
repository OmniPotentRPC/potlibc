        subroutine predip(dname)

        implicit double precision (a-h,o-z)
        implicit integer (i-n)

        character(len=*),intent(in)::dname
        double precision dc0(0:5,0:5),dw0(0:5,0:5), coef(0:2879)

        common/NCOEdip/ms,mr
        common/h4o2coefdip/dc0,dw0,coef

        ms=1827 ; mr=1053

        open(20,file=dname,status='old')
        read(20,*)
        read(20,*)
        read(20,*)(coef(i1),i1=0,ms+mr-1)
        close(20)

        write(*,*) "Initializing H2O-H2O dipole!"
        return
        end

!***************************************************************
        subroutine calcdip(dip,chg,cart)

        implicit none

        integer ms,mr,i
        double precision dc0(0:5,0:5),dw0(0:5,0:5),coef(0:2879)

        common/NCOEdip/ms,mr
        common/h4o2coefdip/dc0,dw0,coef
        double precision V, cart(3,6),dip(1:3),chg(0:5)
        double precision rvec(0:3),d0(0:5,0:5),r0(0:5,0:5)
        double precision vec(0:3,0:2879),chgb(0:5,0:2879)

        call getdvec (ms, mr, cart, vec, chgb)

        do i=0,5
          chg(i)=dot_product(chgb(i,:),coef)
        end do
     
        dip = matmul(cart, chg)

        return
        end subroutine calcdip
