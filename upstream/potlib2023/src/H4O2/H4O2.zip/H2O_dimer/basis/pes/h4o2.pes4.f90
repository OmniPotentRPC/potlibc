        subroutine prepot(dname)

!        implicit none
        implicit double precision (a-h,o-z)
        implicit integer (i-n)

        double precision dc0(0:5,0:5),dw0(0:5,0:5), coef(0:5226)
        character (len=*), intent(in) :: dname


        common/NCOE/ms,mr
        common/h4o2coef/dc0,dw0,coef

        ms=5056 ; mr=57

        open(20,file=dname,status='old')
        read(20,*)
        read(20,*)
        read(20,*)(coef(i1),i1=0,ms+3*mr-1)
        close(20)

        write(*,*) "Initializing H2O-H2O potential!"
        return
        end

!***************************************************************

        subroutine calcpot(V,cart)

        implicit none

        integer ms,mr
        double precision dc0(0:5,0:5),dw0(0:5,0:5),coef(0:5226)

        common/NCOE/ms,mr
        common/h4o2coef/dc0,dw0,coef
        double precision V, cart(3,6)


        double precision rvec(0:3),d0(0:5,0:5),r0(0:5,0:5),vec(0:ms+3*mr-1)
        double precision xnuc(0:2,0:5)

        call getvec (ms, mr, cart, vec)
        V = dot_product(coef,vec)

        return
        end subroutine calcpot

