program getpot
use pes_shell
implicit none

  integer::i,natm
  real,dimension(3,6)::x
  character::symb
  real::v

  read(*,*) natm
  read(*,*) 
  do i=1,natm
     read(*,*) symb,x(:,i)
  end do
  x = x / auang

  ! initialize the potential
  call prepot()

  ! call the potential
  call calcpot(v,x)

  write(*,*) "pot=",v

end program
