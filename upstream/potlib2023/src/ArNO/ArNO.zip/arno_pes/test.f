        include 'arno_pes.f'

        program main
        implicit real*8(a-h,o-z)
        dimension q(9)
        data init/0/
        save init

c Initializations
        if(init.eq.0)then                                              
        call potread
        init=1                                                         
        endif                                                          

        open(61,file='test.txt',status='replace')

        write(61,*)'parallelly compile with "ifort -openmp arno_pes.f"' 

************ A' minimum
        Q(1:3)=(/-2.528060E+00,  1.496618E+00, 0.000000E+00  /)
        Q(4:6)=(/-1.145484E+00, -2.000000E+00, 0.000000E+00  /)
        Q(7:9)=(/-2.289803E+00, -2.136303E+00, 0.000000E+00  /)
        Q=Q/.5291772083d0
        r_ArN=dsqrt((q(1)-q(4))**2+(q(2)-q(5))**2+(q(3)-q(6))**2)
        r_NO=dsqrt((q(7)-q(4))**2+(q(8)-q(5))**2+(q(9)-q(6))**2)
        r_ArO=dsqrt((q(7)-q(1))**2+(q(8)-q(2))**2+(q(9)-q(3))**2)
        cthx=(r_ArN**2+r_NO**2-r_ArO**2)/2d0/r_ArN/r_NO
        call ArNOpes(r_NO,r_ArN,cthx,vtm,vim,1)
        
        Q(1:3)=(/-2.624113E-01,  8.581560E-01,  1.000000E+02/)
        Q(4:6)=(/-1.096034E+00, -2.007092E+00,  1.517793E-14/)
        Q(7:9)=(/-2.248454E+00, -2.007092E+00, -9.170006E-15/)

        Q=Q/.5291772083d0
        r_ArN=dsqrt((q(1)-q(4))**2+(q(2)-q(5))**2+(q(3)-q(6))**2)
        r_NO=dsqrt((q(7)-q(4))**2+(q(8)-q(5))**2+(q(9)-q(6))**2)
        r_ArO=dsqrt((q(7)-q(1))**2+(q(8)-q(2))**2+(q(9)-q(3))**2)
        cthx=(r_ArN**2+r_NO**2-r_ArO**2)/2d0/r_ArN/r_NO
        call ArNOpes(r_NO,r_ArN,cthx,vtd,vim,1)
        
        write(61,*) "De on A' PES (Ref: 86.0856703688702 cm^-1)"
        write(61,*) vtd-vtm

************ A'' minimum
        Q(1:3)=(/-3.210403E-01,  1.235912E-01, 0.000000E+00 /)
        Q(4:6)=(/-1.022375E+00, -3.388187E+00, 0.000000E+00 /)
        Q(7:9)=(/-2.174126E+00, -3.348267E+00, 0.000000E+00 /)

        Q=Q/.5291772083d0
        r_ArN=dsqrt((q(1)-q(4))**2+(q(2)-q(5))**2+(q(3)-q(6))**2)
        r_NO=dsqrt((q(7)-q(4))**2+(q(8)-q(5))**2+(q(9)-q(6))**2)
        r_ArO=dsqrt((q(7)-q(1))**2+(q(8)-q(2))**2+(q(9)-q(3))**2)
        cthx=(r_ArN**2+r_NO**2-r_ArO**2)/2d0/r_ArN/r_NO
        call ArNOpes(r_NO,r_ArN,cthx,vtm2,vim,2)

        Q(1:3)=(/-2.624113E-01,  8.581560E-01,  1.000000E+02/)
        Q(4:6)=(/-1.096035E+00, -2.007092E+00,  1.264833E-14/)
        Q(7:9)=(/-2.248453E+00, -2.007092E+00, -7.272779E-15/)

        Q=Q/.5291772083d0
        r_ArN=dsqrt((q(1)-q(4))**2+(q(2)-q(5))**2+(q(3)-q(6))**2)
        r_NO=dsqrt((q(7)-q(4))**2+(q(8)-q(5))**2+(q(9)-q(6))**2)
        r_ArO=dsqrt((q(7)-q(1))**2+(q(8)-q(2))**2+(q(9)-q(3))**2)
        cthx=(r_ArN**2+r_NO**2-r_ArO**2)/2d0/r_ArN/r_NO
        call ArNOpes(r_NO,r_ArN,cthx,vtd2,vim,2)
        write(61,*) "De on A'' PES (Ref: 82.4874282989917 cm^-1)"
        write(61,*) vtd2-vtm2

        end
