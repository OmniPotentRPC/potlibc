!********************************************************************** 
!   System:                     ArNO
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                ArNO
!   Number of derivatives:      0
!   Number of bodies:           3
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: C. Amarasinghe, H. Li, C. A. Perera, M. Besemer, J. Zuo,
!   C. Xie, A. van der Avoird, G. C. Groenenboom, H. Guo, J. Kłos, and
!   A. G. Suits "State-to-state scattering of highly vibrationally 
!   excited NO at broadly tunable energies"
!   Nat. Chem. 2020, 12, 528-534.
!
!   Notes: see below
!
!**********************************************************************

****************************************************************************
* 1A' and 1A" PESs of ArNO at the MRCI-F12+Q/cc-pVQZ-F12 level.
* Reference: Nat. Chem. 12, 528-534 (2020).
****************************************************************************
                            
These files are for the PES of Ar+N0(X2pi) reaction, including
  1. Ab initio date point: spline.dat
  2. Main fortran file containing subroutines: arno_pes.f

To use this PES, as shown in the test.f, please be sure to do:
  1. Initialization:
       call potread
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call ArNOpes(r_NO,r_ArN,cthx,vtot,vint,istat)
     where,
       r_NO,r_ArN: bond distances in bohr;
       cthx=cos(theta), theta: inter-bond <Ar-N-O> angle;
       vtot: total potential energy of ArNO complex in cm^-1,
             zero point on PESs set at minimum of asymptote Ar+NO on A' PES;
       vint: interaction energy between Ar and NO in cm^-1;
             vint = vtot_(ArNO) - vtot_(Ar + NO)
       istat = 1 for A' PES,
               2 for A" PES,
               others set as 1 for A' PES;
  3. 1D potentials (in cm^-1) of NO A' and A":
       call pes1D(r_NO,v,istat).
