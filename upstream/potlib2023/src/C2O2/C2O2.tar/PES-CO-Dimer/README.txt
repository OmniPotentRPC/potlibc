!********************************************************************** 
!   System:                     C2O2
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                C2O2
!   Number of derivatives:      1 
!   Number of bodies:           4
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: 
!   J. Chen, J. Li, J. M. Bowman, and H. Guo, "Energy transfer between 
!   vibrationally excited carbon monoxide based on a highly accurate
!   six-dimensional potential energy surface"
!   J. Chem. Phys. 153, 054310 (2020).
!
!   Notes: see below
!
!**********************************************************************

2020/7/8
Jun Chen
njuchenjun@gmail.com

I. Description of inputs/outputs of the PES subroutines.
    Two subroutines have been provided in the PES,
    the subroutine pes_ococ(r,v,idv,dvdr) calculates the 6D interaction PES,
    and the subroutine potco(r,v,dv) calculates the PEC of CO.

    All bond distances are in unit of Bohr, and energies in unit of wavenumbers.

    For the subroutine pes_ococ,
        input   real*8  r(6)    interatomic distances, in order of
                                O1-C1, O1-O2, O1-C2, C1-O2, C1-C2, O2-C2;
        output  real*8  v       interaction energy between CO-CO monomers;
        input   integer idv     if idv=1, calculate energy and derivatives;
                                if idv=0, calculate energy only;
        output  real*8  dv(6)   derivatives respective to the interatomic distances.

    For the subroutine potco,
        input   real*8  r       bond length of CO molecule;
        output  real*8  v       the potential energy;
        output  real*8  dv      the derivative.

II. Compiling instructions.
    A BLAS library is required to evaluate the subroutines.

    The parameter file "nn_ococ_w20.txt" should be placed in the working directory,
    or a directory indicated by the keyword "#define ..." in the code.

    Do not change the file extension ".F90" to ".f90",
    otherwise a preprocessor should be run, for example, ifort -fpp ...

    A test program has been provided in test.f90 to compute the interaction
    energy, total energy as well as the derivatives of total energy respective
    to the interatomic distances. A sample Makefile is also included.

      4
      CO-dimer 000005 Cartesian/Angstrom
      O1     0.507464   -5.559636    0.000000
      C1    -0.676403   -4.827579    0.000000
      O2    -0.002646    0.507559   -0.026816
      C2     0.003527   -0.676530    0.035743

    The output should be:

     Interaction Energy / Total Energy (cm-1)
       -76.2 19711.9
     Derivatives (cm-1/Bohr)
     53917.4   -21.9    40.2   -26.8    50.9 23683.8

