program test
  call test1
  call test2
end program

subroutine test1
  implicit none
  real*8 :: c(3,4),r(6),vint,vco1,vco2,vtot
  integer :: i,j,k
  real*8 :: dvdr(6),dvco1,dvco2

  c=reshape([ 0.507464d0,-5.559636d0, 0.000000d0,&
             -0.676403d0,-4.827579d0, 0.000000d0,&
             -0.002646d0, 0.507559d0,-0.026816d0,&
              0.003527d0,-0.676530d0, 0.035743d0],[3,4])
  c=c/0.5291772083d0

  k=0
  do i=1,3
  do j=i+1,4
     k=k+1
     r(k)=dsqrt(dot_product((c(:,i)-c(:,j)),(c(:,i)-c(:,j))))
  enddo
  enddo

  call pes_ococ(r,vint,1,dvdr)
  call potco(r(1),vco1,dvco1)
  call potco(r(6),vco2,dvco2)
  vtot=vint+vco1+vco2
  dvdr(1)=dvdr(1)+dvco1
  dvdr(6)=dvdr(6)+dvco2

  write(*,*)
  write(*,*) "Interaction Energy / Total Energy (cm-1)"
  write(*,'(2f8.1)') vint,vtot
  write(*,*) "Derivatives (cm-1/Bohr)"
  write(*,'(6f8.1)') dvdr
end

subroutine test2
  implicit none
  real*8 :: r(6),vint,dvdr(6),vtot,vco1,dvco1,vco2,dvco2
  !! r: bohr, O1-C1, O1-O2, O1-C2, C1-O2, C1-C2, O2-C2
  !! v: cm-1;  dvdr: cm-1/bohr
  r=[2.63035d0,11.50590d0,9.27699d0,10.16215d0,7.94917d0,2.240755d0]
  call pes_ococ(r,vint,1,dvdr)
  call potco(r(1),vco1,dvco1)
  call potco(r(6),vco2,dvco2)
  vtot=vint+vco1+vco2
  dvdr(1)=dvdr(1)+dvco1
  dvdr(6)=dvdr(6)+dvco2

  write(*,*)
  write(*,*) "Interaction Energy / Total Energy (cm-1)"
  write(*,'(2f8.1)') vint,vtot
  write(*,*) "Derivatives (cm-1/Bohr)"
  write(*,'(6f8.1)') dvdr
end
