****************************************************************************
* PIP-NN PES for K2Rb2 system at UCCSD(T)/aug-cc-pwCVTZ-PP and aug-ccpwCVQZ-
  PP level.
* Reference: J. Phys. Chem. Lett. 2020,  (11), 2605−2610.
****************************************************************************
                            
These files are for the PES of KRb+KRb reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: k2rb2_pes.f

To use this PES, as shown in the test.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call k2rb2_pes_interface(q,vpes)
     where,
       q:    XYZ cartesian coordinate in KKRbRb order and angstrom unit.
       vpes: the potential in cm^-1.
