        include "k2rb2_pes.f"

        program main
        implicit none
        integer :: n 
        character*2 :: atom(4)
        character*5 :: geom
        double precision :: q(3,4),vpes
        double precision :: v_r,vpes_rel

        call pes_init

        n=0 
        open(51,file='test.xyz',status='old')
        open(61,file='test.txt',status='replace')

        write(61,'(7H=======,20H ===================,20H ===============
     $====)')
        write(61,'(A7,2A20)')'Geom','Vpes/cm-1','Vpes_rel/cm-1'
        write(61,'(7H=======,20H ===================,20H ===============
     $====)')

        do while(.true.)
           read(51,*,end=100)
           read(51,*)geom 
           read(51,*)atom(1),q(:,1) !--> K
           read(51,*)atom(2),q(:,2) !--> K
           read(51,*)atom(3),q(:,3) !--> Rb
           read(51,*)atom(4),q(:,4) !--> Rb
           call k2rb2_pes_interface(q,vpes)
           n=n+1 
           if (n.eq.1) then
              v_r=vpes
           endif
           vpes_rel=vpes-v_r  
           write(61,'(A5,4f20.8)')geom,vpes,vpes_rel
        enddo
100     continue
        write(61,'(7H=======,20H ===================,20H ===============
     $====)')
        close(51)
        close(61)

        end program
