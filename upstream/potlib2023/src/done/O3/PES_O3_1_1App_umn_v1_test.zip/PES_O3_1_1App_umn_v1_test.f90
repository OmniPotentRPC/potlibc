      program test
!**********************************************************************
!  Test program to read XYZ coordinates, call a PES subroutine which
!  calculates the energy and gradinets 
!**********************************************************************

       use PES_O3_1_1App_umn_v1, only : pot => pot

      implicit none

      integer i,j,tmp
      double precision E
      double precision X(3),Y(3),Z(3),dEdX(3),dEdY(3),dEdZ(3)

! Conversion factors
! Cconv: bohr to Angstrom
!        1 bohr = 0.52917721092 angstrom
! Econv: kcal/mol to hartree
!        1 kcal/mol = 0.159360144 * 10^-2 hartree
! Gconv: kcal/(mol*Angstrom) to hartree/bohr
!        1 kcal mol^-1 angstrom^-1 = 0.843297564 * 10^-3 hartree/bohr
! EVconv hartree to eV

      double precision,parameter :: Cconv = 0.52917721092d0
      double precision,parameter :: Econv = 0.159360144d-2
      double precision,parameter :: Gconv = 0.843297564d-3
      double precision,parameter :: EVconv = 27.2114d0


! Read coordinates from aaaa.data file
      open(unit=20,file="PES_O3_1_1App_umn_v1.data")
      open(unit=30,file="PES_O3_1_1App_umn_v1.out")

      write(30,*) "index,energy in eV and kcal/mol"
      write(30,*) "gradients in (kcal/mol)/Å and hartree/bohr (after ;)"

      do i=1,2
       read(20,*) tmp
       read(20,*) X(1),Y(1),Z(1)
       read(20,*) X(2),Y(2),Z(2)
       read(20,*) X(3),Y(3),Z(3)
       do j=1,3
        X(j)=X(j)/Cconv
        Y(j)=Y(j)/Cconv
        Z(j)=Z(j)/Cconv
       enddo
       call pot(X,Y,Z,E,dEdX,dEdY,dEdZ)
       write(30,'(I3,2F18.6)') i,E*EVconv,E/Econv
       do j=1,3
        write(30,'(3F12.6,a,3F12.6)') dEdX(j)/Gconv,dEdY(j)/Gconv,&
        dEdZ(j)/Gconv," ; ",dEdX(j),dEdY(j),dEdZ(j) 
       enddo
      enddo
      close(unit=20)
      close(unit=30)

      end

