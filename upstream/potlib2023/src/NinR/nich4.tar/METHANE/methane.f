      PROGRAM DRIVER
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION XC(30),DX(30)

       WRITE (*,*) 'Calculating energy.  One moment please ...'

       OPEN (10, FILE = "geom")
       READ (10,*) NINPATS

       DO 10 N = 1,NINPATS*3,3
        READ(10,*) XC(N), XC(N+1), XC(N+2)

10     CONTINUE
       CLOSE (10)
        CALL SETUP(NINPATS*3)
       E = 0.0

       CALL SURF (E,XC, DX, NINPATS*3)
        WRITE (9,*) 'Cartesians:'
        DO 12 N = 1,NINPATS*3,3
         WRITE (9,20) XC(N), XC(N+1), XC(N+2)
12      CONTINUE
        WRITE (9,*) 'Derviatives:'
        DO 13 N = 1,NINPATS*3,3
         WRITE (9,21) DX(N), DX(N+1), DX(N+2)
13      CONTINUE
        WRITE (9,'(A,F10.6,A)') 'Energy = ',E*627.5095,' kcal/mol'

        WRITE (*,*) 'Done.  Results in fort.9'
20      FORMAT (3F8.3)
21      FORMAT (1P3E12.3)
22      FORMAT (F12.6)


      END



      SUBROUTINE SETUP(NCRDM) 
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)

C  This is the PES for CH4 interaction with Ni surface.  It is a 
C    combination of the J1 surface and the EAM6 surface.
C    J1 reference:  T. Joseph, R. Steckler, and D.G. Truhlar, J. Chem. Phys. 
C                   87, 7036-7049 (1987).
C                   R. Steckler, K.J. Dykema, F.B. Brown, G.C. Hancock, and
C                   D.G. Truhlar, J. Chem. Phys. 87, 7024-7035 (1987).       
C    EAM6 reference:  S.E. Wonchoba and D.G. Truhlar, submitted to Phys. Rev.
C                     B.
C                     T.N. Truong, D.G. Truhlar, and B.C. Garrett, J. Phys. 
C                     Chem. 93, 8227-8239 (1989).
C
C    NOTE:  NATDM APPEARS IN 3 PLACES.  ADJUST IT ACCORDINGLY FOR THE
C           SIZE SYSTEM BEING WORKED ON.  ADJUST IT IN ALL 3 PLACES!
C
C  Here is how this code works.  Originally, EAM6 handled H on Ni.  Also, 
C    it was able to use the EDIM method to treat H2 and H3 on Ni.  The J1
C    surface handled CH4 + H  <---> CH3 + H2.  First, the J1 surface was 
C    modified to treat CH4 <---> CH3 + H.  Second, parameters for treating
C    C atom were added to EAM6.
C  Next, J1 and EAM6 were merged.  The three-body (V3) terms in J1 were 
C    removed and replaced with VDIM of EAM6.  There are 4 three body terms
C    in the original J1.  Now, each three-body term consists of the C atom, 
C    one of the methyl H atoms, and the pseudoorbitals representing the Ni
C    surface.
C  Right now, the code handles each three body terms just using the 
C    formalism described in the EDIM paper for a diatomic on a surface.
C    The coding for a triatomic on the surface can be found in the EAM6
C    code (original version) or earlier EDIM codes.  It is not currently 
C    implememted for this procedure. 
C
C Set up data for EDIM potential and perform some error checking; 
C must be called once before any calls to the main driver SURF.
C
C Atoms are partitioned into covalent gas-phase atoms and metal surface
C    atoms.  The metal atoms are further divided into a primary zone
C    and secondary zone; the primary zone also includes all covalent
C    atoms.  All atoms in the primary zone are allowed to move and
C    their derivatives (wrt spaced fixed cartesians) are computed.
C Unscaled cartesian coordinates are passed thru parameter list and
C    are in atomic units.  Energy and derivatives wrt unscaled cartesian
C    coordinates are returned to the calling routine in atomic units.
C    The EAM data is such that using coordinates in Angstroms gives
C    energies in eV and derivatives in eV/Angstroms.  All other data is
C    input in atomic units unless explicitly stated before the read
C    statement and is converted to use eV and Anstroms internally.  BOHR
C    converts from au to Angstoms, CEV converts from Hartree to eV, and
C    CONVF converts from eV/Angstroms to Hartree/bohr.
C The parameter list must match the variable type and dimensioning used
C    in the calling routine.  The dimension is set by the variable NCRDM
C    NCRDM is three times the maximum number of atoms allowed to move in
C    the calling program; this must be at equal to or greater than the 
C    the number of atoms allowed to move in this potential energy 
C    surface.  
C The maximum number of atoms allowed to move in this surface routine is
C    set by the parameter NATDM.
C The number of atoms allowed to move in a given calculation using this
C    surface is set by the input variables NCOV and NMETP which are 
C    explained below.  
C The SETUP subroutine also does some error checking, in particular 
C    if the number of gas atoms NCOV > 3, or NATDM < NCOV + NMETP,
C    or, NCRDM < NCOV + NMETP then error messages will be written to 
C    unit 6 and the calculation stopped.
C The coordinates of only the moving atoms (those in the primary
C    zone) are passed through parameter list and are assumed to be
C    arranged in the X array as follows:
C                               X-ARRAY INDICES
C      ATOM               X           Y           Z
C    gas atom k      3*(k-1)+1   3*(k-1)+2   3*(k-1)+3, k=1,NCOV
C    surface atom i  3*(i-1)+1   3*(i-1)+2   3*(i-1)+3, i=NCOV+1,NATPRM
C    where NCOV   = number of gas atoms
C          NATPRM = number of atoms in primary zone (gas + metal)
C
C NATMX  - maximum number of atoms (gas + solid) including moving and
C          fixed geometries.
C NCOVMX - maximum number of gas atoms
C NVCDM  - maximum number of 'bonds' (cov-cov and cov-metal)
C NATDM  - maximum number of atoms (gas + solid) allowed to move
C



C  Change accordingly for larger systems the following line!!
      PARAMETER (NATDM = 53)


C
      PARAMETER (NATMX=1601, NCOVMX=5, NVCDM=(NCOVMX*(NCOVMX+1))/2)
      COMMON /SURCM1/ R(3,NATMX), DIJ(NATMX,NATMX),
     *   DIJDR(3,NATMX,NATMX), VCOV(NVCDM), DVCOV(3,NATDM,NVCDM),
     *   VCOV3(NVCDM), DVCOV3(3,NATDM,NVCDM), DVMET(3,NATDM),
     *   RHOS(NATMX), RHO(NATMX), RHOP(NATMX,NATMX), RHOI(NATMX),
     *   F(NATMX), FP(NATMX), EZERO, ITYPE(NATMX), NATPRM, NATPRP,
     *   NCOV, NCOVP, NMET, NMETP,NATOMS, NBOND, NBONDC, INDGS,
     * NCUT(NATMX),ID(NATMX,NATMX),NCOV2,NBONDC2,NBOND2,NFRST(NVCDM)
      COMMON /SCUBCM/ HRHOC(NATMX),DHRHOC(NATMX),HRHOD(NATMX),
     *     DHRHOD(NATMX)
C
C NDIMDM - maximum dimension needed for DIM calculation. (For NCOV=2,
C          NDIM=2, and for NCOV=3, NDIM=5.)
      PARAMETER (NDIMDM=5)
      COMMON /SURCM2/ H(NDIMDM,NDIMDM), S(NDIMDM,NDIMDM), EIS1(NDIMDM),
     *   EIS2(NDIMDM), U(NDIMDM,NDIMDM), EIG(NDIMDM),
     *   DHDR(NDIMDM,NDIMDM), DVDR(3,NATDM)
C
C NTYMDM - maximum number of metal types
C NTYGDM - maximum number of non-metal types (gas types)
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      PARAMETER (NMORDM=(NTYGDM*(NTYGDM+1))/2)
      COMMON /SMORCM/ DE(NMORDM), ALFM(NMORDM), REQ(NMORDM),
     *   SATO(NMORDM)
      COMMON /STRICM/ TRIPH(3,NTYGDM)
      COMMON /SCUTCM/ RCUT(2,NTYPDM),DCUT(NTYPDM)
      COMMON /SRHOCM/ CRI(10,NTYPDM), CI(10,NTYPDM), SI(10,NTYPDM),
     *   FACT(10,NTYPDM), RNSPAR(2,NTYPDM), NI(10,NTYPDM), NTS(NTYPDM),
     *   NTP(NTYPDM), NE(NTYPDM)
      COMMON /SZRCM/ Z0(NTYPDM), BETA(NTYPDM), ALPHA(NTYPDM), CONV
      COMMON /SFCM/  FPAR(14,NTYPDM)
C
      DATA BOHR/0.52917706E0/, CEV/27.21161E0/
C
C NCOV   - number of gas atoms used for each DIM calculation
C NCOV2  - total number of gas atoms
C NMETP  - number of metal atoms allowed to move (primary zone)
C NMETS  - number of metal atoms in secondary zone (total metal atoms
C          minus NMETP).
C
C OPEN THE POTENTIAL DATA FILE
C
**       OPEN (UNIT=4, FILE='pothni111CH.dat', STATUS='OLD',
**     *       FORM='FORMATTED', ERR=100)
C
C
      REWIND 4  
      
      READ (4, *)NCOV2
      CALL SETUP2(NCOV2*3)
      READ (4, *) NCOV, NMETP, NMETS
C NATPRM - number of atoms in primary zone
C
      NATPRM = NCOV2 + NMETP
C
C Check that the primary zone has at least one atom and less than
C the maximum set by the parameter NATDM
C
      IF (NATPRM .LE. 0) THEN
         WRITE (6, *) ' Number of atoms in the primary zone must be'
         WRITE (6, *) ' greater than zero but is', NATPRM
         STOP 'SETUP 2'
      ELSE IF (NATPRM .GT. NATDM) THEN
         WRITE (6, 1000) NATPRM, NATDM
         STOP 'SETUP 3'
      END IF
C
C Check the number of gas atoms read in from unit 4
C
      IF (NCOV2 .GT. NCOVMX) THEN
          WRITE (6, 1100) NCOVMX, NCOV
          STOP 'SETUP 4'
      ENDIF
C
C Check that the calling program has passes the correct number
C of cartesian coordinates for the atoms in the primary zone.
C
      IF (NCRDM .LT. (3 * NATPRM)) THEN
          WRITE (6, 1200) NCRDM, 3*NATPRM
          STOP 'SETUP 5'
      ENDIF
C
      NATPRP = NATPRM + 1
C NMET   - number of metal atoms
      NMET = NMETP + NMETS
C NATOMS - total number of atoms
      NATOMS = NMET + NCOV2
C NCOVP  - index of first metal atom
      NCOVP = NCOV2 + 1
C NBONDC - number of gas-gas bonds per DIM calc
      NBONDC = (NCOV*(NCOV-1))/2
C NBONDC2 - total number of gas-gas bonds
      NBONDC2 = (NCOV2*(NCOV2-1))/2
C NBOND  - total number of bond (gas-gas + gas-metal) per DIM calc
      NBOND = NBONDC + NCOV
C NBOND2  - total number of bond (gas-gas + gas-metal)
      NBOND2 = NBONDC2 + NCOV2
C INDGS  - index of first gas-metal bond)
      INDGS = NBONDC2 + 1
      WRITE (6,600)NCOV2,NCOV,NMETP,NMETS,NATPRM,NMET,NATOMS,NBOND
C
C Morse parameters for covalent-covalent bonds and Sato parameters
C    DE    - Morse dissociation energy (in Hartree)
C    ALPM  - Morse range parameter (in 1/bohr)
C    REQ   - Morse equilibrium geometry (in bohr)
C    SATCOV- cov-cov Sato parameter
      WRITE (6,*) 'Atom Type 1 is Ni'
      WRITE (6,*) 'Atom Type 2 is H'
      WRITE (6,*) 'Atom Type 3 is C'
      WRITE (6, 601)
      IT = 0
      DO 10 IT1 = 1,NTYGDM
         DO 10 IT2 = 1,IT1
            IT = IT + 1
            READ (4, *) DE(IT), ALFM(IT), REQ(IT), SATO(IT)
            WRITE (6, 602) IT1+NTYMDM, IT2+NTYMDM, DE(IT), ALFM(IT),
     *         REQ(IT), SATO(IT)
C   Convert energies to eV, lengths to Angstroms
            DE(IT) = DE(IT)*CEV
            ALFM(IT) = ALFM(IT)/BOHR
            REQ(IT) = REQ(IT)*BOHR
            SATO(IT) = 0.5E0*(1.0E0-SATO(IT))/(1.0E0+SATO(IT))
   10 CONTINUE
C    TRIPH - parameters for gas-metal triplet curves
      WRITE (6, 603)
      DO 20 IT = 1,NTYGDM
         READ (4, *) (TRIPH(I,IT), I=1,3)
         WRITE (6, 604) IT+NTYMDM, (TRIPH(I,IT), I=1,3)
   20 CONTINUE

* Now read in A, B, C, & Sato for C-H & C-Ni from fort.93
      REWIND 93
       READ (93,*) TRIPH(1,2) 
       READ (93,*) TRIPH(2,2) 
       READ (93,*) TRIPH(3,2) 
       READ (93,*) SATO(2)
      CLOSE (93)
      SATO(2) = 0.5E0*(1.0E0-SATO(2))/(1.0E0+SATO(2))

C   RNSPAR - parameters for effective number of s electrons in the rho
C            calculations
      WRITE (6, 605)
      DO 30 IT = 1,NTYMDM
         READ (4, *) (RNSPAR(I, IT), I=1,2)
         WRITE (6, 604) IT, (RNSPAR(I, IT), I=1,2)
   30 CONTINUE
      WRITE (6, 606)
      DO 35 IT = 1,NTYGDM
         READ (4, *) (RNSPAR(I, IT+NTYMDM), I=1,2)
         WRITE (6, 604) IT+NTYMDM, RNSPAR(1,IT+NTYMDM)
   35 CONTINUE
      READ (4, *) (FPAR(I,3), I=1,2)
      WRITE (6, 620) (FPAR(I,3), I=1,2)
C   Parameters for pair repulsion terms
      WRITE (6, 607)
      DO 40 IT = 1,NTYPDM
         READ (4, *) Z0(IT), BETA(IT), ALPHA(IT)
         WRITE (6, 604) IT, Z0(IT), BETA(IT), ALPHA(IT)
   40 CONTINUE
C   Parameters for switching function
      WRITE (6, 608)
      DO 50 IT = 1,NTYPDM
         READ (4, *) RCUT(1,IT),RCUT(2,IT)
         DCUT(IT) = RCUT(1,IT) - RCUT(2,IT)
         WRITE (6, 604) IT, RCUT(1,IT),RCUT(2,IT)
   50 CONTINUE
C   Zero of energy read in Hartree
      READ (4, *) EZERO
      WRITE (6, 609) EZERO
      IF (NCOV .GT. 1) THEN
C   Set up overlap matrix
         IF (NCOV .EQ. 2) THEN
            NDIM = 2
            S(1,1) = 4.0E0
            S(1,2) = -2.0E0
            S(2,2) = 4.0E0
         ELSE IF (NCOV .EQ. 3) THEN
            NDIM = 5
            S(1,1) = 1.0E0
            S(1,2) = 0.25E0
            S(2,2) = 1.0E0
            S(1,3) = -0.5E0
            S(2,3) = -0.5E0
            S(3,3) = 1.0E0
            S(1,4) = -0.5E0
            S(2,4) = -0.5E0
            S(3,4) = 0.25E0
            S(4,4) = 1.0E0
            S(1,5) = -0.5E0
            S(2,5) = -0.5E0
            S(3,5) = 0.25E0
            S(4,5) = 0.25E0
            S(5,5) = 1.0E0
         END IF
C    Get Cholesky factorization of S
         DO 120 I = 1,NDIM
            DO 120 J = 1,I
               H(J,I) = 0.0E0
  120    CONTINUE
         CALL REDUC (NDIMDM, NDIM, 1, H, S, EIS2, IERR)
         IF (IERR .NE. 0) THEN
            WRITE (6, 6000) IERR
            STOP
         END IF
      END IF
C
      READ (4,*) (ITYPE(I),I=1,NATPRM)
      WRITE (6, 610) (ITYPE(I),I=1,NATPRM)
      IF (NATOMS .GT. NATMX) THEN
         WRITE (6, *) ' NATOMS=', NATOMS, ' .GT. NATMX=', NATMX
         STOP
      END IF
      IF (NATPRP .LE. NATOMS) THEN
C  Read in geometries of atoms that are fixed to their lattice sites
C     (secondary zone)
         DO 140 I = NATPRP,NATOMS
            READ (4,*) ITYPE(I), (R(J,I),J=1,3)
C  Convert from bohr to angstrom.
            DO 130 J = 1,3
               R(J,I) = R(J,I)*BOHR
  130       CONTINUE
  140    CONTINUE
      END IF
      WRITE (6, 612)
C
C  Calculate cri constants matrix for rhom
      DO 160 IT = 1,NTYPDM
         NN = NTS(IT)+NTP(IT)
         DO 150 I=1,NN
            EX = FLOAT(NI(I,IT))+0.5
            CRI(I,IT) = CI(I,IT)*(2.0*SI(I,IT))**EX/SQRT(FACT(I,IT))
  150    CONTINUE
  160 CONTINUE
C
C Get electron density at each atom in the secondary zone due to all
C    other atoms in the secondary zone.
      DO 170 I = 1,NATOMS
         RHOS(I) = 0.0
  170 CONTINUE
      IF (NATPRP.LE.NATOMS) THEN
C First get interatomic distances and set up lookup table.
         CALL SURR2 (NATPRP, NATOMS, R, DIJ, ITYPE, NCUT, ID, NATMX)
         DO 190 I = NATPRP,NATOMS
            NMAX = NCUT(I)
            IF (NMAX .GT. 0) THEN
C Evaluate density from atom i at all atoms j in the lookup list for
C    atom i.
               CALL SURRHO(R(3,I), DIJ(1,I), RHOI, RHOP, ITYPE(I),
     *            NATOMS, NMAX, ID(1,I), NCOV, HRHOC, DHRHOC,
     *            HRHOD, DHRHOD, ITYPE,I, DIJ(1,5),1)
               DO 180 JJ = 1,NMAX
                  J = ID(JJ,I)
                  RHOS(J) = RHOS(J) + RHOI(J)
  180          CONTINUE
            END IF
  190    CONTINUE
       END IF
C
C  CLOSE THE POTENTIAL DATA FILE
C
      CLOSE (4)
C

      RETURN
  600 FORMAT (//, 1X, 130(1H*), /, ' Set up EDIM potential version 6',
     *   //, 5X, 'Total Number of covalent atoms=', T50, I5, /,
     *   5X, 'Number of covelant atoms per DIM calc=', T50, I5, /,
     *   5X, 'Number of metal atoms in primary zone=', T50, I5, /,
     *   5X, 'Number of metal atoms in secondary zone=', T50, I5, /,
     *   5X, 'Total number of atoms in primary zone=', T50, I5, /,
     *   5X, 'Total number of metal atoms=', T50, I5, /,
     *   5X, 'Total number of atoms=', T50, I5, /,
     *   5X, 'Number of cov-cov and cov-met bonds=', T50, I5)
  601 FORMAT (/, 5X, 'Covalent-covalent Morse parameters', /,
     *   7X, 'Atom type', 2X, 'D (hartrees)', 3X, 'ALF (1/bohr)', 3X,
     *   'REQ (bohr)', 5X, 'SATO')
  602 FORMAT (5X, 2I5, 1P4E15.7)
  603 FORMAT (/, 5X, 'Parameters defining cov-met triplet interaction',
     *   /, 7X, 'Atom', 5X, 'Parameters')
  604 FORMAT (5X, I5, 1P4E15.7)
  605 FORMAT (/, 5X, 'Effective number of s electrons for metal', /,
     *   7X, 'Atom', 5X, 'Bulk', 11X, 'Surface')
  606 FORMAT (/, 5X, 'Effective number of s electrons for covalent',
     *   ' atoms', /, 7X, 'Atom')
  607 FORMAT (/, 5X, 'Parameters for pair repulsion terms', /, 7X,
     *   'Atom', 5X, 'Z0', 13X, 'BETA', 11X, 'ALPHA')
  608 FORMAT (/, 5X, 'Parameters for switching function', /,
     *   7X, 'Atom', 5X, 'RCUT1', 11X, 'RCUT2')
  609 FORMAT (/, 5X, 'Zero of energy=', T50, 1PE17.10, ' Hartree')
  610 FORMAT (5X, ' For primary zone, ITYPE=', /, (10X, 30I3))
  612 FORMAT (1X, 130(1H*))
  620 FORMAT (/, 5X, 'Parameters for embedding function for atom 3', /,
     *   ' F1=', T50, 1PE15.7, /, ' F2=', T50, 1PE15.7)
 1000 FORMAT(/,3X,5(1H*),'Number of atoms in the primary zone, ',
     *       'NATPRM = ',I5,' is larger than the maximum set by',
     *       ' the parameter NATDM = ',/)
 1100 FORMAT(/,3X,5(1H*),'This surface is coded for ',I2,
     *       'gas-phase atoms, but the number read in from unit',
     *       ' 4 is ',I3,/)
 1200 FORMAT(/,3X,5(1H*),'The calling routine has passed only',
     *       I5,' cartesian coordinates, but the potential ',
     *       'requires ',I5,/)
 6000 FORMAT (' IN SETUP, ERROR WITH EISPACK ROUTINE REDUC, IERR=', I5)
C
  100 WRITE(6,*)'ERROR OPENING POTENTIAL DATA FILE'
      STOP 'SETUP 1'
C
      END
      BLOCK DATA
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Block data for EDIM potentials
C
C NTYMDM - maximum number of metal types
C NTYGDM - maximum number of non-metal types (gas types)
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      COMMON /SRHOCM/ CRI(10,NTYPDM), CI(10,NTYPDM), SI(10,NTYPDM),
     *   FACT(10,NTYPDM), RNSPAR(2,NTYPDM), NI(10,NTYPDM), NTS(NTYPDM),
     *   NTP(NTYPDM), NE(NTYPDM)
      COMMON /SZRCM/ Z0(NTYPDM), BETA(NTYPDM), ALPHA(NTYPDM), CONV
      COMMON /SFCM/  FPAR(14,NTYPDM)
C
      DATA CONV /14.3888/
**      DATA CONV /14.3994/
C
C  Ni embedding energy

       DATA (FPAR(I,1),I=1,14) / -303.28911, 7.64744, 87.98723,
     +   75.07472, -522.77364, 373.37826, 0.1,0.11,-2.014563533E10,
     +   -538419456.0, -4060125.0, -11.03098054, 39.42118, 56.34512/ 

C H embedding energy
      DATA (FPAR(I,2), I=1,2) /  476.1208, 5.0715/
*      DATA (FPAR(I,2), I=1,2) /  476.1208, 5.0715/

C C embedding energy
      DATA (FPAR(I,3), I=1,2) / -221.6, 44.74/
C
C Ni electron density
      DATA NE(1),NTS(1),NTP(1) /10, 8, 2/
C                             1s    2s    3s    4s    3d
      DATA (NI(I,1),I=1,10) / 1, 1, 2, 2, 3, 3, 4, 4, 3, 3/
      DATA (FACT(I,1),I=1,10) /2., 2., 24., 24., 720., 720., 40320.,
     *   40320., 720.,720./
      DATA (CI(I,1),I=1,10) / -0.00389, -0.02991, -0.03189, 0.15289,
     *   -0.20048, -0.05423, 0.49292, 0.61875, 0.4212, 0.70658/
      DATA (SI(I,1),I=1,10) / 54.88885, 38.48431, 27.42703, 20.88204,
     *   10.95707, 7.31958, 3.9265, 2.15289, 12.67582, 5.43253 /
C
C H electron density
      DATA NE(2), NTS(2), NTP(2) /1, 1, 0/
      DATA NI(1,2) /1/
      DATA FACT(1,2) /2./
      DATA CI(1,2) / 1.0/
      DATA SI(1,2) / 1.88972652/

C C electron density
      DATA NE(3),NTS(3),NTP(3) /4, 2, 2/
C                             1s    2s          2p
      DATA (NI(I,3),I=1,10) / 1, 1, 2, 2, 2, 2, 2, 2, 2, 2/
      DATA (FACT(I,3),I=1,10) /2., 2., 24., 24., 24., 24., 24.,
     *   24., 24.,24./
      DATA (CI(I,3),I=1,10) / -0.20814, -0.01071, 0.08099, 0.75045,
     *    0.33549, -0.14765, 0.28241, 0.54697, 0.23195, 0.01025 /
      DATA (SI(I,3),I=1,10) / 10.27273, 17.91979, 1.99841, 2.88051,
     *    5.07278, 7.93882, 1.85335, 2.72808, 4.91435, 12.30241 /

C O electron density
C      DATA NE(3),NTS(3),NTP(3) /6, 4, 2/
C                            1s    2s    2p
C      DATA (NI(I,3),I=1,6) / 1, 1, 2, 2, 2, 2/
C      DATA (FACT(I,3),I=1,6) /2., 2., 24., 24., 24., 24./
C      DATA (CI(I,3),I=1,6) / 0.01587, -0.29963, 0.70761, 0.37450,
C     *   0.33221, 0.74483/
C      DATA (SI(I,3),I=1,6) / 17.89480, 12.92567, 5.08130, 3.16716,
C     *    6.98384, 3.13543/
C

      END
      SUBROUTINE SURF(E, X, DX, NCRDM)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Driver for evaluation of potential for gas-metal-surface interactions.
C



C Change accordingly for larger systems the following line
      PARAMETER (NATDM = 53)

* NSURF2 is the N3TM parameter passed into SURF2 for the calculation of
*  the methane bend.  It is calculated by the J1 surface, which assumes
*  6 atoms.  The 5th H atom is non-existent though.  RC-H = infinity.
*  This is handled within SURF2.  Then when all the info for derivatives
*  comes back from SURF2, only DX(1-15) is added in.  (In SURF2, the indicies
*  for the 5th H atom are 16, 17, and 18)   
      PARAMETER (NSURF2 = 18)  



      PARAMETER (NATMX=1601, NCOVMX=5, NVCDM=(NCOVMX*(NCOVMX+1))/2)
      COMMON /SURCM1/ R(3,NATMX), DIJ(NATMX,NATMX),
     *   DIJDR(3,NATMX,NATMX), VCOV(NVCDM), DVCOV(3,NATDM,NVCDM),
     *   VCOV3(NVCDM), DVCOV3(3,NATDM,NVCDM), DVMET(3,NATDM),
     *   RHOS(NATMX), RHO(NATMX), RHOP(NATMX,NATMX), RHOI(NATMX),
     *   F(NATMX), FP(NATMX), EZERO, ITYPE(NATMX), NATPRM, NATPRP,
     *   NCOV, NCOVP, NMET, NMETP,NATOMS, NBOND, NBONDC, INDGS,
     * NCUT(NATMX),ID(NATMX,NATMX),NCOV2,NBONDC2,NBOND2,NFRST(NVCDM)
      COMMON /SCUBCM/ HRHOC(NATMX),DHRHOC(NATMX),HRHOD(NATMX),
     *     DHRHOD(NATMX)
*      COMMON /RHO1CM/ DFDP,DVDP,DVBDR(3,NATDM)
      COMMON /GNLGCM / IFLAG9
      COMMON /FREECM/ DFREE(4,2000), DFRDX(15)
C
C NDIMDM - maximum dimension needed for DIM calculation. (For NCOV=2,
C          NDIM=2, and for NCOV=3, NDIM=5.)
      PARAMETER (NDIMDM=5)
      COMMON /SURCM2/ H(NDIMDM,NDIMDM), S(NDIMDM,NDIMDM), EIS1(NDIMDM),
     *   EIS2(NDIMDM), U(NDIMDM,NDIMDM), EIG(NDIMDM),
     *   DHDR(NDIMDM,NDIMDM), DVDR(3,NATDM)
C
      DIMENSION X(NCRDM),DX(NCRDM),DX2(NCOVMX*3+3),XS2(18),
     *    DXXM(3*NATDM)
C
      DATA BOHR/0.52917706E0/, CEV/27.21161E0/, CONVF/0.01944673836E0/
C
C Convert coordinates to Angstroms
      I = 0
      DO 10 II = 1,NATPRM
         DO 5 J = 1,3
            I = I + 1
            R(J,II) = X(I)*BOHR
    5    CONTINUE
   10 CONTINUE
C
C Get interatomic distances and set up lookup table
      CALL SURR1 (NCOV2, NCOVP, NATPRM, NATOMS, R, DIJ, DIJDR, ITYPE,
     *   NCUT, ID, NATMX)
C
C Get covalent potentials and derivatives and derivatives
C These are the C-H singlet and triplet interactions (ES & ET)
       INIT = 1
       INDX = 0
       JAT1 = 5
       JAT2 = 1
      IF (NCOV .GT. 1) CALL SURCOV (NCOV, NBONDC, NATPRM, NATDM, NATMX,
     *   ITYPE,DIJ,DIJDR,VCOV,DVCOV,VCOV3,DVCOV3,NBONDC2,JAT1,JAT2,
     *  INDX, INIT)

       INIT = 0
       INDX = 1
       JAT1 = 5
       JAT2 = 2
      IF (NCOV .GT. 1) CALL SURCOV (NCOV, NBONDC, NATPRM, NATDM, NATMX,
     *   ITYPE,DIJ,DIJDR,VCOV,DVCOV,VCOV3,DVCOV3,NBONDC2,JAT1,JAT2,
     *  INDX, INIT)

       INDX = 2
       JAT1 = 5
       JAT2 = 3
      IF (NCOV .GT. 1) CALL SURCOV (NCOV, NBONDC, NATPRM, NATDM, NATMX,
     *   ITYPE,DIJ,DIJDR,VCOV,DVCOV,VCOV3,DVCOV3,NBONDC2,JAT1,JAT2,
     *  INDX, INIT)

       INDX = 3
       JAT1 = 5
       JAT2 = 4
      IF (NCOV .GT. 1) CALL SURCOV (NCOV, NBONDC, NATPRM, NATDM, NATMX,
     *   ITYPE,DIJ,DIJDR,VCOV,DVCOV,VCOV3,DVCOV3,NBONDC2,JAT1,JAT2,
     *  INDX, INIT)
      
C Set ES & ET for H-H interactions equal to zero.
C These interactions are calculated in SURF2 by Vbend.
       DO 12 M = 5,10
         VCOV(M) = 0.0
         VCOV3(M) = 0.0
12     CONTINUE

C
C Get EAM potentials for gas-metal interactions and metal-metal
C    interactions and their derivatives
         REWIND 96
         READ (96,*) FCA1
         READ (96,*) FCB1
         READ (96,*) FCC1
         READ (96,*) FCA2
         READ (96,*) FCB2
         READ (96,*) FCC2
         CLOSE (96)
           
       CALL SUREAM (NCOV, NMET, NATPRM, NATOMS, NCOVP, NMETP, NVCDM,
     *   NATDM, NATMX, R, ITYPE, DIJ, DIJDR, VCOV(INDGS),
     *   DVCOV(1,1,INDGS), VCOV3(INDGS), DVCOV3(1,1,INDGS), VMET, DVMET,
     *   RHOS, RHO, RHOP, RHOI, F, FP, NCUT, ID, HRHOC, DHRHOC,
     *   DHRHOD,HRHOD,NCOV2, FCA1, FCB1, FCC1, FCA2, FCB2, FCC2)
C
C Evaluate DIM for potential and derivatives

         NB1 = 1
         NB2 = 11
         NB3 = 15
      CALL SURDIM (NCOV, NATDM, NBOND, NATPRM, VCOV, DVCOV, VCOV3,
     *   DVCOV3, NDIMDM, H, S, EIS1, EIS2, U, EIG, DHDR, V, DVDR,
     *   NB1, NB2, NB3, NBOND2,1)
         VRES = V
         V1 = V

         NB1 = 2
         NB2 = 12
         NB3 = 15
      CALL SURDIM (NCOV, NATDM, NBOND, NATPRM, VCOV, DVCOV, VCOV3,
     *   DVCOV3, NDIMDM, H, S, EIS1, EIS2, U, EIG, DHDR, V, DVDR,
     *   NB1, NB2, NB3, NBOND2,0)
         VRES = VRES + V
         V2 = V

         NB1 = 3
         NB2 = 13
         NB3 = 15
      CALL SURDIM (NCOV, NATDM, NBOND, NATPRM, VCOV, DVCOV, VCOV3,
     *   DVCOV3, NDIMDM, H, S, EIS1, EIS2, U, EIG, DHDR, V, DVDR,
     *   NB1, NB2, NB3, NBOND2,0)
         VRES = VRES + V
         V3 = V

         NB1 = 4
         NB2 = 14
         NB3 = 15
      CALL SURDIM (NCOV, NATDM, NBOND, NATPRM, VCOV, DVCOV, VCOV3,
     *   DVCOV3, NDIMDM, H, S, EIS1, EIS2, U, EIG, DHDR, V, DVDR,
     *   NB1, NB2, NB3, NBOND2,0)
         VRES = VRES + V
         V4 = V
         V = VRES
C
C Total energy is DIM potential plus the metal-metal interactions
      E = (V + VMET)/CEV + EZERO
      ERES = E
* E & ERES are now in hartrees
C
C Evaluate derivative and convert to au
      I = 0
      DO 20 II = 1,NATPRM
         DO 20 J = 1,3
            I = I + 1
            DX(I) = (DVDR(J,II) + DVMET(J,II))*CONVF
*            WRITE (6,*)'J,II,DVDR(J,II),DVMET(J,II)',
*     *          J,II,DVDR(J,II),DVMET(J,II)
   20 CONTINUE
      DO 22 II = 1, 15
*        WRITE (6,*) 'I, DX, DFRDX',II,DX(II),DFRDX(II)
        DX(II) = DX(II) + DFRDX(II)*CONVF
22    CONTINUE

  
      VBEND = 0
      DO 28 I = 1,18
        DX2(I) = 0.0
28    CONTINUE
*      GOTO 35
      IFLAG9 = 0
       XS2(1) = X(1)
       XS2(2) = X(2)
       XS2(3) = X(3)
       XS2(4) = X(4)
       XS2(5) = X(5)
       XS2(6) = X(6)
       XS2(7) = X(7)
       XS2(8) = X(8)
       XS2(9) = X(9)
       XS2(10) = X(10)
       XS2(11) = X(11)
       XS2(12) = X(12)
       XS2(13) = X(13)
       XS2(14) = X(14)
       XS2(15) = X(15)
       XS2(16) = X(13)
       XS2(17) = X(14)
       XS2(18) = 0.0D0 


      CALL SURF2(VBEND, XS2, DX2, DXXM, NSURF2,IFLAG9)
91     FORMAT (4F10.4, F12.3, F12.6)
       IF (IFLAG9 .EQ. 1) GOTO 998
      DO 30 I = 1, (NSURF2 - 3)
        DX(I) = DX(I) + DX2(I)
30    CONTINUE 
      DO 37 I = 1,3*(NATPRM-NCOV2)
        DX((3*NCOV2)+I) = DX((3*NCOV2)+I) + DXXM(I)
37    CONTINUE
35    CONTINUE
   

      ERES = ERES + VBEND
998      E = ERES
C
999      RETURN
      END
      SUBROUTINE SURCOV (NCOV, NBONDC, NATPRM, NATDM, NATMX, ITYPE,
     *   DIJ, DIJDR, VCOV, DVCOV, VCOV3, DVCOV3,NBONDC2,JAT1,JAT2,
     *   INDX,INIT)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Compute covalent-covalent pair potentials and derivatives
C
      DIMENSION DIJ(NATMX,NATMX), DIJDR(3,NATMX,NATMX),
     *   VCOV(NBONDC2), DVCOV(3,NATDM,NBONDC2), VCOV3(NBONDC2),
     *   DVCOV3(3,NATDM,NBONDC2), ITYPE(NATMX)
C
C NTYMDM - maximum number of metal types
C NTYGDM - maximum number of non-metal types (gas types)
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      PARAMETER (NMORDM=(NTYGDM*(NTYGDM+1))/2)
      COMMON /SMORCM/ DE(NMORDM), ALFM(NMORDM), REQ(NMORDM),
     *   SATO(NMORDM)
C
      IF (INIT. EQ. 1) THEN 
       INIT = 0
        DO 10 J = 1, NBONDC2
         DO 10 I = 1,NATPRM
            DO 10 K = 1,3
               DVCOV(K,I,J) = 0.0E0
               DVCOV3(K,I,J) = 0.0E0
   10 CONTINUE
      ENDIF
         J = JAT2
         JM = JAT1
         IT1 = ITYPE(J) - NTYMDM
            IT2 = ITYPE(JM) - NTYMDM
            ITG = MAX(IT1,IT2)
* IT determines the type of bond between J & JM
            IT = (ITG*(ITG-1))/2 + MIN(IT1,IT2)
            INDX = INDX + 1
              T = -ALFM(IT)*(DIJ(JM,J)-REQ(IT))
            AEXP = EXP(T)
            T = DE(IT)*AEXP
            VCOV(INDX) = T*(AEXP-2.0E0)
              TD = -2.0E0*ALFM(IT)*T
              DV = TD*(AEXP-1.0E0)
            T = SATO(IT)*T
            VCOV3(INDX) = T*(AEXP+2.0E0)
            TD = -2.0E0*ALFM(IT)*T
            DV3 = TD*(AEXP+1.0E0)
            DO 40 K = 1,3
               DR = DIJDR(K,JM,J)
               T = DV*DR
               DVCOV(K,JM,INDX) = DVCOV(K,JM,INDX) + T
               DVCOV(K,J,INDX) = DVCOV(K,J,INDX) - T
               T = DV3*DR
               DVCOV3(K,JM,INDX) = DVCOV3(K,JM,INDX) + T
               DVCOV3(K,J,INDX) = DVCOV3(K,J,INDX) - T
   40       CONTINUE
      RETURN
      END

      SUBROUTINE SURDIM (NCOV, NATDM, NBOND, NATPRM, VCOV, DVCOV,
     *   VCOV3, DVCOV3, NDIMDM, H, S, EIS1, EIS2, U, E, DHDR, V, DVDR,
     *   NB1, NB2, NB3, NBOND2, NFRST)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Evaluate DIM potential and derivatives wrt cartesian coordinates
C
      DIMENSION VCOV(NBOND2), DVCOV(3,NATDM,NBOND2), VCOV3(NBOND2),
     *  DVCOV3(3,NATDM,NBOND2), H(NDIMDM,NDIMDM), S(NDIMDM,NDIMDM),
     *   EIS1(NDIMDM), EIS2(NDIMDM), U(NDIMDM,NDIMDM), E(NDIMDM),
     *   DHDR(NDIMDM,NDIMDM), DVDR(3,NATDM)
C
      IF (NFRST .EQ. 1) THEN
        DO 5 I = 1, NATPRM
         DO 5 K = 1, 3
          DVDR(K,I) = 0.0
5     CONTINUE
      ENDIF
       
      IF (NCOV .EQ. 1) THEN
C Only one covalent atom, V and DVDR are set to the one gas-surface
C    interaction term
         V = VCOV(1)
         DO 10 I = 1,NATPRM
            DO 10 J = 1,3
               DVDR(J,I) = DVCOV(J,I,1)
   10    CONTINUE
         RETURN
      ELSE
C More than one covalent atom; compute Q's and J's and put them back
C    into VCOV and DVCOV
         QSUM = 0.0E0
         XJSUM = 0.0E0
            T1 = VCOV(NB1)
            T3 = VCOV3(NB1)
            Q = 0.5E0*(T1 + T3)
            TNB1 = Q
            QSUM = QSUM + Q
            XJ = 0.5E0*(T1 - T3)
            T3NB1 = XJ
            XJSUM = XJSUM + XJ

            T1 = VCOV(NB2)
            T3 = VCOV3(NB2)
            Q = 0.5E0*(T1 + T3)
            TNB2 = Q
            QSUM = QSUM + Q
            XJ = 0.5E0*(T1 - T3)
            T3NB2 = XJ
            XJSUM = XJSUM + XJ

            T1 = VCOV(NB3)
            T3 = VCOV3(NB3)
            Q = 0.5E0*(T1 + T3)
            TNB3 = Q
            QSUM = QSUM + Q
            XJ = 0.5E0*(T1 - T3)
            T3NB3 = XJ
            XJSUM = XJSUM + XJ

C Construct upper triangle of NDIMxNDIM Hamiltonian matrix.
         IF (NCOV .EQ. 2) THEN
            NDIM = 2
* NB2 & NB3 are cov-met bonds
            XJM = T3NB2 + T3NB3
            H(1,1) = 2.0E0*(2.0E0*(QSUM + T3NB1) - XJM)
            H(1,2) = -2.0E0*(QSUM + T3NB1 + XJM)
            H(2,2) = 2.0E0*(2.0E0*(QSUM + XJM) - T3NB1)
         END IF
      END IF
      NM = NDIM - 1
      DO 30 I = 1,NM
         IP = I + 1
         DO 30 J = IP,NDIM
            H(J,I) = H(I,J)
   30 CONTINUE
C
C Diagonalize H using Eispack routine; put eigenvectors into U,
C    eigenvalues into E
      CALL REDUC (NDIMDM, NDIM, -1, H, S, EIS2, IERR)
      IF (IERR .NE. 0) THEN
         WRITE (6, 6000) IERR
         STOP
      END IF
      CALL TRED2 (NDIMDM, NDIM, H, E, EIS1, U)
      CALL TQL2P (NDIMDM, NDIM, E, EIS1, U, IERR)
      IF (IERR .NE. 0) THEN
         WRITE (6, 6001) IERR
         STOP
      END IF
      CALL REBAK (NDIMDM, NDIM, S, EIS2, 1, U)
C
      V = E(1)
C
C Evaluate derivatives of lowest root
      DO 70 I = 1,NATPRM
         DO 70 K = 1,3
            DQSUM = 0.0E0
            DXJSUM = 0.0E0
               T1 = DVCOV(K,I,NB1)
               T3 = DVCOV3(K,I,NB1)
               DQ = 0.5E0*(T1 + T3)
               TDNB1 = DQ
               DQSUM = DQSUM + DQ
               DXJ = 0.5E0*(T1 - T3)
               TD3NB1 = DXJ
               DXJSUM = DXJSUM + DXJ

               T1 = DVCOV(K,I,NB2)
               T3 = DVCOV3(K,I,NB2)
               DQ = 0.5E0*(T1 + T3)
               TDNB2 = DQ
               DQSUM = DQSUM + DQ
               DXJ = 0.5E0*(T1 - T3)
               TD3NB2 = DXJ
               DXJSUM = DXJSUM + DXJ

               T1 = DVCOV(K,I,NB3)
               T3 = DVCOV3(K,I,NB3)
               DQ = 0.5E0*(T1 + T3)
               TDNB3 = DQ
               DQSUM = DQSUM + DQ
               DXJ = 0.5E0*(T1 - T3)
               TD3NB3 = DXJ
               DXJSUM = DXJSUM + DXJ

            IF (NCOV .EQ. 2) THEN
               DXJM = TD3NB2 + TD3NB3
               DHDR(1,1) = 2.0E0*(2.0E0*(DQSUM + TD3NB1)
     *            - DXJM)
               DHDR(1,2) = -2.0E0*(DQSUM + TD3NB1 + DXJM)
               DHDR(2,2) = 2.0E0*(2.0E0*(DQSUM + DXJM)
     *            - TD3NB1)
            END IF
            DO 50 L = 1,NM
               LP = L + 1
               DO 50 M = LP,NDIM
                  DHDR(M,L) = DHDR(L,M)
   50       CONTINUE
            SUM = 0.0E0
            DO 60 L = 1,NDIM
               T1 = U(L,1)
               DO 60 M = 1,NDIM
                  T2 = T1*U(M,1)
                  SUM = SUM + T2*DHDR(L,M)
   60       CONTINUE
            DVDR(K,I) = DVDR(K,I) + SUM
   70 CONTINUE
C
      RETURN
 6000 FORMAT (' IN CALL TO EISPACK ROUTINE REDUC, IERR =', I5)
 6001 FORMAT (' IN CALL TO EISPACK ROUTINE TQL2, IERR =', I5)
      END
      SUBROUTINE SUREAM (NCOV, NMET, NATPRM, NATOMS, NCOVP, NMETP,
     *   NVCDM, NATDM, NATMX, R, ITYPE, DIJ, DIJDR, VCOV, DVCOV, VCOV3,
     *   DVCOV3, VMET, DVMET, RHOS, RHO, RHOP, RHOI, F, FP, NCUT, ID,
     *   HRHOC, DHRHOC,DHRHOD,HRHOD,NCOV2, FCA1, FCB1, FCC1, FCA2, 
     *   FCB2, FCC2)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Calculate the potential and derivatives for the EAM potential
C
      DIMENSION R(3,NATOMS), ITYPE(NATOMS), DIJ(NATMX,NATMX),
     * DIJDR(3,NATMX,NATMX), VCOV(NCOV2), DVCOV(3,NATDM,NCOV2),
     * VCOV3(NCOV), DVCOV3(3,NATDM,NCOV2), DVMET(3,NATDM),
     * RHOS(NATOMS), RHO(NATOMS), RHOP(NATMX,NATMX), RHOI(NATMX)
      DIMENSION F(NATOMS), FP(NATOMS), NCUT(NATMX), ID(NATMX,NATMX),
     * F3(NATOMS), F3P(NATOMS), HRHOC(NATOMS),RJ(9),
     * DHRHOC(NATMX,NATMX),HRHO(NATOMS),H2RHO(NATOMS),WT(9),DWT(9),
     * DHRHOD(NATMX,NATMX),F2(NATOMS),F2P(NATOMS),HRHOD(NATOMS)    
      DIMENSION SIP(3), SIW(3), SIDW(3)
C
C NTYMDM - maximum number of metal types
C NTYGDM - maximum number of non-metal types (gas types)
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      PARAMETER (NMORDM=(NTYGDM*(NTYGDM+1))/2)
      COMMON /SMORCM/ DE(NMORDM), ALFM(NMORDM), REQ(NMORDM),
     *   SATO(NMORDM)
      COMMON /STRICM/ TRIPH(3,NTYGDM)
      COMMON /SFCM/ FPAR(14,NTYPDM)
      COMMON /CDENCM/CDEN,HDEN(4)
      COMMON /FREECM/ DFREE(4,2000), DFRDX(15)
C
C Initialization
C    Set electron density to stored value computed in SETUP
      DO 10 I = 1,NATOMS
         RHO(I) = RHOS(I)
   10 CONTINUE
      DO 20 I = 1,NCOV2
         DO 20 J = 1,NATPRM
             DO 20 K = 1,3
                 DVCOV(K,J,I) = 0.0E0
                 DVCOV3(K,J,I) = 0.0E0
   20 CONTINUE
      DO 30 J = 1,NATPRM
         DO 30 K = 1,3
            DVMET(K,J) = 0.0E0
   30 CONTINUE
C
C Calculate total electron density rho for all atoms.  For atoms in the
C    primary zone contributions are computed to all other atoms.  For
C    atoms in the secondary zone, their contributions are computed only
C    for atoms in the primary zone, their contributions to atoms in the
C    secondary zone are stored in ROHS.
   
      DO 33 J = 1,NCOV2    
      HRHO(J) = 0.0
      H2RHO(J) = 0.0
      HRHOC(J) = 0.0
      HRHOD(J) = 0.0
33    CONTINUE
      DO 50 I = 1,NATOMS
*      DO 50 I = 24,24
         NMAX = NCUT(I)
         IF (NMAX .GT. 0) THEN
            NFLG = 2
            CALL SURRHO (R(3,I), DIJ(1,I), RHOI, RHOP(1,I), ITYPE(I),
     *         NATOMS, NMAX, ID(1,I), NCOV, HRHOC, DHRHOC(1,I),
     *         HRHOD, DHRHOD(1,I), ITYPE,I,  DIJ(1,5),NFLG)
            DO 40 JJ = 1,NMAX
               J = ID(JJ,I)
               RHO(J) = RHO(J) + RHOI(J)
               IF (J .LE. NCOV2) THEN
                 HRHO(J) = HRHO(J) + HRHOC(J)
                 H2RHO(J) = H2RHO(J) + HRHOD(J)
               ENDIF 
   40       CONTINUE
         END IF
   50 CONTINUE
          
C Calculate F and dF/dro for all atoms
      DO 80 I = 1,NATOMS

         IF(ITYPE(I).EQ.1) THEN
C    Ni atom
            IF (RHO(I) .GT. FPAR(8,1)) THEN
               F(I) = FPAR(12,1)
               FP(I) = 0.0
            ELSEIF (RHO(I) .GT. FPAR(7,1)) THEN
               DEL = RHO(I) - FPAR(8,1)
               DEL2 = DEL*DEL
               F(I) = FPAR(12,1) + DEL2*DEL*(FPAR(11,1) +
     *            DEL*(FPAR(10,1) + DEL*FPAR(9,1)))
               FP(I) = DEL2*(3.0*FPAR(11,1) + DEL*(4.0*FPAR(10,1) +
     *            DEL*5.0*FPAR(9,1)))
            ELSE
               T1 = -FPAR(2,1)*RHO(I)
               T = FPAR(1,1)*EXP(T1)
               F(I) = T*RHO(I)
               FP(I) = T*(1.0 + T1)
               T1 = -FPAR(4,1)*RHO(I)
               T2 = FPAR(3,1)*RHO(I)
               T = T2*T2*EXP(T1)
               F(I) = F(I) + T2*T
               FP(I) = FP(I) + T*(3.0*FPAR(3,1) - FPAR(4,1)*T2)
               T1 = -FPAR(6,1)*RHO(I)
               T = FPAR(5,1)*EXP(T1)
               F(I) = F(I) + T*RHO(I)
               FP(I) = FP(I) + T*(1.0 + T1)
               DP1 = FPAR(13,1)*RHO(I)
               DP2 = DP1*DP1
               DP4 = DP2*DP2
               DP5 = DP4*DP1
               T = EXP(-FPAR(14,1)*RHO(I))
               F(I) = F(I) + DP5*T
               FP(I) = FP(I) + T*(5*FPAR(13,1)*DP4 - FPAR(14,1)*DP5)
            ENDIF
            F3(I) = 0.0
            F3P(I) = 0.0
            F2(I) = 0.0
            F2P(I) =0.0

         ELSE IF (ITYPE(I) .EQ. 3) THEN
C    C atom

* NOTE -- For a regular run, uncomment these inext three lines, and put in 
* real values for FCA1, FCB1, FCC1

            
            CDEN = RHO(I)
* Assign FC(rho) and its derivative -- FC(rho) is a 3 part function.     
* Specifically, it's two functions of the form A*p^C*exp(-B*p), joined
* by a 6 variable spline that makes the function continuous through the
* second derivative.   Function 1 goes from 0 < rho <= (a-delta), Spline
* goes from (a-delta) < rho <= a, and Function 2 is for rho > a

      AAA = 0.003
      ADEL = 0.001
      AA2 = 0.022
      ADEL2 = 0.007
      
      IF (RHO(I) .LE. (AAA-ADEL)) THEN
         T1 = -FCB1*RHO(I)
         EXPT1 = EXP(T1)
         IF (RHO(I) .GT. 0.0) THEN
           T2 = FCA1*RHO(I)**(FCC1 - 1.0)
         ELSE
           T2 = 0.0
         ENDIF
         F(I) = T2*EXPT1*RHO(I)
         T3 = -FCB1*RHO(I) + FCC1
         FP(I) = EXPT1 * T3 * T2
      ELSEIF (RHO(I) .LE. AAA) THEN
         SAV =  0.3355955375E+16
         SBV =  0.8340164313E+13
         SCV =  0.5489281024E+10
         SDV =  -0.3223638975E+16
         SEV =  0.8124186493E+13
         SFV =  -0.5501493760E+10
         F(I) = SAV*(RHO(I)-AAA)**5 + SBV*(RHO(I)-AAA)**4
     +     + SCV*(RHO(I)-AAA)**3 + SDV*(RHO(I)-(AAA-ADEL))**5
     +     + SEV*(RHO(I)-(AAA-ADEL))**4 + SFV*(RHO(I)-(AAA-ADEL))**3
         FP(I) = 5*SAV*(RHO(I)-AAA)**4 + 4*SBV*(RHO(I)-AAA)**3
     +     + 3*SCV*(RHO(I)-AAA)**2 + 5*SDV*(RHO(I)-(AAA-ADEL))**4
     +     + 4*SEV*(RHO(I)-(AAA-ADEL))**3
     +     + 3*SFV*(RHO(I)-(AAA-ADEL))**2
       ELSEIF (RHO(I) .LE. (AA2-ADEL2)) THEN
         FCAM = -11.236
         FCBM = -35.422
         FCCM = 0.52239
         T1 = -FCBM*RHO(I)
         EXPT1 = EXP(T1)
         T2 = FCAM*RHO(I)**(FCCM - 1.0)
         F(I) = T2*EXPT1*RHO(I)
         T3 = -FCBM*RHO(I) + FCCM
         FP(I) = EXPT1 * T3 * T2
       ELSEIF (RHO(I) .LE. AA2) THEN
         SAV =  0.9558951199E+12
         SBV =  0.1648154112E+11
         SCV =  74744608.00
         SDV =  -0.9270320824E+12
         SEV =  0.1628130099E+11
         SFV =  -76418312.00
         F(I) = SAV*(RHO(I)-AA2)**5 + SBV*(RHO(I)-AA2)**4
     +     + SCV*(RHO(I)-AA2)**3 + SDV*(RHO(I)-(AA2-ADEL2))**5
     +   + SEV*(RHO(I)-(AA2-ADEL2))**4 + SFV*(RHO(I)-(AA2-ADEL2))**3
         FP(I) = 5*SAV*(RHO(I)-AA2)**4 + 4*SBV*(RHO(I)-AA2)**3
     +     + 3*SCV*(RHO(I)-AA2)**2 + 5*SDV*(RHO(I)-(AA2-ADEL2))**4
     +     + 4*SEV*(RHO(I)-(AA2-ADEL2))**3
     +     + 3*SFV*(RHO(I)-(AA2-ADEL2))**2
       ELSE
         T1 = -FCB2*RHO(I)
         EXPT1 = EXP(T1)
         T2 = FCA2*RHO(I)**(FCC2 - 1.0)
         F(I) = T2*EXPT1*RHO(I)
         T3 = -FCB2*RHO(I) + FCC2
         FP(I) = EXPT1 * T3 * T2
       ENDIF

            F3(I) = 0.0
            F3P(I) = 0.0
            F2(I) = 0.0
            F2P(I) =0.0

         ELSE IF (ITYPE(I) .EQ. 2) THEN

C    H atom
*  Function 1 goes from 0 < rho <= (a-delta), Spline
* goes from (a-delta) < rho <= a, and Function 2 is for rho > a
 
      AAA = 0.009
      ADEL = 0.007
      FHA1 = -4.8029
      FHB1 = 34.462
      FHC1 = 0.38553
      FHA2 = -74.556
      FHB2 = 7.2784
      FHC2 = 1.0154

      IF (RHO(I) .LE. (AAA-ADEL)) THEN
         T1 = -FHB1*RHO(I)
         EXPT1 = EXP(T1)
         IF (RHO(I) .GT. 0.0) THEN
           T2 = FHA1*RHO(I)**(FHC1 - 1.0)
         ELSE
           T2 = 0.0
         ENDIF
         F(I) = T2*EXPT1*RHO(I)
         T3 = -FHB1*RHO(I) + FHC1
         FP(I) = EXPT1 * T3 * T2
      ELSEIF (RHO(I) .LE. AAA) THEN
         SAV =  0.1840945234E+12
         SBV =  0.3276017408E+10
         SCV =  15102027.00
         SDV =  -0.1303885824E+12
         SEV =  0.2375889152E+10
         SFV =  -11946214.00
         F(I) = SAV*(RHO(I)-AAA)**5 + SBV*(RHO(I)-AAA)**4
     +     + SCV*(RHO(I)-AAA)**3 + SDV*(RHO(I)-(AAA-ADEL))**5
     +     + SEV*(RHO(I)-(AAA-ADEL))**4 + SFV*(RHO(I)-(AAA-ADEL))**3
         FP(I) = 5*SAV*(RHO(I)-AAA)**4 + 4*SBV*(RHO(I)-AAA)**3
     +     + 3*SCV*(RHO(I)-AAA)**2 + 5*SDV*(RHO(I)-(AAA-ADEL))**4
     +     + 4*SEV*(RHO(I)-(AAA-ADEL))**3
     +     + 3*SFV*(RHO(I)-(AAA-ADEL))**2
       ELSE
         T1 = -FHB2*RHO(I)
         EXPT1 = EXP(T1)
         T2 = FHA2*RHO(I)**(FHC2 - 1.0)
         F(I) = T2*EXPT1*RHO(I)
         T3 = -FHB2*RHO(I) + FHC2
         FP(I) = EXPT1 * T3 * T2
       ENDIF

            HDEN(I) = RHO(I)
            FPJC = 0.0D0
            FPJD = 0.0D0

          IF (RHO(I) .LT. 0.5) THEN

******** FOR HRHO, HRHOC *************
          FHA = -0.081682  !front mult
          FHB = 1.0  !R weight on 1st exp
          FHB2= 1.0  !R weight on 2nd exp
          FHC = 5.0   !center on 1st exp
          FHC2= 5.0   !center on 2nd exp
          FHD = -0.  !back add

           T = HRHO(I)
           TEXP1 = EXP(FHB * (T - FHC))
           TEXP2 = EXP(FHB2 * (FHC2 - T))
            T1 = TEXP1 + TEXP2
           T1a = TEXP1 - TEXP2
            T2 = FHB*TEXP1 - FHB2*TEXP2
           T2a = FHB*TEXP1 + FHB2*TEXP2
            F3(I) = (FHA/T1)  + FHD
            F3P(I) = (-FHA)*T2/(T1*T1) 

******** FOR H2RHO, HRHOD *************
          FHA = -0.006505    !front mult
          FHB = 10.0  !R weight on 1st exp
          FHB2= 10.0  !R weight on 2nd exp
          FHC = 4.4 !center on 1st exp
          FHC2= 4.4  !center on 2nd exp
          FHD = 0.  !back add
            T = H2RHO(I)
           TEXP1 = EXP(FHB * (T - FHC))
            TEXP2 = EXP(FHB2 * (FHC2 - T))
            T1 = TEXP1 + TEXP2
           T1a = TEXP1 - TEXP2
            T2 = FHB*TEXP1 - FHB2*TEXP2
           T2a = FHB*TEXP1 + FHB2*TEXP2
            F2(I) = (FHA/T1)  + FHD
            F2P(I) = (-FHA)*T2/(T1*T1) 

79        CONTINUE
712       FORMAT (I2,2X,F9.4,2X,F9.4,2X,F9.4,2X,F9.4,2X,F9.4,2X,F9.4)
         ENDIF
       ENDIF
   80 CONTINUE
C
C Get pair potentials and derivatives for covalent-metal interactions
C    and total covalent-metal potential.
      DO 120 J = 1,NCOV2
C Contribution to covalent-metal potential from embedding function
         VCOV(J) = F(J) + F3(J) + F2(J)          !SW
*         VCOV(J) = F(J) !Excl non-local
         VCOV3(J) = -(F(J) + F3(J) + F2(J))         !SW
*         VCOV3(J) = -F(J) !Excl non-local
         FPJ = FP(J) 
         FPJC = 0.0D0
         FPJD = 0.0D0
*For non-local         FPJC = F3P(J)                !SW
*For non-local         FPJD = F2P(J)                !SW
C
C   Gas-metal Sato parameter and its derivative.  Scaling function h.
         IT = ITYPE(J) - NTYMDM
         A = TRIPH(1,IT)
         B = TRIPH(2,IT)
         C = TRIPH(3,IT)
         T = TANH(A*(RHO(J)-B))
         SATGM = 0.5*T + C
         DSATGM = 0.5*A*(1. - T*T)
C
         NMAX = NCUT(J)
         IF (NMAX .GT. 0) THEN
            DO 110 II = 1,NMAX
               I = ID(II,J)
 

               D = DIJ(I,J)
C Calculate phi and d(phi)/dRij
               CALL SURZIJ(D,ITYPE(I),ITYPE(J),PHI,PHIP,ZCZ,ZCA2)
C Contribution to total energy from pair potential
               VCOV(J) = VCOV(J) + PHI
*         WRITE (6,*) 'J, VCOV(J) in SUREAM: ', J, VCOV(J)
               VCOV3(J) = VCOV3(J) + PHI
        
C Calculate d(rhoa)i/dRij
               RHOPI = RHOP(J,I)
*SW                IF (ITYPE(J) .EQ. 2) THEN
*SW                RHOPIC = DHRHOC(J,I)   !SW
*SW                RHOPID = DHRHOD(J,I)   !SW
*SW                ELSE
                RHOPIC = 0
                RHOPID = 0
*SW                ENDIF
               T = RHOPI*FPJ
                TC = RHOPIC*FPJC       !SW
                TD = RHOPID*FPJD       !SW
               PSIP = PHIP + T
*SW                PSIP = PSIP + TC + TD      !SW
               PSIP3 = SATGM*(PHIP - T)      !SW
*SW                PSIP3 = SATGM*(PHIP - T - TC - TD)      !SW
               DO 90 K = 1,3
                  DRDX = DIJDR(K,I,J)
                  T = PSIP*DRDX
                  DVCOV(K,J,J) = DVCOV(K,J,J) - T
                  IF (I.LE.NATPRM) DVCOV(K,I,J) = DVCOV(K,I,J) + T
                  T = PSIP3*DRDX
                  DVCOV3(K,J,J) = DVCOV3(K,J,J) - T
                  IF (I.LE.NATPRM) DVCOV3(K,I,J) = DVCOV3(K,I,J) + T

   90          CONTINUE
C Calculate d(rhoa)j/dRij
               RHOPJ = RHOP(I,J)
               DEAM = FP(I)*RHOPJ
C Contribution to derivative of metal-metal potential from embedding
C    function
               DO 100 K = 1,3
                  T = DEAM*DIJDR(K,I,J)
                  DVMET(K,J) = DVMET(K,J) - T
                  IF (I.LE.NATPRM) DVMET(K,I) = DVMET(K,I) + T
  100          CONTINUE
  110       CONTINUE
C
            DO 115 II = 1,NMAX
               I = ID(II,J)
               DSATDR = DSATGM*RHOP(J,I)
               HPFP = DSATDR*VCOV3(J)
               DO 114 K = 1,3
                  DRDX = DIJDR(K,I,J)
                  T = HPFP*DRDX
                  DVCOV3(K,J,J) = DVCOV3(K,J,J) - T
                  IF (I.LE.NATPRM) DVCOV3(K,I,J)=DVCOV3(K,I,J) + T
  114          CONTINUE
  115       CONTINUE
         END IF
C
         VCOV3(J) = SATGM*VCOV3(J)
  120 CONTINUE
C
C Get pair potentials and derivatives for metal-metal interactions
C    and total up metal-metal potential
C
C Contribution to energy from embedding function
      VMET = F(NCOVP)
      JSTRT = NCOVP + 1
      DO 150 J = JSTRT,NATOMS
C Contribution to energy from embedding function
         VMET = VMET + F(J)
         IF (J .LE. NATPRM) THEN
            IMAX = J-1
         ELSE
            IMAX = NATPRM
         END IF
         NMAX = NCUT(J)
         IF (NMAX .GT. 0) THEN
            FPJ = FP(J)
            DO 140 II = 1,NMAX
               I = ID(II,J)
               IF (I.GE.NCOVP .AND. I.LE.IMAX) THEN
                  D = DIJ(I,J)
C Calculate phi and d(phi)/dRij
                  CALL SURZIJ(D,ITYPE(I),ITYPE(J),PHI,PHIP,ZCZ,ZCA2)
C Contribution to metal-metal energy from phi
                  VMET = VMET + PHI
C    Calculate d(rhoa)i/dRij
                  RHOPI = RHOP(J,I)
                  PSIP = PHIP + RHOPI*FPJ
C    Calculate d(rhoa)j/dRij
                  RHOPJ = RHOP(I,J)
                  PSIP = PSIP + FP(I)*RHOPJ
                  DO 130 K = 1,3
                     T = PSIP*DIJDR(K,I,J)
                     DVMET(K,I) = DVMET(K,I) + T
                     IF(J.LE.NATPRM) DVMET(K,J) = DVMET(K,J) - T
  130             CONTINUE
               END IF
  140       CONTINUE
         END IF
  150 CONTINUE

* Now add in the derivatives of the Free density correction, which affect
*  the derivatives of the metal-metal term.  The Free density corection
*  makes RHOI(J) (the density contributed to the Ni atom J due to H atoms
*  1-4 (I) a function of the H-C distance.  This is worked in below.

* DFRDX is an array of the derivatives of the embedding energy of the 
*  Ni atoms with respect to the Cartesians of the 5 gas atoms.

      DO 1001 K = 1, 15
       DFRDX(K) = 0.0
1001  CONTINUE

    
      DO 1050 JCOV = 1,4
       NMAX = NCUT(JCOV) 
       DO 1045 KK = 1,3
       K = ((JCOV-1)*3) + KK
       DO 1040 JJ = 1, NMAX
        JMET = ID(JJ,JCOV)
        DFRDX(K) = DFRDX(K)+FP(JMET)*DFREE(JCOV,JMET)*DIJDR(KK,JCOV,5)
        DFRDX(12+KK) = DFRDX(12+KK) + 
     *       FP(JMET)*DFREE(JCOV,JMET)*DIJDR(KK,5,JCOV)
1040   CONTINUE
1045   CONTINUE
1050   CONTINUE

      RETURN
      END
      SUBROUTINE SURR1 (NCOV, NCOVP, NATPRM, NATOMS, R, DIJ, DIJDR,
     *   ITYPE, NCUT, ID, NATMX)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Evaluate Rij and dRij/dxi between all atoms in the primary zone with
C    all other atoms, for Rij less than RCUT include interaction in the
C    lookup list except for covalent-covalent interactions.
C
      DIMENSION R(3,NATOMS), DIJ(NATMX,NATMX), DIJDR(3,NATMX,NATMX),
     *   ITYPE(NATOMS), NCUT(NATMX), ID(NATMX,NATMX)
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      COMMON /SCUTCM/ RCUT(2,NTYPDM), DCUT(NTYPDM)
      DATA EPS /1.0E-13/
C
      DO 20 I = 1,NATPRM
         DIJ(I,I) = 0.0
         DIJDR(1,I,I) = 0.0
         DIJDR(2,I,I) = 0.0
         DIJDR(3,I,I) = 0.0
         IF ((I+1).LE.NATOMS) THEN
            DO 10 J = I+1,NATOMS
               T1 = R(1,I) - R(1,J)
               T2 = R(2,I) - R(2,J)
               T3 = R(3,I) - R(3,J)
               D = T1*T1 + T2*T2 + T3*T3
               D = SQRT(D)
               IF (D .LT. 1.E-13) THEN
                  WRITE(9,'(1X,4HATOM,I3,3HAND,I3,18H ARE TOO CLOSE, D=
     *                  ,1PE16.6)') I,J,D 
                  STOP 100
               ENDIF 
               DIJDR(1,I,J) = T1/D
               DIJDR(2,I,J) = T2/D
               DIJDR(3,I,J) = T3/D
               DIJ(I,J) = D
               DIJ(J,I) = D
               DIJDR(1,J,I) = -DIJDR(1,I,J)
               DIJDR(2,J,I) = -DIJDR(2,I,J)
               DIJDR(3,J,I) = -DIJDR(3,I,J)
   10       CONTINUE
         ENDIF
   20 CONTINUE
      DO 40 I = 1,NATOMS
         IF (I.LE.NCOV) THEN
            JSTRT = NCOVP
            JFINI = NATOMS
         ELSEIF (I.LE.NATPRM) THEN
            JSTRT = 1
            JFINI = NATOMS
         ELSE
            JSTRT = 1
            JFINI = NATPRM
         END IF
         N = 0
         ITYPI = ITYPE(I)
         DO 30 J = JSTRT,JFINI
            IF(I .NE. J .AND. DIJ(I,J) .LT. RCUT(2,ITYPI)) THEN
               N = N + 1
               ID(N,I) = J
            END IF
   30    CONTINUE
         NCUT(I) = N
   40 CONTINUE
      RETURN
      END
      SUBROUTINE SURR2 (NATPRP, NATOMS, R, DIJ, ITYPE, NCUT, ID, NATMX)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Evaluate Rij between all atoms in the secondary zone (from NATRPR to
C    NATOMS)
C
      DIMENSION R(3,NATOMS), DIJ(NATMX,NATMX), ITYPE(NATOMS),
     *   NCUT(NATMX), ID(NATMX,NATMX)
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      COMMON /SCUTCM/ RCUT(2,NTYPDM), DCUT(NTYPDM)
      DATA EPS /1.0E-13/
C
      DIJ(NATPRP,NATPRP) = 0.0
      DO 20 I = NATPRP+1,NATOMS
         DO 10 J = NATPRP,I-1
            T1 = R(1,I) - R(1,J)
            T2 = R(2,I) - R(2,J)
            T3 = R(3,I) - R(3,J)
            D = T1*T1 + T2*T2 + T3*T3
            D = SQRT(D)
            DIJ(I,J) = D
            DIJ(J,I) = D
   10    CONTINUE
         DIJ(I,I) = 0.0
   20 CONTINUE
      DO 40 I = NATPRP,NATOMS
         N = 0
         ITYPI = ITYPE(I)
         DO 30 J = NATPRP,NATOMS
            IF(I .NE. J .AND. DIJ(I,J) .LT. RCUT(2,ITYPI)) THEN 
               N = N + 1
               ID(N,I) = J
            END IF
   30    CONTINUE
         NCUT(I) = N
   40 CONTINUE
      RETURN
      END
      SUBROUTINE SURRHO (Z, DIJ, RHOI, RHOP, ITYPI, NATOMS, NMAX, ID,
     *    NCOV, HRHOC, DHRHOC,HRHOD,DHRHOD, ITYPE,IA,DCA,NFLG)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C Compute contribution of atomic density for atom i to all atoms j in
C    its lookup table.
C                 a
C    RHOI(J) = rho (R  )
C                 i  ij
C                   a
C    RHOP(J) = d[rho (R  )]/dR
C                   i  ij     ij
C
      DIMENSION DIJ(NATOMS), RHOI(NATOMS), RHOP(NATOMS), ID(NATOMS),
     *    HRHOC(NATOMS), DHRHOC(NATOMS), HRHOD(NATOMS),DHRHOD(NATOMS),
     *    ITYPE(NATOMS), DCA(NATOMS)
C NTYMDM - maximum number of metal types
C NTYGDM - maximum number of non-metal types (gas types)
C DCA(1-4) = R(C-H1-4) in Angstroms
C IA is the index of atom I
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      PARAMETER (NMORDM=(NTYGDM*(NTYGDM+1))/2)
      COMMON /SCUTCM/ RCUT(2,NTYPDM), DCUT(NTYPDM)
      COMMON /SRHOCM/ CRI(10,NTYPDM), CI(10,NTYPDM), SI(10,NTYPDM),
     *   FACT(10,NTYPDM), RNSPAR(2,NTYPDM), NI(10,NTYPDM), NTS(NTYPDM),
     *   NTP(NTYPDM), NE(NTYPDM)
      COMMON /FREECM/ DFREE(4,2000), DFRDX(15)
C
      DATA PI /3.1415926/
C
      RNS = RNSPAR(1,ITYPI)
      DRNS = 0.0
      IF (ITYPI .LE. NTYMDM .AND. ABS(Z) .LT. 0.5) THEN
         RNS = RNSPAR(2,ITYPI)
      END IF
      RNP = FLOAT(NE(ITYPI)) - RNS
      DRNP = 0.0
      RCUT1 = RCUT(1,ITYPI)
      RCUT2 = RCUT(2,ITYPI)
      DC = DCUT(ITYPI)
C
      DO 20 M = 1,NMAX
         J = ID(M)
         RIJ = DIJ(J)
         IF( RIJ .LE. RCUT1) THEN
           S = 1.0
           DS = 0.0
         ELSE
           RR1 = RIJ - RCUT1
           RR2 = RIJ - RCUT2
           S = RR2/DC + (SIN(PI*((RR1+RR2)/DC)))/(2.0*PI)
           DS = (1.0 + COS(PI*((RR1+RR2)/DC)))/DC
         ENDIF


         SUMS = 0.0
         DSUMS = 0.0
         SUMD = 0.0
         DSUMD = 0.0

         IF (ITYPI .EQ. 1) THEN
* Ni atom
         DO 10 K = 1,8
               NEXP = NI(K,ITYPI) - 1
               T = CRI(K,ITYPI)*RIJ**NEXP*EXP(-SI(K,ITYPI)*RIJ)
               DT = T*(FLOAT(NEXP)/RIJ - SI(K,ITYPI))
               SUMS = SUMS + T
               DSUMS = DSUMS + DT
10       CONTINUE
         DO 12 KK = 9,10
               NEXP = NI(KK,ITYPI) - 1
               T = CRI(KK,ITYPI)*RIJ**NEXP*EXP(-SI(KK,ITYPI)*RIJ)
               DT = T*(FLOAT(NEXP)/RIJ - SI(KK,ITYPI))
               SUMD = SUMD + T
               DSUMD = DSUMD + DT
12       CONTINUE

         ELSE IF (ITYPI .EQ. 2 ) THEN
* H atom
               NEXP = NI(1,ITYPI) - 1
               T = CRI(1,ITYPI)*RIJ**NEXP*EXP(-SI(1,ITYPI)*RIJ)
               DT = T*(FLOAT(NEXP)/RIJ - SI(1,ITYPI))
               SUMS = SUMS + T
               DSUMS = DSUMS + DT

         ELSE IF (ITYPI .EQ. 3) THEN
* C atom
         DO 14 K = 1,6
               NEXP = NI(K,ITYPI) - 1
               T = CRI(K,ITYPI)*RIJ**NEXP*EXP(-SI(K,ITYPI)*RIJ)
               DT = T*(FLOAT(NEXP)/RIJ - SI(K,ITYPI))
               SUMS = SUMS + T
               DSUMS = DSUMS + DT
14       CONTINUE
         DO 16 KK = 7,10
               NEXP = NI(KK,ITYPI) - 1
               T = CRI(KK,ITYPI)*RIJ**NEXP*EXP(-SI(KK,ITYPI)*RIJ)
               DT = T*(FLOAT(NEXP)/RIJ - SI(KK,ITYPI))
               SUMD = SUMD + T
               DSUMD = DSUMD + DT
16       CONTINUE
         ENDIF
C
         RHOMT = (RNS*SUMS*SUMS + RNP*SUMD*SUMD)/(4.*PI)
         DRHODR = (RNS*SUMS*DSUMS + RNP*SUMD*DSUMD)/(2.*PI)
          RHOI(J) =  RHOMT*S
          RHOP(J) = DRHODR*S + DS*RHOMT

* Add in Free density factor for H atoms
* FREE is a function of the H-Ni distance and the H-C distance, and it
*  gives the value (from 0 to 1) which defines the amount of the 
*  density of the H atom that is available to the Ni atom.  In general,
*  the closer the H atom is to the C atom, the less density is available
*  to the Ni atom, but the closer the H atom is to the Ni atom, the 
*  harder it is for the C atom to extract the density (and hence make it
*  unavailable to the Ni atom).  The result is a balance between the
*  C-H distanmce and he Ni-H distance.
* DFDHNI is the derivative of the FREE function with respect to R(H-Ni)
* DFDCH is the derivative of the FREE function with respect to R(C-H)
* The new value for RHOI(J) and RHOP(J) are calculated, RHOI(J) is still
*  the density contributed by the H atom to Ni atom J (now weighted by the
*  FREE function), and RHOP(J) is still the derivative of the density
*  contributed to Ni atom J by the H atom with respect to the H-Ni distance.
* DFREE(I,J) is the derivative of the density contributed to Ni atom J 
*  by H atom I with respect to the C-H distance.  This quantity is factored
*  in to DVMET later.

      IF (ITYPI .EQ. 2) THEN
*        DFREE(IA,J) = 0.0
*        GOTO 1113
        ALFNI = 1.464   !Angstroms^-1
        ALFC = 1.774   !Angstroms^-1
        REHNI = 1.9    !Angstroms
        RECH = 1.09     !Angstroms
        BFAC1 = EXP(-ALFNI*(RIJ-REHNI))
        BFAC2 = EXP(-ALFC*(DCA(IA)-RECH))
        DENOM = BFAC1 + BFAC2
        FREE = BFAC1 / DENOM
   
        DFDHNI = ((DENOM*(-ALFNI)*BFAC1) - BFAC1*(-ALFNI)*BFAC1)
     *                     / DENOM**2.0
        DFDCH = -BFAC1*(-ALFC)*BFAC2 / DENOM**2.0

***Using only BFAC2... 
*        FREE = 1.0 - BFAC2
*        DFDHNI = 0.0
*        DFDCH = ALFC*BFAC2
***

        RHOP(J) = RHOP(J)*FREE + RHOI(J)*DFDHNI
        DFREE(IA,J) = RHOI(J)*DFDCH
        RHOI(J) = RHOI(J)*FREE 

        GOTO 1113
        IF (J. EQ. 6) THEN
         WRITE (6,*) 'Ni 6, H ',IA,FREE
        ENDIF
        IF (J. EQ. 7) THEN
         WRITE (6,*) 'Ni 7, H ',IA,FREE
        ENDIF
        IF (J. EQ. 8) THEN
         WRITE (6,*) 'Ni 8, H ',IA,FREE
        ENDIF
1113    CONTINUE
      ENDIF

* Do nonlocal term of H atom
       GOTO 19
         IF (ITYPE(J) .EQ. 2) THEN
          IF (RHOMT .GT. 0.0) THEN
            T = RHOMT*30.
            HRHOD(J) = SQRT(T) 
*      IF (NFLG .EQ. 2 .AND. IA .EQ. 24) THEN 
*       STOP 999
*      ENDIF
*            DHRHOD(J) = 0.5*T**(-0.5)*DRHODR*30. 
            T = 52.0834*RHOMT
           HRHOC(J) = T**2.
           DHRHOC(J) = 2.*T**1.*DRHODR*52.0834
          ENDIF
         ELSE
         ENDIF
19    CONTINUE
20    CONTINUE
      RETURN
      END
      SUBROUTINE SURZIJ (R,ITYPE,JTYPE,PHI,DPHI,ZCZ,ZCA2)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C  Calculate the two body interactions and its derivative.
C
C   Z(R) = Z0*(1+BETA*R)*EXP(-ALPHA*R)*S
C   S(R) = (R-(RC+DC)/(-DC) - 1/2PI*SIN(PI*(2R-2RC-DC)/DC))  RC<R<RC+DC
C   Z0(1) for M, Z0(2) for H, etc.
C
C NTYMDM - maximum number of metal types
C NTYGDM - maximum number of non-metal types (gas types)
      PARAMETER (NTYMDM=1, NTYGDM=2, NTYPDM=NTYMDM+NTYGDM)
      PARAMETER (NMORDM=(NTYGDM*(NTYGDM+1))/2)
      COMMON /SCUTCM/ RCUT(2,NTYPDM), DCUT(NTYPDM)
      COMMON /SZRCM/ Z0(NTYPDM), BETA(NTYPDM), ALPHA(NTYPDM), CONV
      DIMENSION RJ(4), WT(4), DWT(4),  ZI(2), DZI(2), LTYP(2)
      DATA PI /3.1415926/
C
      LTYP(1) = ITYPE
      LTYP(2) = JTYPE
      DO 20 I = 1,2
         RCUT1 = RCUT(1,LTYP(I))
         RCUT2 = RCUT(2,LTYP(I))
         DC = DCUT(LTYP(I))
         IF( R .LE. RCUT1) THEN
           S = 1.0
           DS = 0.0
         ELSE
           RR1 = R - RCUT1
           RR2 = R - RCUT2
           S = RR2/DC + (SIN(PI*((RR1+RR2)/DC)))/(2.0*PI)
           DS = (1.0 + COS(PI*((RR1+RR2)/DC)))/DC
         ENDIF

	IF (LTYP(I) .EQ. 2) THEN
* H atom       
           

*EAM6 ZH-->
591        ALVAL = 0.37473
           BEVAL = 0.93232
           GAVAL = 2.77511
           ALVA2 = 0.01012
           BEVA2 = 0.54879
           GAVA2 = 142.67761
           ALVA3 = 0.01073
           BEVA3 = 0.37697
           GAVA3 = 95.4552
           FHA = 0.015
           FHB = 08.0
           FHC = 2.4
           FHD = 0.0
           TEXP1 = EXP(FHB * (R - FHC))
           TEXP2 = EXP(FHB * (FHC - R))
            T1 = TEXP1 + TEXP2
            T2 = FHB*TEXP1 - FHB*TEXP2

           ZI2 = (R/BEVAL)**GAVAL*DEXP(-R/ALVAL)
           DZI2 = (DEXP(-R/ALVAL)*(R/BEVAL)**(GAVAL-1.0))
     +        * (GAVAL/BEVAL - R/(ALVAL*BEVAL))
           ZI2 = ZI2 + (R/BEVA2)**GAVA2*DEXP(-R/ALVA2)
           DZI2 = DZI2 + (DEXP(-R/ALVA2)*(R/BEVA2)**(GAVA2-1.0))
     +        * (GAVA2/BEVA2 - R/(ALVA2*BEVA2))
           ZI2 = ZI2 + (R/BEVA3)**GAVA3*DEXP(-R/ALVA3)
           DZI2 = DZI2 + (DEXP(-R/ALVA3)*(R/BEVA3)**(GAVA3-1.0))
     +        * (GAVA3/BEVA3 - R/(ALVA3*BEVA3))
           ZI2 = ZI2 + (FHA/T1)  + FHD
           DZI2 = DZI2 + (-FHA)*T2/(T1*T1) 
           ZI(I) = ZI2
           DZI(I) = DZI2

* for low R ZH --> EAM7 correction 
           IF (R .LE. 1.09) THEN
             ZLA = -5.957
             ZLB = 9.804
             ZLC = -3.705
             ZI(I) = 1.0 + ZLA*R**5 + ZLB*R**4 + ZLC*R**3
             DZI(I) = 5*ZLA*R**4 + 4*ZLB*R**3 + 3*ZLC*R**2
           ENDIF 
592        CONTINUE

         ELSE IF (LTYP(I) .EQ. 1) THEN
*  Ni atom
           T1 = Z0(LTYP(I))*EXP(-ALPHA(LTYP(I))*R)
           ZI(I) = T1*(1.0 + BETA(LTYP(I))*R)
           DZI(I) = -ALPHA(LTYP(I))*ZI(I) + BETA(LTYP(I))*T1
           DZI(I) = DZI(I)*S + DS*ZI(I)
           ZI(I)  = ZI(I)*S

         ELSE IF (LTYP(I) .EQ. 3) THEN
* C atom
         REWIND 94
         READ (94,*) ZCZ
         READ (94,*) ZCA1
         READ (94,*) ZCA2
         READ (94,*) ZCC1
         READ (94,*) ZCC2
         CLOSE (94)

         ZCB1 = 0.0 !-0.3391
         ZCB2 = 25.914311
         ZCD1 = 0.0 !-3.8634
         ZCD2 = 15.7474
         T1 = ZCA1*EXP(-ZCA2*R)
         T2 = ZCB1*EXP(-ZCB2*R)
         T3 = R*ZCC1*EXP(-ZCC2*R)
         T4 = R*ZCD1*EXP(-ZCD2*R)
         DT1 = T1*(-ZCA2)
         DT2 = T2*(-ZCB2)
         DT3 = (-ZCC2 + (1/R))*T3
         DT4 = (-ZCD2 + (1/R))*T4
         ZI(I) = ZCZ*(T1 + T2 +T3 + T4)
         DZI(I) = ZCZ*(DT1 + DT2 +DT3 + DT4)
        
         ENDIF

 20   CONTINUE
      PHI = ZI(1)*ZI(2)/R
      DZ2 = ZI(1)*DZI(2) + ZI(2)*DZI(1)
      DPHI = CONV*(DZ2 - PHI)/R
      PHI = CONV*PHI

      RETURN
      END



C Eispack routines
      SUBROUTINE REBAK(NM,N,B,DL,M,Z)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      INTEGER I,J,K,M,N,I1,II,NM
      DOUBLE PRECISION B(NM,N),DL(N),Z(NM,M)
      DOUBLE PRECISION X
C
C     THIS SUBROUTINE IS A TRANSLATION OF THE ALGOL PROCEDURE REBAKA,
C     NUM. MATH. 11, 99-110(1968) BY MARTIN AND WILKINSON.
C     HANDBOOK FOR AUTO. COMP., VOL.II-LINEAR ALGEBRA, 303-314(1971).
C
C     THIS SUBROUTINE FORMS THE EIGENVECTORS OF A GENERALIZED
C     SYMMETRIC EIGENSYSTEM BY BACK TRANSFORMING THOSE OF THE
C     DERIVED SYMMETRIC MATRIX DETERMINED BY  REDUC.
C
C     ON INPUT-
C
C        NM MUST BE SET TO THE ROW DIMENSION OF TWO-DIMENSIONAL
C          ARRAY PARAMETERS AS DECLARED IN THE CALLING PROGRAM
C          DIMENSION STATEMENT,
C
C        N IS THE ORDER OF THE MATRIX SYSTEM,
C
C        B CONTAINS INFORMATION ABOUT THE SIMILARITY TRANSFORMATION
C          (CHOLESKY DECOMPOSITION) USED IN THE REDUCTION BY  REDUC
C          IN ITS STRICT LOWER TRIANGLE,
C
C        DL CONTAINS FURTHER INFORMATION ABOUT THE TRANSFORMATION,
C
C        M IS THE NUMBER OF EIGENVECTORS TO BE BACK TRANSFORMED,
C
C        Z CONTAINS THE EIGENVECTORS TO BE BACK TRANSFORMED
C          IN ITS FIRST M COLUMNS.
C
C     ON OUTPUT-
C
C        Z CONTAINS THE TRANSFORMED EIGENVECTORS
C          IN ITS FIRST M COLUMNS.
C
C     QUESTIONS AND COMMENTS SHOULD BE DIRECTED TO B. S. GARBOW,
C     APPLIED MATHEMATICS DIVISION, ARGONNE NATIONAL LABORATORY
C
C     ------------------------------------------------------------------
C
      IF (M .EQ. 0) GO TO 200
C
      DO 100 J = 1, M
C     ********** FOR I=N STEP -1 UNTIL 1 DO -- **********
         DO 100 II = 1, N
            I = N + 1 - II
            I1 = I + 1
            X = Z(I,J)
            IF (I .EQ. N) GO TO 80
C
            DO 60 K = I1, N
   60       X = X - B(K,I) * Z(K,J)
C
   80       Z(I,J) = X / DL(I)
  100 CONTINUE
C
  200 RETURN
C     ********** LAST CARD OF REBAK **********
      END
C
C     ------------------------------------------------------------------
C
      SUBROUTINE REDUC(NM,N,ISGN,A,B,DL,IERR)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      INTEGER I,J,K,N,I1,J1,NM,NN,IERR
      DOUBLE PRECISION A(NM,N),B(NM,N),DL(N)
      DOUBLE PRECISION X,Y
C
C     THIS SUBROUTINE IS A TRANSLATION OF THE ALGOL PROCEDURE REDUC1,
C     NUM. MATH. 11, 99-110(1968) BY MARTIN AND WILKINSON.
C     HANDBOOK FOR AUTO. COMP., VOL.II-LINEAR ALGEBRA, 303-314(1971).
C
C     THIS SUBROUTINE REDUCES THE GENERALIZED SYMMETRIC EIGENPROBLEM
C     AX=(LAMBDA)BX, WHERE B IS POSITIVE DEFINITE, TO THE STANDARD
C     SYMMETRIC EIGENPROBLEM USING THE CHOLESKY FACTORIZATION OF B.
C
C     ON INPUT-
C
C        NM MUST BE SET TO THE ROW DIMENSION OF TWO-DIMENSIONAL
C          ARRAY PARAMETERS AS DECLARED IN THE CALLING PROGRAM
C          DIMENSION STATEMENT,
C
C        N IS THE ORDER OF THE MATRICES A AND B.  IF THE CHOLESKY
C          FACTOR L OF B IS ALREADY AVAILABLE, N SHOULD BE PREFIXED
C          WITH A MINUS SIGN,
C
C        A AND B CONTAIN THE REAL SYMMETRIC INPUT MATRICES.  ONLY THE
C          FULL UPPER TRIANGLES OF THE MATRICES NEED BE SUPPLIED.  IF
C          N IS NEGATIVE, THE STRICT LOWER TRIANGLE OF B CONTAINS,
C          INSTEAD, THE STRICT LOWER TRIANGLE OF ITS CHOLESKY FACTOR L,
C
C        DL CONTAINS, IF N IS NEGATIVE, THE DIAGONAL ELEMENTS OF L.
C
C     ON OUTPUT-
C
C        A CONTAINS IN ITS FULL LOWER TRIANGLE THE FULL LOWER TRIANGLE
C          OF THE SYMMETRIC MATRIX DERIVED FROM THE REDUCTION TO THE
C          STANDARD FORM.  THE STRICT UPPER TRIANGLE OF A IS UNALTERED,
C
C        B CONTAINS IN ITS STRICT LOWER TRIANGLE THE STRICT LOWER
C          TRIANGLE OF ITS CHOLESKY FACTOR L.  THE FULL UPPER
C          TRIANGLE OF B IS UNALTERED,
C
C        DL CONTAINS THE DIAGONAL ELEMENTS OF L,
C
C        IERR IS SET TO
C          ZERO       FOR NORMAL RETURN,
C          7*N+1      IF B IS NOT POSITIVE DEFINITE.
C
C     QUESTIONS AND COMMENTS SHOULD BE DIRECTED TO B. S. GARBOW,
C     APPLIED MATHEMATICS DIVISION, ARGONNE NATIONAL LABORATORY
C
C     ------------------------------------------------------------------
C
      IERR = 0
      NN = IABS(N)
      IF (ISGN .LT. 0) GO TO 100
C     ********** FORM L IN THE ARRAYS B AND DL **********
      DO 80 I = 1, N
         I1 = I - 1
C
         DO 80 J = I, N
            X = B(I,J)
            IF (I .EQ. 1) GO TO 40
C
            DO 20 K = 1, I1
   20       X = X - B(I,K) * B(J,K)
C
   40       IF (J .NE. I) GO TO 60
            IF (X .LE. 0.0E0) GO TO 1000
            Y = SQRT(X)
            DL(I) = Y
            GO TO 80
   60       B(J,I) = X / Y
   80 CONTINUE
C     ********** FORM THE TRANSPOSE OF THE UPPER TRIANGLE OF INV(L)*A
C                IN THE LOWER TRIANGLE OF THE ARRAY A **********
  100 DO 200 I = 1, NN
         I1 = I - 1
         Y = DL(I)
C
         DO 200 J = I, NN
            X = A(I,J)
            IF (I .EQ. 1) GO TO 180
C
            DO 160 K = 1, I1
  160       X = X - B(I,K) * A(J,K)
C
  180       A(J,I) = X / Y
  200 CONTINUE
C     ********** PRE-MULTIPLY BY INV(L) AND OVERWRITE **********
      DO 300 J = 1, NN
         J1 = J - 1
C
         DO 300 I = J, NN
            X = A(I,J)
            IF (I .EQ. J) GO TO 240
            I1 = I - 1
C
            DO 220 K = J, I1
  220       X = X - A(K,J) * B(I,K)
C
  240       IF (J .EQ. 1) GO TO 280
C
            DO 260 K = 1, J1
  260       X = X - A(J,K) * B(I,K)
C
  280       A(I,J) = X / DL(I)
  300 CONTINUE
C
      GO TO 1001
C     ********** SET ERROR -- B IS NOT POSITIVE DEFINITE **********
 1000 IERR = 7 * N + 1
 1001 RETURN
C     ********** LAST CARD OF REDUC **********
      END
      SUBROUTINE TQL2P(NM,N,D,E,Z,IERR)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      INTEGER I,J,K,L,M,N,II,L1,NM,MML,IERR
      DOUBLE PRECISION D(N),E(N),Z(NM,N)
      DOUBLE PRECISION B,C,F,G,H,P,R,S,MACHEP
C
C     THIS SUBROUTINE IS A TRANSLATION OF THE ALGOL PROCEDURE TQL2,
C     NUM. MATH. 11, 293-306(1968) BY BOWDLER, MARTIN, REINSCH, AND
C     WILKINSON.
C     HANDBOOK FOR AUTO. COMP., VOL.II-LINEAR ALGEBRA, 227-240(1971).
C
C     THIS SUBROUTINE FINDS THE EIGENVALUES AND EIGENVECTORS
C     OF A SYMMETRIC TRIDIAGONAL MATRIX BY THE QL METHOD.
C     THE EIGENVECTORS OF A FULL SYMMETRIC MATRIX CAN ALSO
C     BE FOUND IF  TRED2  HAS BEEN USED TO REDUCE THIS
C     FULL MATRIX TO TRIDIAGONAL FORM.
C
C     ON INPUT-
C
C        NM MUST BE SET TO THE ROW DIMENSION OF TWO-DIMENSIONAL
C          ARRAY PARAMETERS AS DECLARED IN THE CALLING PROGRAM
C          DIMENSION STATEMENT,
C
C        N IS THE ORDER OF THE MATRIX,
C
C        D CONTAINS THE DIAGONAL ELEMENTS OF THE INPUT MATRIX,
C
C        E CONTAINS THE SUBDIAGONAL ELEMENTS OF THE INPUT MATRIX
C          IN ITS LAST N-1 POSITIONS.  E(1) IS ARBITRARY,
C
C        Z CONTAINS THE TRANSFORMATION MATRIX PRODUCED IN THE
C          REDUCTION BY  TRED2, IF PERFORMED.  IF THE EIGENVECTORS
C          OF THE TRIDIAGONAL MATRIX ARE DESIRED, Z MUST CONTAIN
C          THE IDENTITY MATRIX.
C
C      ON OUTPUT-
C
C        D CONTAINS THE EIGENVALUES IN ASCENDING ORDER.  IF AN
C          ERROR EXIT IS MADE, THE EIGENVALUES ARE CORRECT BUT
C          UNORDERED FOR INDICES 1,2,...,IERR-1,
C
C        E HAS BEEN DESTROYED,
C
C        Z CONTAINS ORTHONORMAL EIGENVECTORS OF THE SYMMETRIC
C          TRIDIAGONAL (OR FULL) MATRIX.  IF AN ERROR EXIT IS MADE,
C          Z CONTAINS THE EIGENVECTORS ASSOCIATED WITH THE STORED
C          EIGENVALUES,
C
C        IERR IS SET TO
C          ZERO       FOR NORMAL RETURN,
C          J          IF THE J-TH EIGENVALUE HAS NOT BEEN
C                     DETERMINED AFTER 30 ITERATIONS.
C
C     QUESTIONS AND COMMENTS SHOULD BE DIRECTED TO B. S. GARBOW,
C     APPLIED MATHEMATICS DIVISION, ARGONNE NATIONAL LABORATORY
C
C     ------------------------------------------------------------------
C
C     ********** MACHEP IS A MACHINE DEPENDENT PARAMETER SPECIFYING
C                THE RELATIVE PRECISION OF FLOATING POINT ARITHMETIC.
C                For the VAX it is set to 2**(-55)
C                **********
C
      MACHEP = 2.0D0**(-46)
C
      IERR = 0
      IF (N .EQ. 1) GO TO 1001
C
      DO 100 I = 2, N
  100 E(I-1) = E(I)
C
      F = 0.0E0
      B = 0.0E0
      E(N) = 0.0E0
C
      DO 240 L = 1, N
         J = 0
         H = MACHEP * (ABS(D(L)) + ABS(E(L)))
         IF (B .LT. H) B = H
C     ********** LOOK FOR SMALL SUB-DIAGONAL ELEMENT **********
         DO 110 M = L, N
            IF (ABS(E(M)) .LE. B) GO TO 120
C     ********** E(N) IS ALWAYS ZERO, SO THERE IS NO EXIT
C                THROUGH THE BOTTOM OF THE LOOP **********
  110    CONTINUE
C
  120    IF (M .EQ. L) GO TO 220
  130    IF (J .EQ. 30) GO TO 1000
         J = J + 1
C     ********** FORM SHIFT **********
         L1 = L + 1
         G = D(L)
         P = (D(L1) - G) / (2.0E0 * E(L))
         R = SQRT(P*P+1.0E0)
         D(L) = E(L) / (P + SIGN(R,P))
         H = G - D(L)
C
         DO 140 I = L1, N
  140    D(I) = D(I) - H
C
         F = F + H
C     ********** QL TRANSFORMATION **********
         P = D(M)
         C = 1.0E0
         S = 0.0E0
         MML = M - L
C     ********** FOR I=M-1 STEP -1 UNTIL L DO -- **********
         DO 200 II = 1, MML
            I = M - II
            G = C * E(I)
            H = C * P
            IF (ABS(P) .LT. ABS(E(I))) GO TO 150
            C = E(I) / P
            R = SQRT(C*C+1.0E0)
            E(I+1) = S * P * R
            S = C / R
            C = 1.0E0 / R
            GO TO 160
  150       C = P / E(I)
            R = SQRT(C*C+1.0E0)
            E(I+1) = S * E(I) * R
            S = 1.0E0 / R
            C = C * S
  160       P = C * D(I) - S * G
            D(I+1) = H + S * (C * G + S * D(I))
C     ********** FORM VECTOR **********
            DO 180 K = 1, N
               H = Z(K,I+1)
               Z(K,I+1) = S * Z(K,I) + C * H
               Z(K,I) = C * Z(K,I) - S * H
  180       CONTINUE
C
  200    CONTINUE
C
         E(L) = S * P
         D(L) = C * P
         IF (ABS(E(L)) .GT. B) GO TO 130
  220    D(L) = D(L) + F
  240 CONTINUE
C     ********** ORDER EIGENVALUES AND EIGENVECTORS **********
      DO 300 II = 2, N
         I = II - 1
         K = I
         P = D(I)
C
         DO 260 J = II, N
            IF (D(J) .GE. P) GO TO 260
            K = J
            P = D(J)
  260    CONTINUE
C
         IF (K .EQ. I) GO TO 300
         D(K) = D(I)
         D(I) = P
C
         DO 280 J = 1, N
            P = Z(J,I)
            Z(J,I) = Z(J,K)
            Z(J,K) = P
  280    CONTINUE
C
  300 CONTINUE
C
      GO TO 1001
C     ********** SET ERROR -- NO CONVERGENCE TO AN
C                EIGENVALUE AFTER 30 ITERATIONS **********
 1000 IERR = L
 1001 RETURN
C     ********** LAST CARD OF TQL2 **********
      END
      SUBROUTINE TRED2(NM,N,A,D,E,Z)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      INTEGER I,J,K,L,N,II,NM,JP1
      DOUBLE PRECISION A(NM,N),D(N),E(N),Z(NM,N)
      DOUBLE PRECISION F,G,H,HH,SCALE
C
C     THIS SUBROUTINE IS A TRANSLATION OF THE ALGOL PROCEDURE TRED2,
C     NUM. MATH. 11, 181-195(1968) BY MARTIN, REINSCH, AND WILKINSON.
C     HANDBOOK FOR AUTO. COMP., VOL.II-LINEAR ALGEBRA, 212-226(1971).
C
C     THIS SUBROUTINE REDUCES A REAL SYMMETRIC MATRIX TO A
C     SYMMETRIC TRIDIAGONAL MATRIX USING AND ACCUMULATING
C     ORTHOGONAL SIMILARITY TRANSFORMATIONS.
C
C     ON INPUT-
C
C        NM MUST BE SET TO THE ROW DIMENSION OF TWO-DIMENSIONAL
C          ARRAY PARAMETERS AS DECLARED IN THE CALLING PROGRAM
C          DIMENSION STATEMENT,
C
C        N IS THE ORDER OF THE MATRIX,
C
C        A CONTAINS THE REAL SYMMETRIC INPUT MATRIX.  ONLY THE
C          LOWER TRIANGLE OF THE MATRIX NEED BE SUPPLIED.
C
C     ON OUTPUT-
C
C        D CONTAINS THE DIAGONAL ELEMENTS OF THE TRIDIAGONAL MATRIX,
C
C        E CONTAINS THE SUBDIAGONAL ELEMENTS OF THE TRIDIAGONAL
C          MATRIX IN ITS LAST N-1 POSITIONS.  E(1) IS SET TO ZERO,
C
C        Z CONTAINS THE ORTHOGONAL TRANSFORMATION MATRIX
C          PRODUCED IN THE REDUCTION,
C
C        A AND Z MAY COINCIDE.  IF DISTINCT, A IS UNALTERED.
C
C     QUESTIONS AND COMMENTS SHOULD BE DIRECTED TO B. S. GARBOW,
C     APPLIED MATHEMATICS DIVISION, ARGONNE NATIONAL LABORATORY
C
C     ------------------------------------------------------------------
C
      DO 100 I = 1, N
C
         DO 100 J = 1, I
            Z(I,J) = A(I,J)
  100 CONTINUE
C
      IF (N .EQ. 1) GO TO 320
C     ********** FOR I=N STEP -1 UNTIL 2 DO -- **********
      DO 300 II = 2, N
         I = N + 2 - II
         L = I - 1
         H = 0.0E0
         SCALE = 0.0E0
         IF (L .LT. 2) GO TO 130
C     ********** SCALE ROW (ALGOL TOL THEN NOT NEEDED) **********
         DO 120 K = 1, L
  120    SCALE = SCALE + ABS(Z(I,K))
C
         IF (SCALE .NE. 0.0E0) GO TO 140
  130    E(I) = Z(I,L)
         GO TO 290
C
  140    DO 150 K = 1, L
            Z(I,K) = Z(I,K) / SCALE
            H = H + Z(I,K) * Z(I,K)
  150    CONTINUE
C
         F = Z(I,L)
         G = -SIGN(SQRT(H),F)
         E(I) = SCALE * G
         H = H - F * G
         Z(I,L) = F - G
         F = 0.0E0
C
         DO 240 J = 1, L
            Z(J,I) = Z(I,J) / H
            G = 0.0E0
C     ********** FORM ELEMENT OF A*U **********
            DO 180 K = 1, J
  180       G = G + Z(J,K) * Z(I,K)
C
            JP1 = J + 1
            IF (L .LT. JP1) GO TO 220
C
            DO 200 K = JP1, L
  200       G = G + Z(K,J) * Z(I,K)
C     ********** FORM ELEMENT OF P **********
  220       E(J) = G / H
            F = F + E(J) * Z(I,J)
  240    CONTINUE
C
         HH = F / (H + H)
C     ********** FORM REDUCED A **********
         DO 260 J = 1, L
            F = Z(I,J)
            G = E(J) - HH * F
            E(J) = G
C
            DO 260 K = 1, J
               Z(J,K) = Z(J,K) - F * E(K) - G * Z(I,K)
  260    CONTINUE
C
  290    D(I) = H
  300 CONTINUE
C
  320 D(1) = 0.0E0
      E(1) = 0.0E0
C     ********** ACCUMULATION OF TRANSFORMATION MATRICES **********
      DO 500 I = 1, N
         L = I - 1
         IF (D(I) .EQ. 0.0E0) GO TO 380
C
         DO 360 J = 1, L
            G = 0.0E0
C
            DO 340 K = 1, L
  340       G = G + Z(I,K) * Z(K,J)
C
            DO 360 K = 1, L
               Z(K,J) = Z(K,J) - G * Z(K,I)
  360    CONTINUE
C
  380    D(I) = Z(I,I)
         Z(I,I) = 1.0E0
         IF (L .LT. 1) GO TO 500
C
         DO 400 J = 1, L
            Z(I,J) = 0.0E0
            Z(J,I) = 0.0E0
  400    CONTINUE
C
  500 CONTINUE
C
      RETURN
C     ********** LAST CARD OF TRED2 **********
      END

      SUBROUTINE SURF2(V, COORD, DX,DXXM, N3TM,IFLAG9)
C
C   System:    CH5 
C   Reference: T. Joseph, R. Steckler, and D. G. Truhlar
C              J. Chem. Phys. 87, 7036-7049 (1987).
C   This is a driver routine for the CH5 potential energy surfaces J1 and J2.
C   This driver reads in the potential parameters from FORTRAN unit 4; the
C   potential parameters for the surface J1 are different from those for J2.
C
C   SETUP must be called once before any calls to SURF.
C   The cartesian coordinates, potential energy, and derivatives of the energy
C   with respect to the cartesian coordinates are passed by the calling  
C   program in the argument list as follows:
C        CALL SURF (V, X, DX, N3TM)
C   where X and DX are arrays dimensioned N3TM, and N3TM must be greater
C   than or equal to 15 (3*number of atoms).  
C   All the information passed to and from the potential energy surface 
C   routine is in hartree atomic units.  
C
C        This potential is written such that:
C                       X(1)  - X(3)  : X, Y, Z for H1
C                       X(4)  - X(6)  : X, Y, Z for H2
C                       X(7)  - X(9)  : X, Y, Z for H3
C                       X(10) - X(12) : X, Y, Z for H4
C                       X(13) - X(15) : X, Y, Z for C 
C                       X(16) - X(18) : X, Y, Z to represent surface if necc. 
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      PARAMETER (NATDM = 53)
      PARAMETER (NATMX=1601, NCOVMX=5, NVCDM=(NCOVMX*(NCOVMX+1))/2)
      COMMON /SURCM1/ R(3,NATMX), DIJ(NATMX,NATMX),
     *   DIJDR(3,NATMX,NATMX), VCOV(NVCDM), DVCOV(3,NATDM,NVCDM),
     *   VCOV3(NVCDM), DVCOV3(3,NATDM,NVCDM), DVMET(3,NATDM),
     *   RHOS(NATMX), RHO(NATMX), RHOP(NATMX,NATMX), RHOI(NATMX),
     *   FE(NATMX), FP(NATMX), EZERO, ITYPE(NATMX), NATPRM, NATPRP,
     *   NCOV, NCOVP, NMET, NMETP,NATOMS, NBOND, NBONDC, INDGS,
     * NCUT(NATMX),ID(NATMX,NATMX),NCOV2,NBONDC2,NBOND2,NFRST(NVCDM)

      COMMON /ICORCM/ RR(15),DERR(15)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /MAPCM/CDRA,CDRB,HDRA,HDRB,HDRC,MAPB,MAPB2(20,5),DVDP(5)

      DIMENSION X(6),Y(6),Z(6),DRDX(15,18),DEDX(18),VDXXM(20,3*NATDM)
      DIMENSION DRDXM(15,3*NATDM),DEDXM(3*NATDM),DXXM(3*NATDM)
      DIMENSION COORD(N3TM),DX(N3TM),VDX(20,N3TM),VE(20),F(20),
     *  DNORM(20,N3TM),VDX2(20,N3TM),DVBDX(3,NCOVMX),IM(18),INCL(20)    
C
C
C     PUT COORDINATES IN PROPER ARRAYS
C
      IPT = 1
      DO 10 I = 1, 6
         X(I) = COORD(IPT)
         Y(I) = COORD(IPT+1)
         Z(I) = COORD(IPT+2)
         IPT = IPT+3
   10 CONTINUE
C Assign dummy values to the surface point.  These are arbitrary values
C that just allow the DISTA subroutine to function properly.  All R values
C that involve this surface point ultimately will be calculated using the 
C maps.  Then, for OOPB, when implied X, Y, and Z values are needed to 
C calculate necessary dot and cross products, subroutine XYZ6 will be called
C to determine them.  Bottom line is that the three numbers below are
C completely arbitrary and have no effect on the calculations.
         X(6) = X(5)
         Y(6) = Y(5)
         Z(6) = 0.0
         TC16 = COORD(16)
         TC17 = COORD(17)
         TC18 = COORD(18)
         COORD(16)= X(6)
         COORD(17)= Y(6)
         COORD(18)= Z(6)
C

      V = 0.0
      K = 1
      VF = 0.0
      DO 12 J = 1,18
       DO 12 M = 1,20
        DNORM(M,J) = 0.0
12    CONTINUE

* Go through all combinations of Ha & Hb (there are 20)
      DO 230 IA = 1, 6
        DO 225 IB = 1,6
          IF (IA .EQ. 5 .OR. IB .EQ. 5 .OR. IB .EQ. IA) GOTO 225
          IM(1) = IA
          IM(6) = IB 

      ENERGY = 0.0
15      CONTINUE 
        CALL POT (0, COORD, DX, N3TM, IA, IB, K, IFLAG9, IM,
     +   X,Y,Z,DRDX,DEDX,ENERGY,DXXM)

* F(K) is the weighting factor for combination # K
      R25 = RR(5)*RR(5)
      R21 = RR(1)*RR(1)
      RHHA = (RR(10) + RR(11) + RR(12)) / 3.0
      RH8 = RHHA**6.0 
      RH7 = 6.0*RHHA**(5.0)
      FBASE = (R25/RR(6))**(6.0)
      PRE = (6.0)*(R25/RR(6))**(5.0) / (RR(6)*RR(6))
      F(K) = (RH8*FBASE)**(2.0)
      POST = 2.0 *(RH8*FBASE)**(1.0)

* DNORM Calculations      
* DNORM(1-20,1-18) are the derivatives of the weighting factor, F(K), 
*  wrt to the 18 coordinates.  The sum over all 20 derivatives for 
*  a given coordinate is the derivative of the normalization factor
*  wrt that coordinate.

*      WRITE (6,*) 'IM: ',IM(1),IM(2),IM(3),IM(4),IM(5),IM(6)

* d{F(K)}/d{IM(1)}
      DNORM(K,3*(IM(1)-1)+1) = DNORM(K,3*(IM(1)-1)+1) + POST*(
     * RH8*PRE*(-1.0*R25*DRDX(6,IM(1))) + (FBASE*RH7/3.0)*
     * (DRDX(10,IM(1)) + DRDX(11,IM(1)) + DRDX(12,IM(1))))
      DNORM(K,3*(IM(1)-1)+2) = DNORM(K,3*(IM(1)-1)+2) + POST*(
     * RH8*PRE*(-1.0*R25*DRDX(6,IM(1)+6)) + (FBASE*RH7/3.0)*
     * (DRDX(10,IM(1)+6) + DRDX(11,IM(1)+6) + DRDX(12,IM(1)+6))) 
      DNORM(K,3*(IM(1)-1)+3) = DNORM(K,3*(IM(1)-1)+3) + POST*(
     * RH8*PRE*(-1.0*R25*DRDX(6,IM(1)+12)) + (FBASE*RH7/3.0)*
     * (DRDX(10,IM(1)+12) + DRDX(11,IM(1)+12) + DRDX(12,IM(1)+12))) 

* d{F(K)}/d{IM(6)}
      DNORM(K,3*(IM(6)-1)+1) = DNORM(K,3*(IM(6)-1)+1) -
     * POST*RH8*PRE*(R25*DRDX(6,IM(6)) -
     *            RR(6)*2.0*RR(5)*DRDX(5,IM(6)))
      DNORM(K,3*(IM(6)-1)+2) = DNORM(K,3*(IM(6)-1)+2) -
     * POST*RH8*PRE*(R25*DRDX(6,IM(6)+6) -
     *            RR(6)*2.0*RR(5)*DRDX(5,IM(6)+6))
      DNORM(K,3*(IM(6)-1)+3) = DNORM(K,3*(IM(6)-1)+3) -
     * POST*RH8*PRE*(R25*DRDX(6,IM(6)+12) -
     *            RR(6)*2.0*RR(5)*DRDX(5,IM(6)+12)) 

* d{F(K)}/d{IM(5)}
      DNORM(K,3*(IM(5)-1)+1) = DNORM(K,3*(IM(5)-1)+1) +
     * POST*RH8*PRE*(RR(6)*(2.0*RR(5)*DRDX(5,IM(5)))) 
      DNORM(K,3*(IM(5)-1)+2) = DNORM(K,3*(IM(5)-1)+2) +
     * POST*RH8*PRE*(RR(6)*(2.0*RR(5)*DRDX(5,IM(5)+6)))  
      DNORM(K,3*(IM(5)-1)+3) = DNORM(K,3*(IM(5)-1)+3) +
     * POST*RH8*PRE*(RR(6)*(2.0*RR(5)*DRDX(5,IM(5)+12))) 

* d{F(K)}/d{IM(2)}
      DNORM(K,3*(IM(2)-1)+1) = DNORM(K,3*(IM(2)-1)+1) + 
     * POST*FBASE*RH7*DRDX(10,IM(2))/3.0
      DNORM(K,3*(IM(2)-1)+2) = DNORM(K,3*(IM(2)-1)+2) + 
     * POST*FBASE*RH7*DRDX(10,IM(2)+6)/3.0
      DNORM(K,3*(IM(2)-1)+3) = DNORM(K,3*(IM(2)-1)+3) + 
     * POST*FBASE*RH7*DRDX(10,IM(2)+12)/3.0

* d{F(K)}/d{IM(3)}
      DNORM(K,3*(IM(3)-1)+1) = DNORM(K,3*(IM(3)-1)+1) + 
     * POST*FBASE*RH7*DRDX(11,IM(3))/3.0
      DNORM(K,3*(IM(3)-1)+2) = DNORM(K,3*(IM(3)-1)+2) + 
     * POST*FBASE*RH7*DRDX(11,IM(3)+6)/3.0
      DNORM(K,3*(IM(3)-1)+3) = DNORM(K,3*(IM(3)-1)+3) + 
     * POST*FBASE*RH7*DRDX(11,IM(3)+12)/3.0

* d{F(K)}/d{IM(4)}
      DNORM(K,3*(IM(4)-1)+1) = DNORM(K,3*(IM(4)-1)+1) + 
     * POST*FBASE*RH7*DRDX(12,IM(4))/3.0
      DNORM(K,3*(IM(4)-1)+2) = DNORM(K,3*(IM(4)-1)+2) + 
     * POST*FBASE*RH7*DRDX(12,IM(4)+6)/3.0
      DNORM(K,3*(IM(4)-1)+3) = DNORM(K,3*(IM(4)-1)+3) + 
     * POST*FBASE*RH7*DRDX(12,IM(4)+12)/3.0

* Derivatives
* The total energy is E = E1' + E2' + ... + E20'
* where EK' = (F(K)/VF)*EK.  That is, EK' is the weighted normalized
*  energy contribution of combination K (i.e., EK) to the total energy.
* Right now, the derivatives of the energy terms (i.e., DX(M), M=1-18)
*  are the derivatives of the unweighted, un-normalized energy term
*  currently being calculated (EK).
*  That is, DX(M) = {D(EK)/D(R1)} * {D(R1)/D(XM)}
*                 + {D(EK)/D(R2)} * {D(R2)/D(XM)}
*                 + {D(EK)/D(R3)} * {D(R3)/D(XM)} + ...
*                 + {D(EK)/D(R15)} * {D(R15)/D(XM)}
*          = D(EK)/D(XM)
*  where M runs from 1-18 and K runs over all non-weighted, non-normalized
*   combinations, 1-20.


* What has to be added in now is the weighting factor and derivative.
* Because what we eventually want is for DX(M) the be the total derivative
*  of the total energy with respect to coord M.
* Want DX(M) to be D(EK')/D(XM) = {D(EK')/D(R1)} * {D(R1)/D(XM)} + 
*                                 {D(EK')/D(R2)} * {D(R2)/D(XM)} + 
*                                 {D(EK')/D(R3)} * {D(R3)/D(XM)} +  ...
*                                 {D(EK')/D(R15)} * {D(R15)/D(XM)}  
* where M runs from 1-18 and K goes over all weighted, normalized
*   combinations, 1-20.

      DO 115 M = 1,18
        VDX(K,M) = F(K)*DX(M)
115    CONTINUE
        
* VDX(K,M) is now the weighted, un-normalized derivative of the energy
* of combination #K wrt coord M, without the derivative of the normalized
* weight added in yet.

* Same thing has to be done for DXXM.  Right now, DXXM are the derivatives
* of the energy of combination K wrt to the metal coordinates.  Need to 
* weight them properly.

      DO 120 M = 1,3*NATDM
        VDXXM(K,M) = F(K)* DXXM(M)
120   CONTINUE

* VE(K) is the unweighted, un-normalized energy calculated for combination # K
* VF is a running total of the normalization factor, DENOM
* V is a running total of the weighted, un-normalized energy
      VE(K) = ENERGY
      VF = VF + F(K)
      V = V + VE(K)*F(K)
      K = K + 1
225      CONTINUE
230    CONTINUE

*********
* Now that all the combinations have been calculated, go through and 
* eliminate the ones that are non-contributory.  This insures that no
* spurious problems introduced by factors blowing up in the unimportant 
* terms get included in the calculations.  
*********

      VFALL = VF
* First set all combinations to be included
      DO 300 KD = 1, 20
       INCL(KD) = 1
300   CONTINUE 

* Now decide which are to be excluded, and adjust normalization factor
*  and total weighted un-normalized energy accordingly
      DO 310 KD = 1, 20
       IF ((F(KD)/VFALL) .LT. 1.0D-8) THEN
         INCL(KD) = 0
         VF = VF - F(KD) 
         V = V - VE(KD)*F(KD)
       ENDIF
310   CONTINUE
        
* Now VF is the normalization factor for only the combinations that will be
*  included -- i.e., for those whose INCL value is still 1, and V is the
*  total weighted un-normalized energy of the combinations that are to be
*  included.

* At this point, VF is the normalization factor, and V is the total
*  un-normalized energy
      DO 235 KD = 1,20
       IF (INCL(KD) .EQ. 1) THEN
       ENDIF
235   CONTINUE 

* Now, only treat energies and derivatives of combinations that were kept.

      DO 638 K = 1,20
       IF (INCL(K) .EQ. 1) THEN
         DO 634 M = 1,18
          VDX(K,M) = VDX(K,M)/VF
634      CONTINUE
         DO 636 M = 1, 3*NATDM
          VDXXM(K,M) = VDXXM(K,M)/VF
636      CONTINUE
       ENDIF
638    CONTINUE
* Now, VDX(K,M) has been normalized, but the derivative of the normalization
* still has to be added in.

      DO 741 K = 1,20
       IF (INCL(K) .EQ. 1) THEN
       DO 740 M = 1,18
        DVFDX = 0.0
        DO 735 N = 1,20
         IF (INCL(N) .EQ. 1) THEN
         DVFDX = DVFDX + DNORM(N,M)
         ENDIF
735     CONTINUE
        VDX(K,M) = VDX(K,M)+VE(K)*(VF*DNORM(K,M)-F(K)*DVFDX)/(VF*VF)
740    CONTINUE 
       ENDIF
741   CONTINUE 

* Now, VDX(K,M) is the total derivative of EK' wrt coord M -- the 
*  derivative of the weighted, normalized energy of combination K
*  wrt coord M.  Now, for all 18 coordinates, add up all contributions 
*  from each of the 20 combinations to get total DX(M). 

      DO 945 M = 1,18 
       DVTOT = 0.0
       DO 943 K = 1,20
        IF (INCL(K) .EQ. 1) THEN
         DVTOT = DVTOT + VDX(K,M)
        ENDIF
943    CONTINUE
        DX(M) = DVTOT  
945   CONTINUE

* Do the same for VDXXM.

      DO 975 M = 1,3*NATDM 
       DVTOT = 0.0
       DO 973 K = 1,20
        IF (INCL(K) .EQ. 1) THEN
         DVTOT = DVTOT + VDXXM(K,M)
        ENDIF
973    CONTINUE
        DXXM(M) = DVTOT  
975   CONTINUE

* Normailize the energy
      VTOT = 0.0
      DO 947 K = 1, 20
       IF (INCL(K) .EQ. 1) THEN
        VTOT = VTOT + VE(K)*F(K)
       ENDIF
947   CONTINUE
      VTOT = VTOT / VF
      V = VTOT
950    CONTINUE 
955    CONTINUE

         COORD(16) = TC16
         COORD(17) = TC17
         COORD(18) = TC18
      RETURN
      END
C
C
      SUBROUTINE SETUP2(N3TM)
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C   N3TMMN = 3 * NATOMS
C   NATOMS = the number of atoms represented by this potential function
C
C   The variable N3TMMN is the minimum value of N3TM allowed to be 
C   passed by the calling routine for the number of cartesian 
C   coordinates needed to represent the full system represented by this 
C   potential energy surface routine.
C   N3TM must be greater than or equal to N3TMMN.
C
      PARAMETER (N3TMMN = 15)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /PDT2CM/ PI,APHI,BPHI,CPHI,PCH4,FCH3,HCH3,RNOT,A3,B3,DELT, 
     *   DIJ,A,B,C0,D,REX
      COMMON /PDT3CM/ FK0,FA,CA,CB
      CHARACTER*5 SURFNM
C
C  CHECK THE NUMBER OF CARTESIAN COORDINATES SET BY THE CALLING PROGRAM
C
      IF (N3TM .LT. N3TMMN) THEN
          WRITE (6, 6000) N3TM, N3TMMN
          STOP 'SETUP 1'
      ENDIF
C
C  OPEN THE POTENTIAL DATA FILE 
C
*       OPEN (UNIT=4, FILE='potch5.dat', STATUS='OLD', 
*     *       FORM='FORMATTED', ERR=6100)
C
C
      REWIND (7)
      READ (7, 1000) SURFNM
      READ (7,1100) (D1(I),I=1,3)
      READ (7,1100) (D3(I),I=1,3)
      READ (7,1200) B1,C1
      WRITE (6,1300) SURFNM
      WRITE (6,1400) (D1(I),I=1,3)
      WRITE (6,1500) (D3(I),I=1,3),(ALPH(I),I=1,3),(RE(I),I=1,3)
      WRITE (6,1600) B1,C1
C
C  CLOSE THE POTENTIAL DATA FILE
C
      CLOSE (7)
C
      RETURN
C
1000  FORMAT(A)
 1100 FORMAT(3F8.5)
 1200 FORMAT(2F6.2)
1300  FORMAT(/,2X,T5,'SETUP has been called for the CH5 ',A3,
     *               'potential energy surface',
     *       //,2X,T5,'Triplet potential parameters:')
1400  FORMAT(2X,T5,'D1:',T12,F8.5,T22,F8.5,T32,F8.5)
1500  FORMAT(2X,T5,'D3:',T12,F8.5,T22,F8.5,T32,F8.5,
     *       /,2X,T5,'Alpha:',T12,F8.5,T22,F8.5,T32,F8.5,
     *       /,2X,T5,'Re:',T12,F8.5,T22,F8.5,T32,F8.5)
1600  FORMAT(2X,T5,'B1:',T12,F5.2,T25,'C1:',T32,F8.5)
6000  FORMAT(/,2X,T5,'Warning: N3TM is set equal to ',I3,
     *                  ' but this potential routine',
     *          /,2X,T14,'requires N3TM be greater than or ',
     *                   'equal to ',I3,/)
C
6100  WRITE(6,*)'Error opening potential data file'
      STOP 'SETUP 2'
C
      END
      BLOCK DATA PARMS
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /PDT2CM/ PI,APHI,BPHI,CPHI,PCH4,FCH3,HCH3,RNOT,A3,B3,DELT, 
     *   DIJ,A,B,C0,D,REX
      COMMON /PDT3CM/ FK0,FA,CA,CB
      COMMON /MAPCM/CDRA,CDRB,HDRA,HDRB,HDRC,MAPB,MAPB2(20,5),DVDP(5)
C
C     PARAMETERS USED IN THE RAFF SURFACE - FROM RAFF,
C     JCP  60, (1974), P. 2227. THE VALUES OF SOME PARAMETERS
C     ARE CHANGED  FROM THAT OF  RAFF SURFACE WHILE DESIGNING
C     SURFACE J1 AND J2 AND FEW NEW PARAMETERS ARE INTRODUCED
C
C*    APARM(1) IS CALCULATED IN SUBROUTINE FORCE
C*
C
      DATA ALPH / 0.939D0,1.029955D0,0.939D0 /
      DATA RE / 2.0673D0,1.402D0,2.0673D0 /
      DATA BETA / 0.939D0,1.029955D0,0.939D0 /
      DATA AA / 0.0D0,0.0D0,-2.3603D0 /
      DATA REFV,TAU,CP / 0.0D0,1.9105588D0,0.080768D0 /
      DATA APARM / 4.0D0,0.8999975D0,0.448035D0,0.606528D0,3.239921D0 /
C
      DATA APHI,BPHI,CPHI / 2.509214D-1, -3.9568698D-5, 0.0D0 /
      DATA PCH4,FCH3,HCH3,RNOT / 1.9106D0,2.19D-2,4.38D-02,2.052D0 /
      DATA A3,B3,DELT,DIJ / 2.102956D-2,5.798533D-1,0.1D0,6.275D0 /
      DATA A,B,C0,D / -1.56944D+3,-1.12008D+3,1.5786151D+3,2.67146D0 /
      DATA PI,CA,CB / 3.141592654D0,0.903D0,0.072D0 /
      DATA REX,FK0,FA / 1.18584D0,2.55D0,0.8D0 /
      DATA MAPB2 /4,4,4,5,4,4,4,5,4,4,4,5,4,4,4,5,1,1,1,1,
     * 12,12,12,6,9,14,14,7,9,14,14,7,9,14,14,7,6,10,10,10,
     * 9,14,14,7,12,12,12,6,14,9,15,8,14,9,15,8,10,6,11,11,
     * 14,9,15,8,14,9,15,8,12,12,12,6,15,15,9,9,11,11,6,12,
     * 15,15,9,9,15,15,9,9,15,15,9,9,12,12,12,6,12,12,12,6 /

*It is absolutely vital to understand the IM array.  This is the array that 
* defines the 20 combinations K of IA and IB.  IM(1) is always treated as
* entitiy A, and IM(6) is always treated as entity B.  And IM(5) is always
* the 5th atom in input -- the C atom. 

* It is also vital to understand the MAPB2 array.  This is the array of bonds
* that have to be calculated using the maps (effective R values).  That is, 
* it is the array of R values that involve the surface for each combination K
* of IA and IB (the flagged entities).

*Here is what these key arrays look like:

* K  IM(1) IM(2) IM(3) IM(4) IM(5) IM(6)  R(C-S) R(H1-S) R(H2-S) R(H3-S) R(H4-S)
* 1   1     3     4     6     5     2       4      12      9       14      15
* 2   1     2     4     6     5     3       4      12      14      9       15
* 3   1     2     3     6     5     4       4      12      14      15      9
* 4   1     2     3     4     5     6       5      6       7       8       9
* 5   2     3     4     6     5     1       4      9       12      14      15
* 6   2     1     4     6     5     3       4      14      12      9       15
* 7   2     1     3     6     5     4       4      14      12      15      9
* 8   2     1     3     4     5     6       5      7       6       8       9
* 9   3     2     4     6     5     1       4      9       14      12      15
* 10  3     1     4     6     5     2       4      14      9       12      15
* 11  3     1     2     6     5     4       4      14      15      12      9
* 12  3     1     2     4     5     6       5      7       8       6       9
* 13  4     2     3     6     5     1       4      9       14      15      12
* 14  4     1     3     6     5     2       4      14      9       15      12
* 15  4     1     2     6     5     3       4      14      15      9       12
* 16  4     1     2     3     5     6       5      7       8       9       6
* 17  6     2     3     4     5     1       1      6       10      11      12
* 18  6     1     3     4     5     2       1      10      6       11      12
* 19  6     1     2     4     5     3       1      10      11      6       12
* 20  6     1     2     3     5     4       1      10      11      12      6

* In the IM array, values of 1-5 indicate input atoms 1-5, and a value of 6 
* incicates the surface.
* For example, for K = 4, the surface is treated as entity B (i.e., assumed
* furthest from the C atom) and input atom 1 is treated as entity A (assumed
* closest to entity B).  And R(5) is the C-Ni surface bond and is calculated
* using the maps in DISTA.  R(6), R(7), R(8), and R(9) are the H1-Ni, H2-Ni, 
* H3-Ni, and H4-Ni bonds calculated using the maps in DISTA.  H#-Ni indicates
* the # atom in input.

* A firm grasp of these arrays is key to any future coding!  -Steve

      END
      SUBROUTINE OOPB (VOOP,DVOOP,V,X,DX,N3TM,DR1DX,IM)
C
C     THIS SUBROUTINE CALCULTES THE OUT OF PLANE BEND POTENTIAL THAT
C     RESULTS FROM THE METHYL.  THE FORM USED IS THE SAME AS THAT
C     GIVEN BY DUCHOVIC ET. AL. (JPC 89, 1339, (1984)).
C     THE DERIVATIVES WITH RESPECT TO THE CARTESIAN COORDINATES (X)
C     ARE ALSO COMPUTED AND STORED IN DVOOP.
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION DVOOP(18),XDIF(2),YDIF(2),ZDIF(2),RV(3,3),DRV(3,3,18)
      DIMENSION XMAGR(3),DXMAGR(3,18),DELTA(3),DDELTA(3,18)
      DIMENSION GAMMA(3),DGAMMA(3,18),TOP(3),DTOP(3,18),DCROSS(3,18)
      DIMENSION DGCROS(18),DPHI(18),DFDX(18),DHDX(18),DRDX(18)
C
C
      DIMENSION X(N3TM),DX(N3TM), DR1DX(15), IM(18)
C
      COMMON /ICORCM/ R(15),DER(15)
      COMMON /TESTCM/ GAMMA,DGAMMA
      COMMON /PDT2CM/ PI,APHI,BPHI,CPHI,PCH4,FCH3,HCH3,RNOT,A3,B3,DELT, 
     *   DIJ,A0,B0,C0,D,REX
C
C     START BY COMPUTING THE NECESSARY DIFFERENCES IN THE R1,R2 AND
C     R3 VECTORS.
C
      XDIF(1) = X(3*(IM(3)-1)+1)-X(3*(IM(2)-1)+1)
      YDIF(1) = X(3*(IM(3)-1)+2)-X(3*(IM(2)-1)+2)
      ZDIF(1) = X(3*(IM(3)-1)+3)-X(3*(IM(2)-1)+3)
      XDIF(2) = X(3*(IM(4)-1)+1)-X(3*(IM(2)-1)+1)
      YDIF(2) = X(3*(IM(4)-1)+2)-X(3*(IM(2)-1)+2)
      ZDIF(2) = X(3*(IM(4)-1)+3)-X(3*(IM(2)-1)+3)
C
C     NOW COMPUTE THE INDIVIDUAL COMPONENTS OF THE R1,R2 AND R3 VECTORS
C
       RV(1,1) = X(3*(IM(2)-1)+1) - X(3*(IM(5)-1)+1) 
       RV(1,2) = X(3*(IM(2)-1)+2) - X(3*(IM(5)-1)+2) 
       RV(1,3) = X(3*(IM(2)-1)+3) - X(3*(IM(5)-1)+3) 
       RV(2,1) = X(3*(IM(3)-1)+1) - X(3*(IM(5)-1)+1) 
       RV(2,2) = X(3*(IM(3)-1)+2) - X(3*(IM(5)-1)+2) 
       RV(2,3) = X(3*(IM(3)-1)+3) - X(3*(IM(5)-1)+3) 
       RV(3,1) = X(3*(IM(4)-1)+1) - X(3*(IM(5)-1)+1) 
       RV(3,2) = X(3*(IM(4)-1)+2) - X(3*(IM(5)-1)+2) 
       RV(3,3) = X(3*(IM(4)-1)+3) - X(3*(IM(5)-1)+3) 
C
C     RSTAR IS THE C-H4 BOND LENGTH -- the dist between C & input atom 1
C but now, with IM array, it's C-IM(1) dist.
C
       RSTAR = SQRT((X(3*(IM(1)-1)+1) - X(3*(IM(5)-1)+1))**2
     *       + (X(3*(IM(1)-1)+2) - X(3*(IM(5)-1)+2))**2
     *       + (X(3*(IM(1)-1)+3) - X(3*(IM(5)-1)+3))**2)
       IF (IM(1) .EQ. 6) RSTAR = R(1)
C
C     COMPUTE THE CROSS PRODUCT OF THESE DIFFERENCES
C
      CROSSX = YDIF(1)*ZDIF(2)-YDIF(2)*ZDIF(1)
      CROSSY = ZDIF(1)*XDIF(2)-XDIF(1)*ZDIF(2)
      CROSSZ = XDIF(1)*YDIF(2)-XDIF(2)*YDIF(1)
      GCROSS = SQRT(CROSSX**2+CROSSY**2+CROSSZ**2)
      
C
C     COMPUTE THE THREE TRIPLE PRODUCTS--WITH R1,R2 AND R3 (TOP)
C     AND THEN COMPUTE THE ANGLE GAMMA USED IN DELTA.
C
      DO 20 I = 1, 3
         XMAGR(I) = SQRT(RV(I,1)**2+RV(I,2)**2+RV(I,3)**2)
         TOP(I) = CROSSX*RV(I,1)+CROSSY*RV(I,2)+CROSSZ*RV(I,3)
         GAMMA(I) = +TOP(I)/(GCROSS*XMAGR(I))
   20 CONTINUE
C
C     NOW THE SECOND TERM IN DELTA--PHINOT
C     FIRST THE SWITCHING FUNCTION SPHI THEN PHINOT
C
      SPHI = 0.0D0
      REST = BPHI*(RSTAR-CPHI)**3
      IF (REST.LT.70.0D0) THEN
         EREST = EXP(REST)
         SPHI = 1.0D0-TANH(APHI*(RSTAR-RNOT)*EREST)
      ENDIF
      PHINOT = PCH4+(PCH4-PI/2.0D0)*(SPHI-1.0D0)
C
C     NOW PUT THESE TWO TERMS TOGETHER TO GET EACH DELTA
C
      DO 30 I = 1, 3
         DELTA(I) = ACOS(GAMMA(I))-PHINOT
   30 CONTINUE
C
C     NEXT COMPUTE THE PARTIALS OF DELTA W/R TO EACH X(I)
C      IN DOING THIS COMPUTATION FIRST FOR EACH TERM CALCULATED
C      ABOVE THE PARTIAL WILL BE COMPUTED AND A STORED USING THE
C      SAME VARIABLE WITH A 'D' IN FRONT.
C
C
C     START WITH THE PARTIAL OF CROSS WITH RESPECT TO EACH X(I)
C
      DO 60 I = 1, 3
         DO 40 J = 1,3
            DCROSS(I,(3*(IM(1)-1)+J)) = 0.0D0
            DCROSS(I,(3*(IM(5)-1)+J)) = 0.0D0
            DCROSS(I,(3*(IM(6)-1)+J)) = 0.0D0
   40    CONTINUE
         IF (I.EQ.1) THEN
            DCROSS(I,(3*(IM(2)-1)+1)) = 0.0D0
            DCROSS(I,(3*(IM(2)-1)+2)) = ZDIF(1)-ZDIF(2)
            DCROSS(I,(3*(IM(2)-1)+3)) = YDIF(2)-YDIF(1)
            DCROSS(I,(3*(IM(3)-1)+1)) = 0.0D0
            DCROSS(I,(3*(IM(3)-1)+2)) = ZDIF(2)
            DCROSS(I,(3*(IM(3)-1)+3)) = -YDIF(2)
            DCROSS(I,(3*(IM(4)-1)+1)) = 0.0D0
            DCROSS(I,(3*(IM(4)-1)+2)) = -ZDIF(1)
            DCROSS(I,(3*(IM(4)-1)+3)) = YDIF(1)
         ELSEIF (I.EQ.2) THEN
            DCROSS(I,(3*(IM(2)-1)+1)) = ZDIF(2)-ZDIF(1)
            DCROSS(I,(3*(IM(2)-1)+2)) = 0.0D0
            DCROSS(I,(3*(IM(2)-1)+3)) = XDIF(1)-XDIF(2)
            DCROSS(I,(3*(IM(3)-1)+1)) = -ZDIF(2)
            DCROSS(I,(3*(IM(3)-1)+2)) = 0.0D0
            DCROSS(I,(3*(IM(3)-1)+3)) = XDIF(2)
            DCROSS(I,(3*(IM(4)-1)+1)) = ZDIF(1)
            DCROSS(I,(3*(IM(4)-1)+2)) = 0.0D0
            DCROSS(I,(3*(IM(4)-1)+3)) = -XDIF(1)
         ELSEIF (I.EQ.3) THEN
            DCROSS(I,(3*(IM(2)-1)+1)) = YDIF(1)-YDIF(2)
            DCROSS(I,(3*(IM(2)-1)+2)) = XDIF(2)-XDIF(1)
            DCROSS(I,(3*(IM(2)-1)+3)) = 0.0D0
            DCROSS(I,(3*(IM(3)-1)+1)) = YDIF(2)
            DCROSS(I,(3*(IM(3)-1)+2)) = -XDIF(2)
            DCROSS(I,(3*(IM(3)-1)+3)) = 0.0D0
            DCROSS(I,(3*(IM(4)-1)+1)) = -YDIF(1)
            DCROSS(I,(3*(IM(4)-1)+2)) = XDIF(1)
            DCROSS(I,(3*(IM(4)-1)+3)) = 0.0D0
         ENDIF
   60 CONTINUE
C
C     NOW COMPUTE THE PARTIALS FOR THE THREE R VECTORS
C
C First initialize DRV(1-3,1-3,1-18) array to zero
C
      DO 65 I = 1,3
       DO 65 J = 1,3
        DO 65 K = 1,18
         DRV(I,J,K) = 0.0D0
65    CONTINUE
C 
C Now calculate the values
C
      DO 70 I = 1, 3
         DO 70 J = 1, 3
            DO 70 K = 1, 3
               DRV(I,J,(3*(IM(1)-1))+K) = 0.0D0
               DRV(I,J,(3*(IM(6)-1))+K) = 0.0D0      !SWTest
   70 CONTINUE
      DO 80 K = 4, 6
         DRV(1,K-3,(3*(IM(2)-2))+K) = 1.0D0
   80 CONTINUE
      DO 90 K = 7, 9
         DRV(2,K-6,(3*(IM(3)-3))+K) = 1.0D0
   90 CONTINUE
      DO 100 K = 10, 12 
         DRV(3,K-9,(3*(IM(4)-4))+K) = 1.0D0
  100 CONTINUE
      DO 110 I = 1, 3
         DO 110 J = 1, 3
            DRV(I,J,(3*(IM(5)-1))+J) = -1.0D0
  110 CONTINUE
C
C     NOW COMPUTE THE PARTIALS FOR THE TRIPLE PRODUCT  (TOP)
C
      DO 120 I = 1, 18
         DO 120 J = 1, 3
            DTOP(J,I) = DCROSS(1,I)*RV(J,1)+CROSSX*DRV(J,1,I)+DCROSS(2,I
     *         )*RV(J,2)+CROSSY*DRV(J,2,I)+DCROSS(3,I)*RV(J,3)+CROSSZ*  
     *         DRV(J,3,I)
  120 CONTINUE
C
C     PARTIALS FOR THE MAGNITUDE OF THE CROSS PRODUCT  (GCROSS)
C
      DO 130 I = 1, 18
         DGCROS(I) = (1.0D0/GCROSS)*(DCROSS(1,I)*CROSSX+DCROSS(2,I)*    
     *      CROSSY+DCROSS(3,I)*CROSSZ)
  130 CONTINUE
C
C     PARTIALS FOR THE MAGNITUDE OF R1, R2 AND R3
C
      DO 150 I = 1, 3
         DO 150 J = 1, 18
            DXMAGR(I,J) = 0.0D0
            DO 140 K = 1, 3
               DXMAGR(I,J) = DXMAGR(I,J)+(1.0D0/XMAGR(I))*(RV(I,K)*DRV(I
     *            ,K,J))
  140       CONTINUE
  150 CONTINUE
C
C     NOW WE'RE READY FOR THE PARTIALS OF GAMMA
C
      DO 160 I = 1, 3
         DO 160 J = 1, 18
            DGAMMA(I,J) = +GCROSS*XMAGR(I)*DTOP(I,J)-TOP(I)*(XMAGR(I)*  
     *         DGCROS(J)+GCROSS*DXMAGR(I,J))
            DGAMMA(I,J) = DGAMMA(I,J)/(GCROSS*XMAGR(I))**2
            DGAMMA(I,J) = DGAMMA(I,J)*(-1.0D0)/(SQRT(1.0D0-GAMMA(I)**2)
     *         )
  160 CONTINUE
C
C     NOW THE PARTIAL FOR THE SECOND TERM IN DELTA -- PHINOT
C       FIRST COMPUTE THE PARTIAL OF S(SWITCHING FUNCTION) WITH
C       RESPECT TO RSTAR, THE THE PARTIAL OF RSTAR W/R X(I) AND
C       FINALLY THE PARTIAL OF PHINOT W/R TO S.
C
      DSDR = 0.0D0
      REST = BPHI*(RSTAR-CPHI)**3
      IF (REST.LT.70.0D0) THEN
         TEXP = EXP(REST)
         DSDR = -((SECH(APHI*(RSTAR-RNOT)*TEXP))**2)
         DSDR = DSDR*APHI*TEXP*(1.0D0+(RSTAR-RNOT)*BPHI*3.0D0*(RSTAR-   
     *      CPHI)**2)
      ENDIF
      DO 170 I = 1, 18
         DRDX(I) = 0.0D0
         DPHI(I) = 0.0D0
  170 CONTINUE
C
      CST = 1.0D0/(2.0D0*RSTAR)
      IF (IM(1) .NE. 6) THEN
      DO 180 I = 1, 3
       DRDX(3*(IM(1)-1)+I) =
     *   CST*2.0D0*(X(3*(IM(1)-1)+I)-X(3*(IM(5)-1)+I))
       DRDX(3*(IM(5)-1)+I) = -DRDX(3*(IM(1)-1)+I)
       DPHI(3*(IM(1)-1)+I) =
     *   DRDX(3*(IM(1)-1)+I)*DSDR*(PCH4-PI/2.0D0)
       DPHI(3*(IM(5)-1)+I) = -DPHI(3*(IM(1)-1)+I)
  180 CONTINUE
      ELSE
       DPHI(3*(IM(5)-1)+1) = DR1DX(13)*DSDR*(PCH4-PI/2.0D0)
       DPHI(3*(IM(5)-1)+2) = DR1DX(14)*DSDR*(PCH4-PI/2.0D0)
       DPHI(3*(IM(5)-1)+3) = DR1DX(15)*DSDR*(PCH4-PI/2.0D0)
      ENDIF
C
C     NOW PUT BOTH TERMS TOGETHER TO GET THE PARTIALS OF DELTA
C
      DO 190 I = 1, 3
         DO 190 J = 1, 18
            DDELTA(I,J) = DGAMMA(I,J)-DPHI(J)
  190 CONTINUE
C
C     WE HAVE NOW COMPUTED ALL THE DELTA TERMS.  NEXT COMPUTE THE
C       FORCE CONSTANTS (F AND H) AND THEIR DERIVATIVES.  THE
C       OUT-OF-PLANE BEND ENERGY WILL ALSO BE COMPUTED HERE (VOOP)
C
C     FIRST THE SWITCHING FUNCTION
C
      S3 = 1.0D0-TANH(A3*(RSTAR-RNOT)*(RSTAR-B3)**2)
      F = (1.0D0-S3)*FCH3
      H = (1.0D0-S3)*HCH3
      VOOP = 0.0D0
      DO 200 I = 1, 3
         VOOP = VOOP+F*(DELTA(I)**2)+H*(DELTA(I)**4)
  200 CONTINUE
C
C     PARTIAL OF THE SWITCHING FUNCTION W/R TO RSTAR
C
      DSDR = -(SECH(A3*(RSTAR-RNOT)*(RSTAR-B3)**2)**2)*A3*((RSTAR-B3)**2
     *   +(RSTAR-RNOT)*2*(RSTAR-B3))
      DFDS = -FCH3
      DHDS = -HCH3
C
C     PARTIAL OF EACH FORCE CONSTANT
C
      DO 210 I = 1, 18
         DFDX(I) = 0.0D0
         DHDX(I) = 0.0D0
  210 CONTINUE
      DO 220 I = 1, 3
         DFDX(3*(IM(1)-1)+I) = DFDS*DSDR*DRDX(3*(IM(1)-1)+I)
         DHDX(3*(IM(1)-1)+I) = DHDS*DSDR*DRDX(3*(IM(1)-1)+I)
         DFDX(3*(IM(5)-1)+I) = -DFDX(3*(IM(1)-1)+I)
         DHDX(3*(IM(5)-1)+I) = -DHDX(3*(IM(1)-1)+I)
  220 CONTINUE
C
C    NOW WE ARE READY FOR THE FULL PARTIAL DERIVATIVES OF VOOP
C
                                                                        
      DO 250 I = 1, 18
         TERM1 = 0.0D0
         DO 230 J = 1, 3
            TERM1 = TERM1+DFDX(I)*DELTA(J)**2
  230    CONTINUE
         TERM2 = 2.0D0*DELTA(1)*DDELTA(1,I)+2.0D0*DELTA(2)*DDELTA(2,I)
     *           +2.0D0*DELTA(3)*DDELTA(3,I)
         TERM2 = TERM2*F
         TERM3 = 0.0D0
         DO 240 J = 1, 3
            TERM3 = TERM3+DHDX(I)*DELTA(J)**4
  240    CONTINUE
         TERM4 = 4.0D0*DELTA(1)**3*DDELTA(1,I)+4.0D0*DELTA(2)**3*
     *           DDELTA(2,I)+4.0D0*DELTA(3)**3*DDELTA(3,I)
         TERM4 = TERM4*H
         DVOOP(I) = TERM1+TERM2+TERM3+TERM4
  250 CONTINUE
      RETURN
      END
C
      FUNCTION SECH (X)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      IF (X.GT.70.0D0) THEN
         SECH = 0.0D0
      ELSE
         SECH = 1.0D0/COSH(X)
      ENDIF
      RETURN
      END
                                                                        
      SUBROUTINE THETA (ASF,DASF,ASB,DASB)
C
C     THIS SUBROUTINE COMPUTES THE EQUILIBRIUM THETA AS A FUNCTION OF
C     R (THE AVERAGE C-H BOND LENGTH IN METHANE).
C     THE DERIVATIVE OF THETA WITH RESPECT TO R(I) IS ALSO COMPUTED.
C     NOTE HERE THAT BECAUSE OF SYMMETRY EACH OF THESE PARTIALS IS
C     THE SAME.       ADDED 11/22/85
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      COMMON /ICORCM/ R(15),DER(15)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /PDT2CM/ PI,APHI,BPHI,CPHI,PCH4,FCH3,HCH3,RNOT,A3,B3,DELTA,
     *   DIJ,A0,B0,C0,D0,REX
C
      RAVG = (R(1)+R(2)+R(3)+R(4))/4.0D0
C
C     COMPUTE THETA
C
      
      IF (RAVG.GT.DIJ) THEN
         ASF = PI/2.0D0
         DASF = 0.0D0
      ELSEIF (RAVG.LE.RE(1)) THEN
         ASF = TAU
         DASF = 0.0D0
      ELSEIF (RAVG.GT.RE(1).AND.RAVG.LE.RE(1)+DELTA) THEN
         DELTA2 = DELTA*DELTA
         FK1 = -4.0D0*CP/(DELTA2)
         A = 3.0D0*FK1/(DELTA2)
         B = -(5.0D0*A*DELTA2+FK1)/(2.0D0*DELTA)
         C = -(20.0D0*A*DELTA2+12.0D0*B*DELTA)/6.0D0
         F = TAU
         RDIF = RAVG-RE(1)
         RDIF2 = RDIF*RDIF
         RDIF3 = RDIF2*RDIF
         RDIF4 = RDIF3*RDIF
         RDIF5 = RDIF4*RDIF
         ASF = A*RDIF5+B*RDIF4+C*RDIF3+F
         DASF = 5.0D0*A*RDIF4+4.0D0*B*RDIF3+3.0D0*C*RDIF2
      ELSEIF (RAVG.LE.DIJ-DELTA) THEN
         A = 1.0133    !bohr^-1
         B = -7.9866E-4   !bohr^-3
         C = A*(RAVG-RE(1))*EXP(B*RAVG*RAVG*RAVG)
         TANV = (EXP(C)-EXP(-1.0*C)) / (EXP(C)+EXP(-1.0*C))
         SV = 1.0 - TANV
         ASF = TAU + (TAU - (PI/2.0))*(SV-1.0)
         SECV = 2.0 / (EXP(C)+EXP(-1.0*C))
         
         DASF = (TAU-PI/2.0)*(-1.0*SECV*SECV*
     +     (C*3.0*B*RAVG*RAVG + EXP(B*RAVG*RAVG*RAVG)*A))
      ELSEIF (RAVG.LE.DIJ.AND.RAVG.GT.DIJ-DELTA) THEN
         F = PI/2.0D0
         FK1 = (TAU-4.0D0*CP*(DIJ-DELTA-RE(1))-F)/(DELTA**3)
         FK2 = (-4.0D0*CP)/(DELTA**2)
         A = -3.0D0*(2.0D0*FK1+FK2)/(DELTA**2)
         B = (FK2+5.0D0*A*DELTA**2)/(2.0D0*DELTA)
         C = (12.0D0*B*DELTA-20.0D0*A*DELTA**2)/6.0D0
         RDIF = RAVG-DIJ
         RDIF3 = RDIF*RDIF*RDIF
         RDIF4 = RDIF3*RDIF
         RDIF5 = RDIF4*RDIF
         ASF = A*RDIF5+B*RDIF4+C*RDIF3+F
         DASF = 5.0D0*A*RDIF4+4.0D0*B*RDIF3+3.0D0*C*RDIF*RDIF
      ENDIF
C
C COMPUTE BACKSIDE EQUILIBRIUM ANGLE
C
      XYZ = COS(ASF)
      CTAU = COS(TAU)
      CTAU2 = CTAU*CTAU
      A = (CTAU+0.5D0)/CTAU2
      ASB = ACOS(A*XYZ*XYZ-0.5D0)
      DASB = 2.0D0*A*XYZ*SIN(ASF)*DASF/SIN(ASB)
C
C NOW COMPUTE THE DER W/R TO RI INSTEAD OF RAVG
C
      DASF = DASF/4.0D0
      DASB = DASB/4.0D0
      RETURN
      END

      SUBROUTINE POT (ISWTCH,COORD,DXX,N3TM,IA,IB,KC,IFLAG9,IM,
     +   X,Y,Z,DRDX,DEDX,ENERGY,DXXM)
C
C     SUBROUTINE TO CALCULATE THE CH4-H SURFACE
C     REQUIRES SUBROUTINES DIST,ANGLE, TRI, AND SWITCH
C     ALSO COMPUTES DE/DR FOR ALL R AND STORES RESULTS IN ARRAY DER
C     DEFINITION OF CARTESIAN COORDINATES X(I), Y(I), AND Z(I)
C      I = 1, 2, 3, 4   REFERS TO H1, H2, H3, H4
C      I = 5            REFERS TO C
C      I = 6            REFERS TO H'
C
C     DEFINITION OF THE R-ARRAY  R(I)
C     H1 IS THE ATOM THAT WILL FORM H-H WITH H5 -- IN ALTERNATE RAFF
C      I = 1, 2, 3, 4   REFERS TO C - H(I)
C      I = 5            REFERS TO C - H'
C      I = 6, 7, 8, 9   REFERS TO H' - H(I)
C      I = 10, 11, 12   REFERS TO H1 - H(2,3,4)
C      I = 13, 14       REFERS TO H2 - H(3,4)
C      I = 15           REFERS TO H3 - H4
C***********************************************************************
C***********************************************************************
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION DFR(4),DVOOP(18),Y1(6),Y2(6),F(4),DF(4),DK(6)
C
C
      PARAMETER (NATDM = 53)
      PARAMETER (NATMX=1601, NCOVMX=5, NVCDM=(NCOVMX*(NCOVMX+1))/2)
      DIMENSION COORD(N3TM),DXX(N3TM), CXX(18),DR1DX(15),IM(18)
      DIMENSION X(6),Y(6),Z(6),DRDX(15,18),DEDX(18)
      DIMENSION DRDXM(15,3*NATDM),DEDXM(3*NATDM),DXXM(3*NATDM)
      COMMON /ICORCM/ R(15),DER(15)
C
      COMMON /POTRCM/ AG(6),R2(15),ACS(6),ASS(6)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /DERVCM/ DECCR1,DECCR5,DECCR6
      COMMON /TEMCOM/ RTEM(9),DTEMP(9),ETEM
      COMMON /ALPDCM/ DALP
      COMMON /MAPCM/CDRA,CDRB,HDRA,HDRB,HDRC,MAPB,MAPB2(20,5),DVDP(5)
      COMMON /SURCM1/ RR(3,NATMX), DIJ(NATMX,NATMX),
     *   DIJDR(3,NATMX,NATMX), VCOV(NVCDM), DVCOV(3,NATDM,NVCDM),
     *   VCOV3(NVCDM), DVCOV3(3,NATDM,NVCDM), DVMET(3,NATDM),
     *   RHOS(NATMX), RHO(NATMX), RHOP(NATMX,NATMX), RHOI(NATMX),
     *   FE(NATMX), FP(NATMX), EZERO, ITYPE(NATMX), NATPRM, NATPRP,
     *   NCOV, NCOVP, NMET, NMETP,NATOMS, NBOND, NBONDC, INDGS,
     * NCUT(NATMX),ID(NATMX,NATMX),NCOV2,NBONDC2,NBOND2,NFRST(NVCDM)
      DATA EVCON / 2.721161D+1 /
      DATA BOHR / 0.529167 /
C
C COMPUTE THE INTERPARTICLE DISTANCES R
C
      IFLAG9 = 0
      CALL DISTA (IA,IB, KC,IFLAG9,IM,X,Y,Z)
      IF (IFLAG9 .EQ. 1) THEN
        WRITE (6,*) '(A) IFLAG9 = 1'
        RETURN
      ENDIF
      NMAX = NCUT(5)
      TDRDX = 0.0D0
      TDRDY = 0.0D0
      TDRDZ = 0.0D0
      DO 30 II5 = 1,NMAX
       I5 = ID(II5,5)
       TDRDX = TDRDX + RHOP(5,I5)*DIJDR(1,5,I5) 
       TDRDY = TDRDY + RHOP(5,I5)*DIJDR(2,5,I5) 
       TDRDZ = TDRDZ + RHOP(5,I5)*DIJDR(3,5,I5) 
30    CONTINUE
      DR1DX(13) = DVDP(5)*TDRDX*BOHR
      DR1DX(14) = DVDP(5)*TDRDY*BOHR
      DR1DX(15) = DVDP(5)*TDRDZ*BOHR
    
* DR1DX(13) is the derivative of the mapped R1 wrt X13.  This comes into play
* when K = 17-20, or when R1 is the C-Ni distance and must be mapped.  These
* values will be needed in OOPB in such cases.  At this point, DVDP(5) is the
* derivative of the C-Ni mapped distance wrt the C atom density.  TDRDX is
* the derivative of the C atom density wrt the X coord of the C atom.  14 & 15
* are for Y & Z.
        

C
C **********************************************************************
C***********************************************************************
C COMPUTE THE HCH ANGLES AND STORE RESULTS IN ARRAY AG
C
      CALL ANGLE (X,Y,Z)
C
C***********************************************************************
C
      DO 50 I = 1, 15
         DER(I) = 0.0D0
   50 CONTINUE
C
C  COMPUTE THE MORSE RANGE PARAMETERS ALPH:
C
      CALL CALPHA
C
C
C***********************************************************************
C COMPUTE FORCE CONSTANTS
C COMPUTE ATTENUATION TERMS
C
      XA = R(1)-RE(1)
      XB = R(2)-RE(1)
      XC = R(3)-RE(1)
      XD = R(4)-RE(1)
      XA2 = XA*XA
      XB2 = XB*XB
      XC2 = XC*XC
      XD2 = XD*XD
      XXA = R(6)-RE(2)
      XXB = R(7)-RE(2)
      XXC = R(8)-RE(2)
      XXD = R(9)-RE(2)
       
       EXA11 = 0.0D0
       EXA12 = 0.0D0
       EXA13 = 0.0D0
       EXA14 = 0.0D0
       EXA21 = 0.0D0
       EXA22 = 0.0D0
       EXA23 = 0.0D0
       EXA24 = 0.0D0
      IF (R2(6) .LT. 2500) EXA11 = EXP(-APARM(2)*R2(6))
      IF (R2(7) .LT. 2500) EXA12 = EXP(-APARM(2)*R2(7))
      IF (R2(8) .LT. 2500) EXA13 = EXP(-APARM(2)*R2(8))
      IF (R2(9) .LT. 2500) EXA14 = EXP(-APARM(2)*R2(9))
      IF (XXA .LT. 50) EXA21 = EXP(-APARM(5)*XXA*XXA)
      IF (XXB .LT. 50) EXA22 = EXP(-APARM(5)*XXB*XXB)
      IF (XXC .LT. 50) EXA23 = EXP(-APARM(5)*XXC*XXC)
      IF (XXD .LT. 50) EXA24 = EXP(-APARM(5)*XXD*XXD)

      A11 = 1.0D0-EXA11
      A12 = 1.0D0-EXA12
      A13 = 1.0D0-EXA13
      A14 = 1.0D0-EXA14
      A21 = APARM(3)+APARM(4)*EXA21
      A22 = APARM(3)+APARM(4)*EXA22
      A23 = APARM(3)+APARM(4)*EXA23
      A24 = APARM(3)+APARM(4)*EXA24

       EXF1 = 0.0D0
       EXF2 = 0.0D0
       EXF3 = 0.0D0
       EXF4 = 0.0D0
      IF (XA2 .LT. 2500) EXF1 = EXP(-A21*XA2)
      IF (XB2 .LT. 2500) EXF2 = EXP(-A22*XB2)
      IF (XC2 .LT. 2500) EXF3 = EXP(-A23*XC2)
      IF (XD2 .LT. 2500) EXF4 = EXP(-A24*XD2)

      F(1) = A11*EXF1
      F(2) = A12*EXF2
      F(3) = A13*EXF3
      F(4) = A14*EXF4
C
C DK'S ARE THE FORCE CONSTANTS
C     FIRST COMPUTE THE K0 SINCE IT IS NOW A FUNCTION OF R(1)
C
      CALL FORCE (DADR1)
      DK(1) = APARM(1)*F(1)*F(2)
      DK(2) = APARM(1)*F(1)*F(3)
      DK(3) = APARM(1)*F(1)*F(4)
      DK(4) = APARM(1)*F(2)*F(3)
      DK(5) = APARM(1)*F(2)*F(4)
      DK(6) = APARM(1)*F(3)*F(4)
C
C***********************************************************************
C COMPUTE THE EQUILIBRIUM ANGLES--THETA AND D(THETA)/DR
C
      CALL THETA (ASF,DASF,ASB,DASB)
      DAA = 0.0D0

C
C***********************************************************************
C COMPUTE CONTRIBUTION TO THE TOTAL ENERGY FROM THE ANGLE TERMS
C
      SUM = 0.0D0
      EE = 0.0D0
      IF1 = 1
      IF2 = 2
      IF3 = 3
      IB1 = 4
      IB2 = 5
      IB3 = 6
      FAC4 = 1.0  !3.07
      DO 60 I = 1, 3
         O = AG(I)-ASF
         Y1(I) = O
         Y2(I) = O*O
         Y6 = Y2(I)*Y2(I)*Y2(I)
         Y4 = FAC4*Y2(I)*Y2(I)*Y2(I)
         SUM = SUM+DK(I)*(Y2(I)+Y4)
   60 CONTINUE
      DO 70 I = 4, 6
         Y1(I) = AG(I)-ASB
         Y2(I) = Y1(I)*Y1(I)
         Y6 = Y2(I)*Y2(I)*Y2(I)
         Y4 = FAC4*Y2(I)*Y2(I)*Y2(I)
         SUM = SUM+DK(I)*(Y2(I)+Y4)
   70 CONTINUE
      EE = EE+0.5D0*SUM
C
C***********************************************************************
C COMPUTE DERIVATIVES OF THE ANGLE ATTENUATION TERMS WITH RESPECT TO R6,
C                       AND R9
C
      DFR(1) = 2.0D0*APARM(2)*R(6)*EXA11*EXF1+A11*EXF1*XA2*2.0D0*APARM(4
     *   )*APARM(5)*XXA*EXA21
      DFR(2) = 2.0D0*APARM(2)*R(7)*EXA12*EXF2+A12*EXF2*XB2*2.0D0*APARM(4
     *   )*APARM(5)*XXB*EXA22
      DFR(3) = 2.0D0*APARM(2)*R(8)*EXA13*EXF3+A13*EXF3*XC2*2.0D0*APARM(4
     *   )*APARM(5)*XXC*EXA23
      DFR(4) = 2.0D0*APARM(2)*R(9)*EXA14*EXF4+A14*EXF4*XD2*2.0D0*APARM(4
     *   )*APARM(5)*XXD*EXA24
C
C COMPUTE DERIVATIVES OF ATTENUATION TERMS WITH RESPECT TO R1,R2,R3, AND
C
      DF(1) = -2.0D0*A21*XA*F(1)
      DF(2) = -2.0D0*A22*XB*F(2)
      DF(3) = -2.0D0*A23*XC*F(3)
      DF(4) = -2.0D0*A24*XD*F(4)
102   CONTINUE

C
C***********************************************************************
C ADD IN CONTRIBUTION TO DER FROM DK/DR ANGLE TERMS AND D(THETA)/DR TERM
C FIRST THREE ANGLE TERMS
C
      DO 80 I = 1, 3
         STP = 0.5D0*DK(I)*Y2(I)
         W = DK(I)*Y1(I)
         T4 = FAC4*Y2(I)*Y2(I)*Y2(I)
         STP2 = 0.5D0*DK(I)*T4
         W2 = 3.0D0*DK(I)*T4/Y1(I)
         IF (ABS(F(1)).GT.1.0D-10) DER(1)=DER(1)+
     *      (STP+STP2)*(DF(1)/F(1)+DADR1/APARM(1))+
     *      (W+W2)*(-1.0D0/(R(I+1)*ASS(I))+ACS(I)/(R(1)*ASS(I)))
         IF (ABS(F(I+1)).GT.1.0D-10) DER(I+1)=DER(I+1)+
     *      (STP+STP2)*DF(I+1)/F(I+1)+
     *      (W+W2)*(-1.0D0/(R(1)*ASS(I))+ACS(I)/(ASS(I)*R(I+1)))
         IF (ABS(F(1)).GT.1.0D-10) DER(6)=DER(6)+(STP+STP2)*DFR(1)/F(1)
         IF (ABS(F(I+1)).GT.1.0D-10) DER(I+6)=DER(I+6)+
     *      (STP+STP2)*DFR(I+1)/F(I+1)
         DER(I+9) = DER(I+9)+(W+W2)*R(I+9)/(R(1)*R(I+1)*ASS(I))
   80 CONTINUE
C
C **********************************************************************
C FOURTH AND FIFTH ANGLE TERMS
C
      DO 90 I = 4, 5
       STP = 0.5D0*DK(I)*Y2(I)
       W = DK(I)*Y1(I)
         T4 = FAC4*Y2(I)*Y2(I)*Y2(I)
         STP2 = 0.5D0*DK(I)*T4
         W2 = 3.0D0*DK(I)*T4/Y1(I)
       
       DER(1) = DER(1)+(STP+STP2)*DADR1/APARM(1)
       IF (ABS(F(2)) .GT. 1.0D-10) THEN
        DER(2) = DER(2)+(STP+STP2)*DF(2)/F(2)+
     *    (W+W2)*(-1.0D0/(ASS(I)*R(I-1))+ACS(I)/(ASS(I)*R(2)))
        DER(7) = DER(7)+(STP+STP2)*DFR(2)/F(2)
       ENDIF
       IF (ABS(F(I-1)).GT.1.0D-10) DER(I-1)=DER(I-1)+
     *    (STP+STP2)*DF(I-1)/F(I-1)+
     *    (W+W2)*(-1.0D0/(ASS(I)*R(2))+ACS(I)/(ASS(I)*R(I-1)))
       IF (ABS(F(I-1)).GT.1.0D-10) DER(I+4)=DER(I+4)+
     *    (STP+STP2)*DFR(I-1)/F(I-1)
       DER(I+9) = DER(I+9)+(W+W2)*R(I+9)/(R(2)*R(I-1)*ASS(I))
   90 CONTINUE
C
C CONTRIBUTION FROM SIXTH ANGLE TERM
C
      STP = 0.5D0*DK(6)*Y2(6)
      W = DK(6)*Y1(6)
         T4 = FAC4*Y2(6)*Y2(6)*Y2(I)
         STP2 = 0.5D0*DK(6)*T4
         W2 = 3.0D0*DK(6)*T4/Y1(6)
      DER(1) = DER(1)+(STP+STP2)*DADR1/APARM(1)
      IF (ABS(F(3)) .GT. 1.0D-10) THEN
       DER(3)=DER(3)+(STP+STP2)*DF(3)/F(3)
     *   +(W+W2)*(-1.0D0/(ASS(6)*R(4))+ACS(6)/(ASS(6)*R(3)))
       DER(8)=DER(8)+(STP+STP2)*DFR(3)/F(3)
      ENDIF
      IF (ABS(F(4)) .GT. 1.0D-10) THEN
       DER(4)=DER(4)+(STP+STP2)*DF(4)/F(4)+
     *   (W+W2)*(-1.0D0/(ASS(6)*R(3))+ACS(6)/(ASS(6)*R(4)))
       DER(9) = DER(9)+(STP+STP2)*DFR(4)/F(4)
      ENDIF
      DER(15) = DER(15)+(W+W2)*R(15)/(ASS(6)*R(3)*R(4))
C
C **********************************************************************
C CONTRIBUTION FROM EQ. ANGLE VARIATION TO D(ANGLE)/DR******
C
      DO 100 KLM = 1, 4
         DER(KLM) = DER(KLM)-(DK(IF1)*Y1(IF1)+DK(IF2)*Y1(IF2)+DK(IF3)*Y1
     *      (IF3))*DASF-(DK(IB1)*Y1(IB1)+DK(IB2)*Y1(IB2)+DK(IB3)*Y1(IB3)
     *      )*DASB
         DER(KLM) = DER(KLM)-(DK(IF1)*Y1(IF1)**5.0
     *                       +DK(IF2)*Y1(IF2)**5.0
     *                       +DK(IF3)*Y1(IF3)**5.0)*(3.0*FAC4*DASF)
     *                      -(DK(IB1)*Y1(IB1)**5.0
     *                       +DK(IB2)*Y1(IB2)**5.0
     *                       +DK(IB3)*Y1(IB3)**5.0)*(3.0*FAC4*DASB)
  100 CONTINUE
      DER(5) = DER(5)-(DK(IF1)*Y1(IF1)+DK(IF2)*Y1(IF2)+DK(IF3)*Y1(IF3))*
     *   DAA-(DK(IB1)*Y1(IB1)+DK(IB2)*Y1(IB2)+DK(IB3)*Y1(IB3))*3.0D0*   
     *   SIN(ASF)*COS(ASF)*DAA/SIN(ASB)
         DER(5) = DER(5)-(DK(IF1)*Y1(IF1)**5.0
     *                       +DK(IF2)*Y1(IF2)**5.0
     *                       +DK(IF3)*Y1(IF3)**5.0)*(3.0*FAC4*DAA)
     *                      -(DK(IB1)*Y1(IB1)**5.0
     *                       +DK(IB2)*Y1(IB2)**5.0
     *                       +DK(IB3)*Y1(IB3)**5.0)
     *         *(3.0*FAC4*DASB)*3.0D0*SIN(ASF)*COS(ASF)*DAA/SIN(ASB)
101     CONTINUE
C
C **********************************************************************
C
      
      ENERGY = EE/EVCON+REFV
* Energy is now in hartrees
C
C      CALCULATE DRDX ARRAY
C
      CALL DRDXC (KC,IM,X,Y,Z,DRDX,DRDXM)

      DO 110 I = 1, 15
         DER(I) = DER(I)/EVCON
  110 CONTINUE
         DVDP(5) = DVDP(5)*DER(MAPB2(KC,1))
         DVDP(1) = DVDP(1)*DER(MAPB2(KC,2))
         DVDP(2) = DVDP(2)*DER(MAPB2(KC,3))
         DVDP(3) = DVDP(3)*DER(MAPB2(KC,4))
         DVDP(4) = DVDP(4)*DER(MAPB2(KC,5))
* Now, DVDP are the derivatives of Vbend wrt the density due to the metal
* of each of the 5 gas atoms.  DVDP(1-4) = dE/dp(1-4) -- the H atoms, and
* DVDP(5) = dE/dp(5) -- the C atom.

      IF (ISWTCH.EQ.1) RETURN
C
C      CALCULATE DEDX = DEDR(DER) * DRDX
C
      CALL MULT (DER,1,15,DRDX,15,18,DEDX)
      IPT = 1
      DO 120 I = 1, 6
         DXX(IPT) = DEDX(I)
         DXX(IPT+1) = DEDX(I+6)
         DXX(IPT+2) = DEDX(I+12)
         IPT = IPT+3
  120 CONTINUE
*Now the metals
      CALL MULT (DER,1,15,DRDXM,15,3*NATDM,DEDXM) 
      IPT = 1
      DO 121 I = 1,(NATPRM-NCOV2)
        DXXM(IPT) = DEDXM(I)
        DXXM(IPT+1) = DEDXM(I+(NATPRM-NCOV2))
        DXXM(IPT+2) = DEDXM(I+2*(NATPRM-NCOV2))
        IPT = IPT + 3
121   CONTINUE
C
C     NOW ADD IN THE OUT OF PLANE BEND TERM
C
      CXX(1) = X(IM(1))
      CXX(2) = Y(IM(1))
      CXX(3) = Z(IM(1))
      CXX(4) = X(IM(2))
      CXX(5) = Y(IM(2))
      CXX(6) = Z(IM(2))
      CXX(7) = X(IM(3))
      CXX(8) = Y(IM(3))
      CXX(9) = Z(IM(3))
      CXX(10) = X(IM(4))
      CXX(11) = Y(IM(4))
      CXX(12) = Z(IM(4))
      CXX(13) = X(IM(5))
      CXX(14) = Y(IM(5))
      CXX(15) = Z(IM(5))
      CXX(16) = X(IM(6))
      CXX(17) = Y(IM(6))
      CXX(18) = Z(IM(6))
      CALL OOPB (VOOP,DVOOP,V,COORD,DXX,N3TM,DR1DX,IM)
      ENERGY = ENERGY+VOOP
      DO 130 I = 1, 18
         DXX(I) = DXX(I)+DVOOP(I)
  130 CONTINUE
135   CONTINUE
C
      RETURN
      END
C
C***********************************************************************
C
      SUBROUTINE ANGLE (XX,Y,Z)
C
C ROUTINE TO COMPUTE CH4 ANGLES FROM THE INTERPARTICLE DISTANCES
C***********************************************************************
C***********************************************************************
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      DIMENSION XX(6),Y(6),Z(6)
      COMMON /ICORCM/ R(15),DER(15)
C
      COMMON /POTRCM/ AG(6),R2(15),ACS(6),ASS(6)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      DO 10 I = 1, 3
         X = (R2(1)+R2(I+1)-R2(I+9))/(2.0D0*R(1)*R(I+1))
         IF (X .GE. 1.0) THEN
           X = 0.999999999
         ENDIF
         IF (X .LE. -1.0) THEN
                 X = -0.999999999
         ENDIF
         ACS(I) = X
         ASS(I) = SQRT(1.0D0-X*X)
         AG(I) = ACOS(X)
   10 CONTINUE
      DO 20 I = 1, 2
         X = (R2(2)+R2(I+2)-R2(I+12))/(2.0D0*R(2)*R(I+2))
         IF (X .GE. 1.0) THEN
                 X = 0.999999999
         ENDIF
         IF (X .LE. -1.0) THEN
                 X = -0.999999999
         ENDIF
         ACS(I+3) = X
         ASS(I+3) = SQRT(1.0D0-X*X)
         AG(I+3) = ACOS(X)
   20 CONTINUE
      X = (R2(3)+R2(4)-R2(15))/(2.0D0*R(3)*R(4))
         IF (X .GE. 1.0) THEN 
                 X = 0.999999999
         ENDIF
         IF (X .LE. -1.0) THEN
                 X = -0.999999999
         ENDIF
      ACS(6) = X
      ASS(6) = SQRT(1.0D0-X*X)
      AG(6) = ACOS(X)

30    FORMAT (6(F8.2,2X))
      RETURN
      END
C
C***********************************************************************
C***********************************************************************
C
      SUBROUTINE DISTA (IA, IB, KC, IFLAG9,IM,X,Y,Z)
C
C ROUTINE TO COMPUTE THE INTERPARTICLE DISTANCES FROM THE CARTESIAN
C     COORDINATES OF THE ATOMS
C***********************************************************************
C***********************************************************************
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION DF(15,3), IM(18), RS(4), WTS(4), DWTS(4)
C
      DIMENSION X(6),Y(6),Z(6)
      COMMON /ICORCM/ R(15),DER(15)
C
      COMMON /POTRCM/ AG(6),R2(15),ACS(6),ASS(6)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /CDENCM/CDEN,HDEN(4)
      COMMON /MAPCM/CDRA,CDRB,HDRA,HDRB,HDRC,MAPB,MAPB2(20,5),DVDP(5)


      IM(1) = IA
      IM(6) = IB

      I = 2
      DO 5 L = 1,6
        IF (L .EQ. 5) GOTO 5
        IF (L .NE. IM(1) .AND. L .NE. IM(6)) THEN
          IM(I) = L
          I = I + 1
        ENDIF
5     CONTINUE
      IM(5) = 5
      IF (IM(1) .EQ. 6) MAPB = 1
      IF (IM(2) .EQ. 6) MAPB = 2
      IF (IM(3) .EQ. 6) MAPB = 3
      IF (IM(4) .EQ. 6) MAPB = 4
      IF (IM(5) .EQ. 6) MAPB = 5
      IF (IM(6) .EQ. 6) MAPB = 6

      DO 10 I = 1, 4
         DF(I,1) = X(IM(I))-X(IM(5))
         DF(I,2) = Y(IM(I))-Y(IM(5))
         DF(I,3) = Z(IM(I))-Z(IM(5))
         R2(I) = DF(I,1)*DF(I,1)+
     *      DF(I,2)*DF(I,2)+DF(I,3)*DF(I,3)
         R(I) = SQRT(R2(I))
   10 CONTINUE
      DF(5,1) = X(IM(5))-X(IM(6))
      DF(5,2) = Y(IM(5))-Y(IM(6))
      DF(5,3) = Z(IM(5))-Z(IM(6))
      R2(5) = DF(5,1)*DF(5,1)+
     *     DF(5,2)*DF(5,2)+DF(5,3)*DF(5,3)
      R(5) = SQRT(R2(5))
      DO 20 I = 1, 4
         J = I+5
         DF(J,1) = X(IM(I))-X(IM(6))
         DF(J,2) = Y(IM(I))-Y(IM(6))
         DF(J,3) = Z(IM(I))-Z(IM(6))
         R2(J) = DF(J,1)*DF(J,1)+
     *      DF(J,2)*DF(J,2)+DF(J,3)*DF(J,3)
         R(J) = SQRT(R2(J))
   20 CONTINUE
      DO 30 I = 1, 3
         J = I+1
         K = I+9
         DF(K,1) = X(IM(1))-X(IM(J))
         DF(K,2) = Y(IM(1))-Y(IM(J))
         DF(K,3) = Z(IM(1))-Z(IM(J))
         R2(K) = DF(K,1)*DF(K,1)+
     *      DF(K,2)*DF(K,2)+DF(K,3)*DF(K,3)
         R(K) = SQRT(R2(K))
   30 CONTINUE
      DO 40 I = 1, 2
         J = I+2
         K = I+12
         DF(K,1) = X(IM(2))-X(IM(J))
         DF(K,2) = Y(IM(2))-Y(IM(J))
         DF(K,3) = Z(IM(2))-Z(IM(J))
         R2(K) = DF(K,1)*DF(K,1)+
     *       DF(K,2)*DF(K,2)+DF(K,3)*DF(K,3)
         R(K) = SQRT(R2(K))
   40 CONTINUE
      DF(15,1) = X(IM(3))-X(IM(4))
      DF(15,2) = Y(IM(3))-Y(IM(4))
      DF(15,3) = Z(IM(3))-Z(IM(4))
      R2(15) = DF(15,1)*DF(15,1)+DF(15,2)*DF(15,2)+DF(15,3)*DF(15,3)
      R(15) = SQRT(R2(15))

        DVDP(1) = 0.0
        DVDP(2) = 0.0
        DVDP(3) = 0.0
        DVDP(4) = 0.0
        DVDP(5) = 0.0
        REWIND 95
        READ (95,*) CDRB
        READ (95,*) CDRC
        READ (95,*) HDRB
        READ (95,*) HDRC
        close (95)
 
* C atom
      PA = 2496.256348
      PB = -186.830
      PC = 5.09138
      WTMC = 4.0
      CDRC = CDRB + CDRC
      CDRA = 2.067 / (0.023680**(CDRB)-0.023680**(CDRC)) 
      CDRF = 0.0D0
      CPCUT1 = 1E-9
      CPCUT2 = 1E-10
      CAS = -5.7812E11
      CBS = 1.4586E10
      CCS = -9.9092E7
      CDS = 15.0
      ASLP = -208.0
      AYINT = 7.0
      DRAT = -2.9947
      DRBT = 0.5711
       CDEN1 = CDEN + 0.0001
      IF (CDEN .GT. 0.0) THEN
        DRBT = HDRB
        DRCT = HDRB + HDRC
        DRAT = 1.4587 / (0.09393**(DRBT)-0.09393**(DRCT))
      IF (CDEN .GT. 1.0E-6) THEN
        RC1A = 1.0*DRAT*(CDEN**(DRBT) - CDEN**(DRCT))
        DRC1A = 1.0*DRAT*(DRBT*CDEN**(DRBT-1.0)
     +                      - DRCT*CDEN**(DRCT-1.0))
      ELSEIF (CDEN .GT. (1.0E-6-1.0E-8)) THEN
        RC1A = 20.0
        DRC1A = 0.0
      ELSE
        RC1A = 20.0
        DRC1A = 0.0
      ENDIF

      RC1B = CDRA*(CDEN**(CDRB) - CDEN**(CDRC))
      DRC1B = CDRA*(CDRB*CDEN**(CDRB-1.0)
     +                    - CDRC*CDEN**(CDRC-1.0))
      RC1C = 1.4
      DRC1C = 0.0

      RS(1) = 0.0000
      RS(2) = 0.02385
      RS(3) = 0.180

      DO 1080 K = 1,3
       WTS(K) = 1/(CDEN-RS(K))**2
1080  CONTINUE
       WTS(2) = WTMC*WTS(2)
      DO 1090 K = 1,3
       DWTS(K) = (-2)/(CDEN-RS(K))**3
1090  CONTINUE
       DWTS(2) = WTMC*DWTS(2)
      WTNORM = 1 / (WTS(1)+WTS(2)+WTS(3))
      DWTNORM = (-1)*(WTNORM**2)*(DWTS(1)+DWTS(2)+DWTS(3))
      WS1 = WTNORM*WTS(1)*RC1A
      WS2 = WTNORM*WTS(2)*RC1B
      WS3 = WTNORM*WTS(3)*RC1C
      DWS1=WTNORM*WTS(1)*DRC1A + RC1A*(WTS(1)*DWTNORM+WTNORM*DWTS(1))
      DWS2=WTNORM*WTS(2)*DRC1B + RC1B*(WTS(2)*DWTNORM+WTNORM*DWTS(2))
      DWS3=WTNORM*WTS(3)*DRC1C + RC1C*(WTS(3)*DWTNORM+WTNORM*DWTS(3))

      R(MAPB2(KC,1)) = WS1 + WS2 + WS3
      DVDP(5) = DWS1 + DWS2 + DWS3

      ELSE
        R(MAPB2(KC,1)) = 200.0   !Z(IM(5))
        DVDP(5) = 0.0
      ENDIF
        R2(MAPB2(KC,1)) = R(MAPB2(KC,1))*R(MAPB2(KC,1))

      GOTO 776
      IF (CDEN .LE. CPCUT2) THEN
        R(MAPB2(KC,1)) = CDS
        DVDP(5) = 0.0
      ELSEIF (CDEN .GT. CPCUT2 .AND. CDEN .LE. CPCUT1) THEN
        PD = CDEN-CPCUT2
        R(MAPB2(KC,1)) = CAS*PD**5 + CBS*PD**4 + CCS*PD**3 + CDS 
        DVDP(5) = 5*CAS*PD**4 + 4*CBS*PD**3 + 3*CCS*PD*PD
      ELSEIF (CDEN .GT. CPCUT1) THEN
        R(MAPB2(KC,1)) = CDRA*(CDEN**(CDRB) - CDEN**(CDRC))
     +    - CDRF
        DVDP(5) = CDRA*(CDRB*CDEN**(CDRB-1.0) 
     +                    - CDRC*CDEN**(CDRC-1.0)) 
      ENDIF
      IF (CDEN .EQ. 0.0) THEN
        R(MAPB2(KC,1)) = 200.0
        DVDP(5) = 0.0
      ENDIF
        R2(MAPB2(KC,1)) = R(MAPB2(KC,1))*R(MAPB2(KC,1))

* H atoms
776    CONTINUE
        HDRC = HDRB + HDRC
        HDRD = 16.316
        HDRE = 3.723
        HDRA = 1.4587 / (0.09393**(HDRB)-0.09393**(HDRC))
        HDRF =0.0 ! -0.020491
        HDRG = 0.0 !1.3317
        HDRH = 0.0 ! 4.6934
      HPCUT1 = 1E-9
      HPCUT2 = 1E-10
      HAS = -2.2455E13
      HBS = 2.7637E11
      HCS = -9.0975E8
      HDS = 15.0
         
      DRAT = -2.9947
      DRBT = 0.5711
      WTM = 8.0
      IF (HDEN(1) .GT. 0.0) THEN

      IF (HDEN(1) .GT. 1.0E-6) THEN
        RH1A = 1.0*HDRA*(HDEN(1)**(HDRB) - HDEN(1)**(HDRC))
        DRH1A = 1.0*HDRA*(HDRB*HDEN(1)**(HDRB-1.0)
     +                      - HDRC*HDEN(1)**(HDRC-1.0))
      ELSEIF (HDEN(1) .GT. (1.0E-6-1.0E-8)) THEN
        RH1A = 20.0
        DRH1A = 0.0
      ELSE
        RH1A = 20.0
        DRH1A = 0.0
      ENDIF

      RH1B = RH1A
      DRH1B = DRH1A
      RH1C = 1.4
      DRH1C = 0.0
      
      RS(1) = 0.0000
      RS(2) = 0.010
      RS(3) = 0.180

      DO 1000 K = 1,3
       WTS(K) = 1/(HDEN(1)-RS(K))**2
1000  CONTINUE
       WTS(2) = WTM*WTS(2)
      DO 1010 K = 1,3
       DWTS(K) = (-2)/(HDEN(1)-RS(K))**3
1010  CONTINUE
       DWTS(2) = WTM*DWTS(2)
      WTNORM = 1 / (WTS(1)+WTS(2)+WTS(3))
      DWTNORM = (-1)*(WTNORM**2)*(DWTS(1)+DWTS(2)+DWTS(3))
      WS1 = WTNORM*WTS(1)*RH1A 
      WS2 = WTNORM*WTS(2)*RH1B 
      WS3 = WTNORM*WTS(3)*RH1C 
      DWS1=WTNORM*WTS(1)*DRH1A + RH1A*(WTS(1)*DWTNORM+WTNORM*DWTS(1))
      DWS2=WTNORM*WTS(2)*DRH1B + RH1B*(WTS(2)*DWTNORM+WTNORM*DWTS(2))
      DWS3=WTNORM*WTS(3)*DRH1C + RH1C*(WTS(3)*DWTNORM+WTNORM*DWTS(3))

      R(MAPB2(KC,2)) = WS1 + WS2 + WS3
      DVDP(1) = DWS1 + DWS2 + DWS3
 
      ELSE
        R(MAPB2(KC,2)) = 200.0
        DVDP(1) = 0.0
      ENDIF
        R2(MAPB2(KC,2)) = R(MAPB2(KC,2))*R(MAPB2(KC,2))

      IF (HDEN(2) .GT. 0.0) THEN
      IF (HDEN(2) .GT. 1.0E-6) THEN
        RH1A = 1.0*HDRA*(HDEN(2)**(HDRB) - HDEN(2)**(HDRC))
        DRH1A = 1.0*HDRA*(HDRB*HDEN(2)**(HDRB-1.0)
     +                      - HDRC*HDEN(2)**(HDRC-1.0))
      ELSEIF (HDEN(2) .GT. (1.0E-6-1.0E-8)) THEN
        RH1A = 20.0
        DRH1A = 0.0
      ELSE
        RH1A = 20.0
        DRH1A = 0.0
      ENDIF

      RH1B = RH1A
      DRH1B = DRH1A
      RH1C = 1.4
      DRH1C = 0.0

      RS(1) = 0.0000
      RS(2) = 0.01051
      RS(3) = 0.180

      DO 1020 K = 1,3
       WTS(K) = 1/(HDEN(2)-RS(K))**2
1020  CONTINUE
       WTS(2) = WTM*WTS(2)
      DO 1030 K = 1,3
       DWTS(K) = (-2)/(HDEN(2)-RS(K))**3
1030  CONTINUE
       DWTS(2) = WTM*DWTS(2)
      WTNORM = 1 / (WTS(1)+WTS(2)+WTS(3))
      DWTNORM = (-1)*(WTNORM**2)*(DWTS(1)+DWTS(2)+DWTS(3))
      WS1 = WTNORM*WTS(1)*RH1A
      WS2 = WTNORM*WTS(2)*RH1B
      WS3 = WTNORM*WTS(3)*RH1C
      DWS1=WTNORM*WTS(1)*DRH1A + RH1A*(WTS(1)*DWTNORM+WTNORM*DWTS(1))
      DWS2=WTNORM*WTS(2)*DRH1B + RH1B*(WTS(2)*DWTNORM+WTNORM*DWTS(2))
      DWS3=WTNORM*WTS(3)*DRH1C + RH1C*(WTS(3)*DWTNORM+WTNORM*DWTS(3))

      R(MAPB2(KC,3)) = WS1 + WS2 + WS3
      DVDP(2) = DWS1 + DWS2 + DWS3

      ELSE
        R(MAPB2(KC,3)) = 200.0
        DVDP(2) = 0.0
      ENDIF
        R2(MAPB2(KC,3)) = R(MAPB2(KC,3))*R(MAPB2(KC,3))

      IF (HDEN(3) .GT. 0.0) THEN
      IF (HDEN(3) .GT. 1.0E-6) THEN
        RH1A = 1.0*HDRA*(HDEN(3)**(HDRB) - HDEN(3)**(HDRC))
        DRH1A = 1.0*HDRA*(HDRB*HDEN(3)**(HDRB-1.0)
     +                      - HDRC*HDEN(3)**(HDRC-1.0))
      ELSEIF (HDEN(3) .GT. (1.0E-6-1.0E-8)) THEN
        RH1A = 20.0
        DRH1A = 0.0
      ELSE
        RH1A = 20.0
        DRH1A = 0.0
      ENDIF

      RH1B = RH1A
      DRH1B = DRH1A
      RH1C = 1.4
      DRH1C = 0.0

      RS(1) = 0.0000
      RS(2) = 0.01051
      RS(3) = 0.180

      DO 1040 K = 1,3
       WTS(K) = 1/(HDEN(3)-RS(K))**2
1040  CONTINUE
       WTS(2) = WTM*WTS(2)
      DO 1050 K = 1,3
       DWTS(K) = (-2)/(HDEN(3)-RS(K))**3
1050  CONTINUE
       DWTS(2) = WTM*DWTS(2)
      WTNORM = 1 / (WTS(1)+WTS(2)+WTS(3))
      DWTNORM = (-1)*(WTNORM**2)*(DWTS(1)+DWTS(2)+DWTS(3))
      WS1 = WTNORM*WTS(1)*RH1A
      WS2 = WTNORM*WTS(2)*RH1B
      WS3 = WTNORM*WTS(3)*RH1C
      DWS1=WTNORM*WTS(1)*DRH1A + RH1A*(WTS(1)*DWTNORM+WTNORM*DWTS(1))
      DWS2=WTNORM*WTS(2)*DRH1B + RH1B*(WTS(2)*DWTNORM+WTNORM*DWTS(2))
      DWS3=WTNORM*WTS(3)*DRH1C + RH1C*(WTS(3)*DWTNORM+WTNORM*DWTS(3))

      R(MAPB2(KC,4)) = WS1 + WS2 + WS3
      DVDP(3) = DWS1 + DWS2 + DWS3

      ELSE
        R(MAPB2(KC,4)) = 200.0
        DVDP(3) = 0.0
      ENDIF
        R2(MAPB2(KC,4)) = R(MAPB2(KC,4))*R(MAPB2(KC,4))

      IF (HDEN(4) .GT. 0.0) THEN
      IF (HDEN(4) .GT. 1.0E-6) THEN
        RH1A = 1.0*HDRA*(HDEN(4)**(HDRB) - HDEN(4)**(HDRC))
        DRH1A = 1.0*HDRA*(HDRB*HDEN(4)**(HDRB-1.0)
     +                      - HDRC*HDEN(4)**(HDRC-1.0))
      ELSEIF (HDEN(4) .GT. (1.0E-6-1.0E-8)) THEN
        RH1A = 20.0
        DRH1A = 0.0
      ELSE
        RH1A = 20.0
        DRH1A = 0.0
      ENDIF

      RH1B = RH1A
      DRH1B = DRH1A
      RH1C = 1.4
      DRH1C = 0.0

      RS(1) = 0.0000
      RS(2) = 0.01051
      RS(3) = 0.18

      DO 1060 K = 1,3
       WTS(K) = 1/(HDEN(4)-RS(K))**2
1060  CONTINUE
       WTS(2) = WTM*WTS(2)
      DO 1070 K = 1,3
       DWTS(K) = (-2)/(HDEN(4)-RS(K))**3
1070  CONTINUE
       DWTS(2) = WTM*DWTS(2)
      WTNORM = 1 / (WTS(1)+WTS(2)+WTS(3))
      DWTNORM = (-1)*(WTNORM**2)*(DWTS(1)+DWTS(2)+DWTS(3))
      WS1 = WTNORM*WTS(1)*RH1A
      WS2 = WTNORM*WTS(2)*RH1B
      WS3 = WTNORM*WTS(3)*RH1C
      DWS1=WTNORM*WTS(1)*DRH1A + RH1A*(WTS(1)*DWTNORM+WTNORM*DWTS(1))
      DWS2=WTNORM*WTS(2)*DRH1B + RH1B*(WTS(2)*DWTNORM+WTNORM*DWTS(2))
      DWS3=WTNORM*WTS(3)*DRH1C + RH1C*(WTS(3)*DWTNORM+WTNORM*DWTS(3))

      R(MAPB2(KC,5)) = WS1 + WS2 + WS3
      DVDP(4) = DWS1 + DWS2 + DWS3

      ELSE
        R(MAPB2(KC,5)) = 200.0
        DVDP(4) = 0.0
      ENDIF
        R2(MAPB2(KC,5)) = R(MAPB2(KC,5))*R(MAPB2(KC,5))

      GOTO 778

779      IF (HDEN(1) .LE. HPCUT2) THEN
        R(MAPB2(KC,2)) = HDS
        DVDP(1) = 0.0
      ELSEIF (HDEN(1) .GT. HPCUT2 .AND. HDEN(1) .LE. HPCUT1) THEN
        PD = HDEN(1)-HPCUT2
        R(MAPB2(KC,2)) = HAS*PD**5 + HBS*PD**4 + HCS*PD**3 + HDS 
        DVDP(1) = 5*HAS*PD**4 + 4*HBS*PD**3 + 3*HCS*PD*PD
      ELSEIF (HDEN(1) .GT. HPCUT1) THEN
        R(MAPB2(KC,2)) = 1.0*HDRA*(HDEN(1)**(HDRB) - HDEN(1)**(HDRC))
     +    + HDRF + HDRG*HDEN(1) + HDRH*HDEN(1)**2
        DVDP(1) = 1.0*HDRA*(HDRB*HDEN(1)**(HDRB-1.0) 
     +                    - HDRC*HDEN(1)**(HDRC-1.0)) 
     +                    + HDRG + 2.0*HDRH*HDEN(1)
      ENDIF
      IF (HDEN(1) .EQ. 0.0) THEN
        R(MAPB2(KC,2)) = 100.0
        DVDP(1) = 0.0
      ENDIF
        R2(MAPB2(KC,2)) = R(MAPB2(KC,2))*R(MAPB2(KC,2))

      IF (HDEN(2) .LE. HPCUT2) THEN
        R(MAPB2(KC,3)) = HDS
        DVDP(2) = 0.0
      ELSEIF (HDEN(2) .GT. HPCUT2 .AND. HDEN(2) .LE. HPCUT1) THEN
        PD = HDEN(2)-HPCUT2
        R(MAPB2(KC,3)) = HAS*PD**5 + HBS*PD**4 + HCS*PD**3 + HDS 
        DVDP(2) = 5*HAS*PD**4 + 4*HBS*PD**3 + 3*HCS*PD*PD
      ELSEIF (HDEN(2) .GT. HPCUT1) THEN
        R(MAPB2(KC,3)) = 1.0*HDRA*(HDEN(2)**(HDRB) - HDEN(2)**(HDRC))
     +    + HDRF + HDRG*HDEN(2) + HDRH*HDEN(2)**2
        DVDP(2) = 1.0*HDRA*(HDRB*HDEN(2)**(HDRB-1.0) 
     +                    - HDRC*HDEN(2)**(HDRC-1.0)) 
     +                    + HDRG + 2.0*HDRH*HDEN(2)
      ENDIF
      IF (HDEN(2) .EQ. 0.0) THEN
        R(MAPB2(KC,3)) = 100.0
        DVDP(2) = 0.0
      ENDIF
        R2(MAPB2(KC,3)) = R(MAPB2(KC,3))*R(MAPB2(KC,3))

      IF (HDEN(3) .LE. HPCUT2) THEN
        R(MAPB2(KC,4)) = HDS
        DVDP(3) = 0.0
      ELSEIF (HDEN(3) .GT. HPCUT2 .AND. HDEN(3) .LE. HPCUT1) THEN
        PD = HDEN(3)-HPCUT2
        R(MAPB2(KC,4)) = HAS*PD**5 + HBS*PD**4 + HCS*PD**3 + HDS 
        DVDP(3) = 5*HAS*PD**4 + 4*HBS*PD**3 + 3*HCS*PD*PD
      ELSEIF (HDEN(3) .GT. HPCUT1) THEN
        R(MAPB2(KC,4)) = 1.0*HDRA*(HDEN(3)**(HDRB) - HDEN(3)**(HDRC))
     +    + HDRF + HDRG*HDEN(3) + HDRH*HDEN(3)**2
        DVDP(3) = 1.0*HDRA*(HDRB*HDEN(3)**(HDRB-1.0) 
     +                    - HDRC*HDEN(3)**(HDRC-1.0)) 
     +                    + HDRG + 2.0*HDRH*HDEN(3)
      ENDIF
      IF (HDEN(3) .EQ. 0.0) THEN
        R(MAPB2(KC,4)) = 100.0
        DVDP(3) = 0.0
      ENDIF
        R2(MAPB2(KC,4)) = R(MAPB2(KC,4))*R(MAPB2(KC,4))

      IF (HDEN(4) .LE. HPCUT2) THEN
        R(MAPB2(KC,5)) = HDS
        DVDP(4) = 0.0
      ELSEIF (HDEN(4) .GT. HPCUT2 .AND. HDEN(4) .LE. HPCUT1) THEN
        PD = HDEN(4)-HPCUT2
        R(MAPB2(KC,5)) = HAS*PD**5 + HBS*PD**4 + HCS*PD**3 + HDS 
        DVDP(4) = 5*HAS*PD**4 + 4*HBS*PD**3 + 3*HCS*PD*PD
      ELSEIF (HDEN(4) .GT. HPCUT1) THEN
        R(MAPB2(KC,5)) = 1.0*HDRA*(HDEN(4)**(HDRB) - HDEN(4)**(HDRC))
     +    + HDRF + HDRG*HDEN(4) + HDRH*HDEN(4)**2
        DVDP(4) = 1.0*HDRA*(HDRB*HDEN(4)**(HDRB-1.0) 
     +                    - HDRC*HDEN(4)**(HDRC-1.0)) 
     +                    + HDRG + 2.0*HDRH*HDEN(4)
      ENDIF
      IF (HDEN(4) .EQ. 0.0) THEN
        R(MAPB2(KC,5)) = 100.0
        DVDP(4) = 0.0
      ENDIF
        R2(MAPB2(KC,5)) = R(MAPB2(KC,5))*R(MAPB2(KC,5))

778   CONTINUE

      IFLAG9 = 0
      IF (R(MAPB2(KC,1)) .LE. 0.1 .OR. R(MAPB2(KC,2)) .LE. 0.1 .OR.
     *    R(MAPB2(KC,3)) .LE. 0.1 .OR. R(MAPB2(KC,4)) .LE. 0.1 .OR.
     *    R(MAPB2(KC,5)) .LE. 0.1) THEN
      IFLAG9 = 1
      WRITE (6,*) 'Problem (A), KC = ',KC
      RETURN
      ENDIF
* At this point, DVDP(1-5) are the derivatives of the surface bonds with 
* respect to the corresponding densities.  DVDP(1-4) = dR/dp of 4 H atoms, 
* and DVDP(5) = dR/dp of C atom.

777   CONTINUE
       IF (KC .EQ. 12) THEN
       ENDIF

      RETURN
60    FORMAT (8(F7.3,2X))
61    FORMAT (7(F7.3,2X))
      END

      SUBROUTINE DRDXC (KC,IM,X,Y,Z,DRDX,DRDXM)
C
C THIS SUBROUTINE CALCULATES DRDX
C
C     ADDED BY FBB AT THE U. OF MINN.  1/24/84
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      PARAMETER (NATDM = 53)
      PARAMETER (NATMX=1601, NCOVMX=5, NVCDM=(NCOVMX*(NCOVMX+1))/2)
      DIMENSION IM(18), DRSDX(3,5)
      DIMENSION X(6),Y(6),Z(6),DRDX(15,18)
      DIMENSION DRDXM(15,3*NATDM),DEDXM(3*NATDM)
      COMMON /ICORCM/ R(15),DER(15)
C
      COMMON /POTRCM/ AG(6),R2(15),ACS(6),ASS(6)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /MAPCM/CDRA,CDRB,HDRA,HDRB,HDRC,MAPB,MAPB2(20,5),DVDP(5)
      COMMON /SURCM1/ RR(3,NATMX), DIJ(NATMX,NATMX),
     *   DIJDR(3,NATMX,NATMX), VCOV(NVCDM), DVCOV(3,NATDM,NVCDM),
     *   VCOV3(NVCDM), DVCOV3(3,NATDM,NVCDM), DVMET(3,NATDM),
     *   RHOS(NATMX), RHO(NATMX), RHOP(NATMX,NATMX), RHOI(NATMX),
     *   FE(NATMX), FP(NATMX), EZERO, ITYPE(NATMX), NATPRM, NATPRP,
     *   NCOV, NCOVP, NMET, NMETP,NATOMS, NBOND, NBONDC, INDGS,
     * NCUT(NATMX),ID(NATMX,NATMX),NCOV2,NBONDC2,NBOND2,NFRST(NVCDM)
      DATA BOHR / 0.529167 /
C
C
C ZERO OUT DRDX & DRDXM
C
      DO 10 I = 1, 18
         DO 10 J = 1, 15
            DRDX(J,I) = 0.0D0
   10 CONTINUE
      DO 12 I = 1, 3*NATDM
         DO 12 J = 1, 15
            DRDXM(J,I) = 0.0D0
   12 CONTINUE
C
C CALCULATE DRDX FOR C - H(1,2,3,4) BONDS
C
      DO 20 I = 1, 4
         DRDX(I,IM(I)) = (X(IM(I))-X(IM(5)))/R(I)
         DRDX(I,IM(5)) = -DRDX(I,IM(I))
         DRDX(I,IM(I)+6) = (Y(IM(I))-Y(IM(5)))/R(I)
         DRDX(I,IM(5)+6) = -DRDX(I,IM(I)+6)
         DRDX(I,IM(I)+12) = (Z(IM(I))-Z(IM(5)))/R(I)
         DRDX(I,IM(5)+12) = -DRDX(I,IM(I)+12)
   20 CONTINUE
C
C CALCULATE DRDX FOR C - H' BOND
C
      DRDX(5,IM(5)) = (X(IM(5))-X(IM(6)))/R(5)
      DRDX(5,IM(6)) = -DRDX(5,IM(5))
      DRDX(5,IM(5)+6) = (Y(IM(5))-Y(IM(6)))/R(5)
      DRDX(5,IM(6)+6) = -DRDX(5,IM(5)+6)
      DRDX(5,IM(5)+12) = (Z(IM(5))-Z(IM(6)))/R(5)
      DRDX(5,IM(6)+12) = -DRDX(5,IM(5)+12)
C
C CALCULATE DRDX FOR H - H' BONDS
C
      DO 30 I = 1, 4
         DRDX(5+I,IM(I)) = (X(IM(I))-X(IM(6)))/R(5+I)
         DRDX(5+I,IM(6)) = -DRDX(5+I,IM(I))
         DRDX(5+I,IM(I)+6) = (Y(IM(I))-Y(IM(6)))/R(5+I)
         DRDX(5+I,IM(6)+6) = -DRDX(5+I,IM(I)+6)
         DRDX(5+I,IM(I)+12) = (Z(IM(I))-Z(IM(6)))/R(5+I)
         DRDX(5+I,IM(6)+12) = -DRDX(5+I,IM(I)+12)
   30 CONTINUE
31    FORMAT (3(F12.8,2X))

C
C CALCULATE DRDX FOR H1 - H(2,3,4) BONDS
C
      DO 40 I = 1, 3
         DRDX(9+I,IM(I+1)) = -(X(IM(1))-X(IM(I+1)))/R(9+I)
         DRDX(9+I,IM(1)) = -DRDX(9+I,IM(I+1))
         DRDX(9+I,IM(I+1)+6) = -(Y(IM(1))-Y(IM(I+1)))/R(9+I)
         DRDX(9+I,IM(1)+6) = -DRDX(9+I,IM(I+1)+6)
         DRDX(9+I,IM(I+1)+12) = -(Z(IM(1))-Z(IM(I+1)))/R(9+I)
         DRDX(9+I,IM(1)+12) = -DRDX(9+I,IM(I+1)+12)
   40 CONTINUE
C
C CALCULATE DRDX FOR H2 - H(3,4)
C
      DO 50 I = 1, 2
         DRDX(12+I,IM(I+2)) = -(X(IM(2))-X(IM(I+2)))/R(12+I)
         DRDX(12+I,IM(2)) = -DRDX(12+I,IM(I+2))
         DRDX(12+I,IM(I+2)+6) = -(Y(IM(2))-Y(IM(I+2)))/R(12+I)
         DRDX(12+I,IM(2)+6) = -DRDX(12+I,IM(I+2)+6)
         DRDX(12+I,IM(I+2)+12) = -(Z(IM(2))-Z(IM(I+2)))/R(12+I)
         DRDX(12+I,IM(2)+12) = -DRDX(12+I,IM(I+2)+12)
   50 CONTINUE
C
C CALCULATE DRDX FOR H3 - H4
C
      DRDX(15,IM(4)) = -(X(IM(3))-X(IM(4)))/R(15)
      DRDX(15,IM(3)) = -DRDX(15,IM(4))
      DRDX(15,IM(4)+6) = -(Y(IM(3))-Y(IM(4)))/R(15)
      DRDX(15,IM(3)+6) = -DRDX(15,IM(4)+6)
      DRDX(15,IM(4)+12) = -(Z(IM(3))-Z(IM(4)))/R(15)
      DRDX(15,IM(3)+12) = -DRDX(15,IM(4)+12)
C
   
      DO 60 I = 1, 18
        DRDX(MAPB2(KC,1),I) = 0.0D0
        DRDX(MAPB2(KC,2),I) = 0.0D0
        DRDX(MAPB2(KC,3),I) = 0.0D0
        DRDX(MAPB2(KC,4),I) = 0.0D0
        DRDX(MAPB2(KC,5),I) = 0.0D0
   60 CONTINUE
   61 CONTINUE

* Before leaving DRDXC, need to properly assign DRDX values.
* DVDP is still as calculated in DISTA -- i.e, d(Rmap)/d(rho).  DVDP(5) is
* d(RCmap)/d(rhoC), and DVDP(1-4) are d(RHmap)/d(rhoH).

* We need d(Rmap)/d(X1-15), and ultimately for all atoms in primary zone.
* DRDX must be unitless, to agree with all other calculated DRDX values.
* DRDX = DVDP*(RHOP*DIJDR) running over all values of RHOP & DIJDR necessary.
* DVDP is in units of bohr / A^(-3)
* RHOP is in units of A^(-3)/A
* DIJDR is unitless
* So to get DRDX unitless, need to multiply result by 0.529167A / bohr

309   CONTINUE
      KA = NCUT(5)
      DO 320 KE = 1,3
       TDPDX = 0.0D0
       DO 310 KB = 1, KA
        KD = ID(KB,5)
        TDPDX = TDPDX + RHOP(5,KD) * DIJDR(KE,5,KD)
310    CONTINUE
       DRDX(MAPB2(KC,1),((KE-1)*6+5)) = DVDP(5)*TDPDX*BOHR
320   CONTINUE 

      DO 350 KF = 1,4
       KA = NCUT(KF)
       DO 340 KE = 1,3
        TDPDX = 0.0D0
        DO 330 KB = 1, KA
         KD = ID(KB,KF)
         TDPDX = TDPDX + RHOP(KF,KD) * DIJDR(KE,KF,KD)
330     CONTINUE
        DRDX(MAPB2(KC,(KF+1)),((KE-1)*6+KF)) = DVDP(KF)*TDPDX*BOHR
340    CONTINUE
350   CONTINUE

91    CONTINUE

*Now assign DRDX values for the metal atoms in the primary zone.
      IF (NATPRM .GT. 5) THEN
     
       DO 170 JA = 1,(NATPRM-NCOV2)
        JB = NCOV2+JA
         DO 160 JC = 1,3
          JD = (JC-1)*(NATPRM-NCOV2)+JA
          DRDXM(MAPB2(KC,1),JD)=DVDP(5)*RHOP(5,JB)*DIJDR(JC,JB,5)
     *      * BOHR
160      CONTINUE
170    CONTINUE

       DO 200 JE = 1,4  
        DO 190 JA = 1,(NATPRM-NCOV2)
         JB = NCOV2+JA
          DO 180 JC = 1,3
          JD = (JC-1)*(NATPRM-NCOV2)+JA
          DRDXM(MAPB2(KC,JE+1),JD)=DVDP(JE)*RHOP(JE,JB)*DIJDR(JC,JB,JE)
     *      * BOHR
180       CONTINUE
190     CONTINUE
200    CONTINUE
      ENDIF

      RETURN
      END


      SUBROUTINE ARRAYO (TITLE,A,N,M)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C THIS PROGRAM WRITES OUT SMALL MATRICES
C
      DIMENSION A(N,M)
C
      WRITE (6,1000) TITLE
C
      DO 10 I = 1, N
C
         WRITE (6,1050) I,(A(I,J),J=1,M)
C
   10 CONTINUE
      RETURN
C
 1000 FORMAT(///' ',A8,' :'/)
 1050 FORMAT(/I3,6D20.8,(/3X,6D20.8))
C
      END
      SUBROUTINE MULT (A,NA,MA,B,NB,MB,C)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C THIS SUBROUTINE PERFORMS THE MATRIX MULTIPLICATION :
C
C         C = A X B
C
C
      DIMENSION A(NA,MA),B(NB,MB),C(NA,MB)
C
      DO 30 I = 1, NA
C
         DO 20 J = 1, MB
C
            SUM = 0.0D0
            DO 10 K = 1, MA
C
               SUM = SUM+A(I,K)*B(K,J)
   10       CONTINUE
C
            C(I,J) = SUM
   20    CONTINUE
C
   30 CONTINUE
      RETURN
      END
      SUBROUTINE DZERO (A,N)
      DOUBLE PRECISION A(N)
      DO 10 I = 1, N
         A(I) = 0.0D0
   10 CONTINUE
      RETURN
      END
C
C
      SUBROUTINE FORCE (DADR1)
C
C     THIS SUBROUTINE COMPUTES THE BENDING FORCE CONSTANT AS A FUNCTION
C     OF R(1). (APARM(1))   IT ALSO COMPUTES THE DERIVATIVE OF THIS
C     TERM WITH RESPECT TO R(1).
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
C
      COMMON /ICORCM/ R(15),DER(15)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /PDT3CM/ FK0,FA,CA,CB
C
      FEX = EXP(-B1*(R(1)-RE(1))**2)
      APARM(1) = FK0+FA*FEX
      DADR1 = -2.0D0*FA*B1*(R(1)-RE(1))*FEX
      RETURN
      END
C
C
      SUBROUTINE CALPHA
C
C     COMPUTE THE C-H AND C-H' MORSE RANGE PARAMETERS FOR THE SINGLET
C     AND TRIPLET ENERGY CURVES.  THESE WILL BE A FUNCTION OF THE
C     AVERAGE C-H BOND LENGTH IN METHANE.
C
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
C
      COMMON /ICORCM/ R(15),DER(15)
C
      COMMON /PDATCM/ D1(3),D3(3),ALPH(3),RE(3),BETA(3),CC(3),AA(3),    
     *   APARM(5),REFV,TAU,CP,B1,C1
      COMMON /PDT3CM/ FK0,FA,CA,CB
      COMMON /ALPDCM/ DALP
C
C     FIRST COMPUTE THE AVERAGE METHANE BOND LENGTH
C
      RAVG = (R(1)+R(2)+R(3)+R(4))/4.0D0
C
      HTAN = TANH(C1*(RAVG-RE(1)))
      ALPH(1) = CA+CB*((HTAN+1.0D0)/2.0D0)
      ALPH(3) = ALPH(1)
      BETA(1) = ALPH(1)
      BETA(3) = ALPH(1)
C
C     NOW THE DERIVATIVES---DALPH WILL BE THE DERIVATIVE OF ALPHA WITH
C     RESPECT TO R1,R2,R3 OR R4
C
      DALP = (C1*CB/8.0D0)*(1.0D0-HTAN**2)
C
      RETURN
      END
