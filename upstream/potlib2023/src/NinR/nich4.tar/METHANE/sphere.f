	PROGRAM SPHERE
        IMPLICIT DOUBLE PRECISION (A-H,O-Z)
        INCLUDE 'SIZES'
C******************************************************************************
	REAL RADIUS, DX, DY, DZ, D1, D2, DISTANCE(NCUBE),
     1       E, VPOT(NCUBE), TOL, ENERGY(NLAYERS), ECOUNT(NLAYERS)
        INTEGER INSIDE(NCUBE),COUNT,NEIGHBOR(MAXNM,MAXNM)
        COMMON /COORDS/ X(NCUBE), Y(NCUBE), Z(NCUBE)
C*******************************************************************************
        IBOUND = (NLAYERS * NLAYERS * NLAYERS * 2) 
        TOL = LATCON / 4.
        WRITE (*,*) 'Create Lattice..............1'
        WRITE (*,*) 'Sort Lattice................2'
        WRITE (*,*) 'Create Neighbor Data File...3'
        WRITE (*,*) 'Limit Lattice...............4'
        WRITE (*,*) 'Find Energy of Each Atom....5'
        WRITE (*,*) 'Find Rigid Lattice Energy...6'
        WRITE (*,*) 'Exit........................7'

        WRITE (*,*) 'ENTER SELECTION'
        READ (*,610) IFLAG

C   
C  Exit Program if IFLAG = 7
C 
        IF (IFLAG .EQ. 7) THEN
           GOTO 1000
        ENDIF

C
C  Create lattice.  The lattice is created by stacking atomic layers (number
C  determined by NLAYERS) to form a face centered cubic lattice with lattice
C  constant determined by LATCON.
C
	IF (IFLAG .EQ. 1) THEN
        WRITE (*,*) 'Which face to show?'
        WRITE (*,*) '(100)......1'
        WRITE (*,*) '(110)......2'
        WRITE (*,*) '(111)......3'
        READ (*,*) IFT
           OPEN (LATNUM, FILE = LATNAME)
           REWIND (LATNUM)
           XCORIG = 0.0
           YCINIT = 0.0
C           XCORIG = -1.0*FLOAT(NLAYERS-1)*LATCON/2.0                    RR1092
C           YCINIT = -1.0*FLOAT(NLAYERS-1)*LATCON/2.0                    RR1092  
           XCINIT = XCORIG
           IF (IFT .EQ. 1) THEN 
              XCADD = LATCON / 2
           ELSEIF (IFT .EQ. 3) THEN
              XCADD = SQRT(2.)*LATCON/4
              YCADD = SQRT(6.)*LATCON/12
              ZCADD = -SQRT(3.)*LATCON/3
           ELSEIF (IFT .EQ. 2) THEN
              XCADD = LATCON / 2
              YCADD = LATCON / (2*SQRT(2.))
              ZCADD = -LATCON / (2*SQRT(2.))
           ENDIF 
           ZC = 0
           DO 110 K = 1, NLAYERS
              YC = YCINIT
              DO 100 J = 1, NLAYERS
                 XC = XCINIT
                 DO 90 I = 1, NLAYERS
                    WRITE (LATNUM,500) XC, YC, ZC
           IF (IFT .EQ. 1) THEN 
                    WRITE (LATNUM,500) (XC+XCADD),(YC+(LATCON/2)),ZC
                    XC = XC + LATCON 
           ELSEIF (IFT .EQ. 3) THEN
              WRITE (LATNUM,500) (XC+XCADD),(YC+YCADD),(ZC+2*ZCADD)
              WRITE (LATNUM,500) XC,(YC+2*YCADD),(ZC+ZCADD)
              WRITE (LATNUM,500) (XC+XCADD),(YC+3*YCADD),ZC 
              WRITE (LATNUM,500) XC,(YC+4*YCADD),(ZC+2*ZCADD)
              WRITE (LATNUM,500) (XC+XCADD),(YC+5*YCADD),(ZC+ZCADD)
                    XC = XC + (XCADD*2) 
           ELSEIF (IFT. EQ. 2) THEN
              WRITE (LATNUM,500) (XC+XCADD),(YC+YCADD),(ZC+ZCADD)
              XC = XC + (XCADD*2)
           ENDIF
90               CONTINUE
           IF (IFT .EQ. 1) THEN 
                 YC = YC + LATCON
           ELSEIF (IFT .EQ. 3) THEN
                 YC = YC +(YCADD*6)
           ELSEIF (IFT .EQ. 2) THEN
                 YC = YC + (YCADD*2)
           ENDIF
100           CONTINUE
           IF (IFT .EQ. 1) THEN 
              ZC = ZC - (LATCON / 2)
              XCADD = -XCADD
              XCINIT = (MOD(K,2)) * (LATCON / 2) + XCORIG
           ELSEIF (IFT .EQ. 3) THEN
              ZC = ZC + (3*ZCADD) 
           ELSEIF (IFT .EQ. 2) THEN
              ZC = ZC + (2*ZCADD)
           ENDIF 
110           CONTINUE
           CLOSE (LATNUM)
        ENDIF

C
C  Sort lattice by taking existing lattice and ordering atoms by their
C  distance from an origin(s) specified by XCNTR#, YCNTR#, ZCNTR# (which 
C  may be H atoms in reactant and product positions).  INSIDE is an array
C  of the indicies of the lattice atoms.  DISTANCE is an array of the
C  distance between a given atom and the specified origin.
C
        IF (IFLAG .EQ. 2) THEN
	   OPEN (LATNUM, FILE = LATNAME)
	   REWIND (LATNUM)
	   DO 10 I = 1, IBOUND
              READ (LATNUM, 500, END = 15) X(I), Y(I), Z(I)
10	   CONTINUE
           GOTO 17
15         IBOUND = I-1
17         CLOSE (LATNUM)
           DO 20 I = 1, IBOUND
              D1 = GETDIST(XCNTR1, YCNTR1, ZCNTR1, I)
              D2 = GETDIST(XCNTR2, YCNTR2, ZCNTR2, I)
              IF (D2 .LT. D1) THEN
                 D1 = D2
              ENDIF
              COUNT = COUNT + 1
              INSIDE(COUNT) = I
              DISTANCE(COUNT) = D1
20         CONTINUE

           DO 30 I = 1, (COUNT-1)
              DO 25 J = (I+1), COUNT
                 IF (DISTANCE(J) .LT. DISTANCE(I)) THEN
                    TEMP = DISTANCE(I)
                    TEMPIN = INSIDE(I)
                    DISTANCE(I) = DISTANCE(J)
                    INSIDE(I) = INSIDE(J)
                    DISTANCE(J) = TEMP
                    INSIDE(J) = TEMPIN
                 ENDIF
25            CONTINUE
30            CONTINUE 
           
           OPEN(NOUTNM, FILE = OUTNAME)
           WRITE (NOUTNM,*) 'Atom indicies and distances:'  
           WRITE (NOUTNM,600) (INSIDE(I), DISTANCE(I), I = 1, COUNT)
           CLOSE(NOUTNM)

           OPEN(LATNUM, FILE = LATNAME)
           DO 40 I = 1, COUNT
              WRITE(LATNUM,500)X(INSIDE(I)),Y(INSIDE(I)),Z(INSIDE(I)) 
40         CONTINUE
           CLOSE(LATNUM)
        ENDIF 


C
C  Create neighbor data file by finding #X (specified by MAXNM) nearest  
C  neighbors to each of the #Y (specified by MMOVE) moving lattice atoms
C  and storing their indicies into array NEIGHBOR(#X,#Y) transferrable to
C  data file.  Also write the indicies of #Z (specified by MAXNA) nearest
C  neighbors to the origin specified by the sorting of the lattice (by
C  definition, these indicies are 1, 2, 3, ..., MAXNA).
C
        IF (IFLAG .EQ. 3) THEN
           WRITE(*,*)'Input the limiting radius around the atoms'
           READ (*,*) RADIUS
           OPEN(NEINUM, FILE = NEINAME)
           REWIND(NEINUM)
           OPEN(LATNUM, FILE = LATNAME) 
           REWIND(LATNUM)
           WRITE(NEINUM,620) MAXNM, MAXNA
           DO 50 I = 1, IBOUND 
              READ(LATNUM,500, END=55)X(I),Y(I),Z(I)
50         CONTINUE
           GOTO 57
55         IBOUND = I-1
57         CLOSE(LATNUM)
           DO 70 I = 1, MAXNM
              COUNT = 0
              DO 60 J = I, IBOUND
                 D1 = GETDIST(X(I), Y(I), Z(I), J)
                 IF (D1 .LE. RADIUS .AND. D1 .GT. 0.1) THEN
                    COUNT = COUNT + 1
                    NEIGHBOR(COUNT, I) = J
                 ENDIF
60            CONTINUE
70         CONTINUE
           IF (MMOVE .GT. 0) THEN
              DO 80 I = 1, MAXNM
                 WRITE(NEINUM,620)(NEIGHBOR(I,J), J = 1, MMOVE)
80            CONTINUE              
           ENDIF
           WRITE (NEINUM,610)(I,I = 1, MAXNA) 
           CLOSE (NEINUM)
        ENDIF           

C
C  Limit Lattice by taking existing lattice and limiting it to a sphere with
C  radius input by user and center(s) specified by XCNTR#, YCNTR#, and ZCNTR#.
C  Rewrite new limited lattice in place of old one.
C

        IF (IFLAG .EQ. 4) THEN
           OPEN (LATNUM, FILE = LATNAME)
           REWIND (LATNUM)  
           WRITE (*,*) 'Input the radius of the enclosing sphere'
           READ (*,*) RADIUS
           DO 120 I = 1, IBOUND
              READ (LATNUM, 500, END = 125) X(I), Y(I), Z(I)
120        CONTINUE
           GOTO 127
125        IBOUND = I - 1
127        CLOSE (LATNUM)
           COUNT = 0
           DO 130 I = 1, IBOUND
              D1 = GETDIST(XCNTR1, YCNTR1, ZCNTR1, I)
              D2 = GETDIST(XCNTR2, YCNTR2, ZCNTR2, I)
              IF (D2 .LT. D1) THEN
                 D1 = D2
              ENDIF
              IF (D1 .LE. RADIUS .AND. D1 .GT. 0.1) THEN
                 COUNT = COUNT + 1
                 DISTANCE(COUNT) = D1
                 X(COUNT) = X(I)
                 Y(COUNT) = Y(I)
                 Z(COUNT) = Z(I)
              ENDIF
130        CONTINUE
           OPEN (LATNUM, FILE = LATNAME) 
           REWIND (LATNUM)
           DO 140 I = 1, COUNT
              WRITE(LATNUM,500)X(I), Y(I), Z(I)    
140        CONTINUE 
           CLOSE (LATNUM)
           OPEN (NOUTNM, FILE = OUTNAME)
              WRITE (NOUTNM, *) 'Atom indicies and distances:'
              WRITE (NOUTNM, 600) (I, DISTANCE(I), I = 1, COUNT)
           CLOSE (NOUTNM)
        ENDIF       

C
C  Find energy of each atom in the lattice by passing each atom along with
C  the lattice to a separate potential energy FUNCTION POTENG which calculates
C  the potential exerted by the lattice on the particular atom.  INSIDE is an
C  array that contains the row (surface row = 1) that each atom is in.  ENERGY
C  is an array of length NLAYERS that contains the total energy of all the 
C  atoms being considered for averaging (those enclosed in a sphere of approx-
C  imate radius [NLAYERS * LATCON / 4]).  ECOUNT is an array of length NLAYERS
C  that contains the number of atoms in each row being considered for aver-
C  aging.  NOTE!  THIS OPTION REQUIRES A SORTED ARRAY TO WORK CORRECTLY!
C

	IF (IFLAG .EQ. 5) THEN
           OPEN (LATNUM, FILE = LATNAME)
           REWIND (LATNUM)
           DO 150 I = 1, IBOUND
              READ (LATNUM, 500, END = 155) X(I), Y(I), Z(I)
150        CONTINUE
           GOTO 157
155        IBOUND = I - 1  
157        DO 170 I = 1, IBOUND 
              E = POTENG (I, IBOUND)
              VPOT(I) = E
              DO 160 J = 1, NLAYERS 
                 IF (Z(I) .LT. ((1 - J) * LATCON / 2. + TOL)) THEN  
                    INSIDE(I) = J
                 ENDIF
160           CONTINUE
170        CONTINUE
           KFLAG = 0
           DO 180 I = 1, IBOUND
             IF (INSIDE(I) .LE. ((NLAYERS / 2) + 1) .AND. 
     1        KFLAG .EQ. 0) THEN
                ENERGY(INSIDE(I)) = ENERGY(INSIDE(I)) + VPOT(I)
                ECOUNT(INSIDE(I)) = ECOUNT(INSIDE(I)) + 1
             ELSE 
                KFLAG = 1
             ENDIF
180        CONTINUE
           OPEN (NOUTNM, FILE = OUTNAME)
              WRITE (NOUTNM, *) 'Atom indicies and energies:'
              WRITE (NOUTNM, *) '(in atomic units)'
              WRITE (NOUTNM, 605) (I, VPOT(I), I = 1, IBOUND)
              WRITE (NOUTNM, *) 'Average energy of atoms in each row'
              WRITE (NOUTNM, *) '  ROW   AVG ENERGY'
              WRITE (NOUTNM, 615) (I, (ENERGY(I) / ECOUNT(I)),
     1                             I = 1, ((NLAYERS / 2) + 1)) 
           CLOSE (NOUTNM)
	ENDIF
 

	IF (IFLAG .EQ. 6) THEN
           WRITE (*,*) 'Input Optimized X, Y, Z coords separately:'
           READ (*,*) XC
           READ (*,*) YC
           READ (*,*) ZC
           OPEN (LATNUM, FILE = LATNAME)
           REWIND (LATNUM)
           DO 195 I = 1, IBOUND
              READ (LATNUM, 500, END = 200) X(I), Y(I), Z(I)
195        CONTINUE
           GOTO 205
200        IBOUND = I - 1
205        CLOSE(LATNUM)
           ETOT=0
              ETOT = POTENG2(XC,YC,ZC,IBOUND)
           WRITE (*,*) 'Total Energy (kcal/mol):  '
           WRITE (*,*) ETOT*627.51
	ENDIF


500	FORMAT (3F20.8) 
600     FORMAT (7(I5, F6.2))
605     FORMAT (4(I5, 1X, F12.7, 1X))
610     FORMAT (I4)
615     FORMAT (I4, 5X, F12.7)
620     FORMAT (100I4)
700     FORMAT (6(I5, I2, 5X))
1000	END
 

        FUNCTION GETDIST(XC, YC, ZC, I)
        IMPLICIT DOUBLE PRECISION (A-H,O-Z)
        INCLUDE 'SIZES'
        COMMON /COORDS/ X(NCUBE), Y(NCUBE), Z(NCUBE)

C
C   Find the distance between two points
C
        DX = XC - X(I)
        DY = YC - Y(I)
        DZ = ZC - Z(I)
        GETDIST = SQRT(DX*DX + DY*DY + DZ*DZ)
        RETURN
        END
 

	FUNCTION POTENG(I, IBOUND) 
        IMPLICIT DOUBLE PRECISION (A-H,O-Z)
        INCLUDE 'SIZES'
C        REAL ALP, RE, D, RC, DC, C3, C4, C5, TEMP
	COMMON /COORDS/ X(NCUBE), Y(NCUBE), Z(NCUBE)

C
C       Calculate Cu-Cu potential for atom #I in lattice LATNAME using the
C       Morse spline function used by T.N. Truong and D.G. Truhlar in Journal
C       of Physical Chemisrty, 1987, (91), p6229.  ALP, RE, & D are Morse 
C       parameters.  RC is a cutoff.  DC defines the spline range.  C# are 
C       quintic spline paramters.
C
        ALP = 2.2863D0 * 0.5291771D0
        RE = 2.57956D0 / 0.5291771D0 
        D = 4750.D0 * 3.16678D-6 
        RC = 2.D0 * RE 
        DC = 0.1D0
        C3 = 1.054546477734848D-1
        C4 = 7.777013968646125D-1 
        C5 = 1.543041983755434D0 
        POTENG = 0.D0
	DO 50 J = 1, IBOUND
           IF (I .NE. J) THEN
              D1 = GETDIST(X(J), Y(J), Z(J), I)
 	      IF (D1 .LE. (RC - DC)) THEN
                 TEMP = (1.D0 - EXP(-ALP * (D1 - RE)))**2
                 POTENG = POTENG + (D * (TEMP - 1.D0))
              ELSE IF (D1 .LE. (RC + DC)) THEN
                 TEMP = (D1 - RC - DC)
                 TEMP = ((C5 * TEMP + C4) * TEMP + C3) * (TEMP**3)
                 POTENG = POTENG + TEMP
              ENDIF
           ENDIF
50      CONTINUE
	RETURN
	END



	FUNCTION POTENG2(XC,YC,ZC, IBOUND) 
        IMPLICIT DOUBLE PRECISION (A-H,O-Z)
        INCLUDE 'SIZES'
C        REAL ALP, RE, D, RC, DC, C3, C4, C5, TEMP
        INTEGER INSIDE(NCUBE)
	COMMON /COORDS/ X(NCUBE), Y(NCUBE), Z(NCUBE)

C
C       Calculate H-Cu potential for atom #I in lattice LATNAME using the
C       Morse spline function used by T.N. Truong and D.G. Truhlar in Journal
C       of Physical Chemisrty, 1987, (91), p6229.  ALP, RE, & D are Morse 
C       parameters.  RC is a cutoff.  DC defines the spline range.  C# are 
C       quintic spline paramters.
C
        ALP = 1.430D0 * 0.5291771D0
        RE = 2.34D0 / 0.5291771D0 
        D = 3667.2D0 * 3.16678D-6 
        RC = 3.D0 * RE 
        DC = 0.1D0
        C3 = 3.6510655D-2
        C4 = 2.710056D-1 
        C5 = 5.392978D-1
        POTENG2 = 0.D0
        COUNT = 0
        WRITE (*,*) 'Atoms inside spline:'
	DO 50 J = 1, IBOUND
           D1 = GETDIST(XC,YC,ZC,J)
 	   IF (D1 .LE. (RC - DC)) THEN
              TEMP = (1.D0 - EXP(-ALP * (D1 - RE)))**2
              POTENG2 = POTENG2 + (D * (TEMP - 1.D0))
              COUNT = COUNT + 1
              INSIDE (INT(COUNT)) = J
           ELSE IF (D1 .LE. (RC + DC)) THEN
              TEMP = (D1 - RC - DC)
              TEMP = ((C5 * TEMP + C4) * TEMP + C3) * (TEMP**3)
              POTENG2 = POTENG2 + TEMP
              COUNT = COUNT + 1
              INSIDE (INT(COUNT)) = J
              WRITE(*,*) J
           ENDIF
50      CONTINUE
        WRITE (*,*) 'Atoms inside cutoff:'
        WRITE (*,100) (INSIDE(I),I=1,COUNT)   
	RETURN
100     FORMAT (15I4)
	END


