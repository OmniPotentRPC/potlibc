c     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
c     Preliminary subroutine.  Call 'prepot' once before any call 
c     of 'pot'.
      subroutine prepot
      use falcons_vars_eval
      use falcons_vars_main
      implicit none
      call readpes
      end subroutine prepot

c     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
c     !!! NOTE:
c     !!! The following subroutines are modified from versions in the
c     !!! full FALCONS program.
c     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

c     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
c     FALCONS: Fitting Algorithm for the Local Construction Of 
c     eNergy Surfaces
c     Jason Bender, University of Minnesota, bende194@umn.edu
c     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

c     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
c     Reads the pes.dat file. 
c     This defines the arrays 'qi', 'aji', and 'crc'.
c     At the conclusion of this subroutine, those arrays only contain
c     data corresponding to unmasked points in the pes.dat file:
c     - n is the number of unmasked points
c     - nma is the number of masked points
c     - nall is the total number of points, with nall= n+ nma
      subroutine readpes
      use falcons_vars_eval
      use falcons_vars_main
      implicit none
      logical :: ex
      integer :: oridval,maskval
      integer, parameter :: fid=200
c     First define 'cmap' and 'qp'.  (Note that, in the main FALCONS
c     program, these were defined in the 'readinput', not the
c     'readpes' subroutine.)
c     Define the coordinate map used in the conversion from dedqr to
c     dedy. The array cmap defines a relationship between the 'b'
c     and 'a' indices in our convention: the row cmap(b,:) contains
c     three integers, which are the a-indices of the coordinates qr_a
c     such that d(qr_a)/d(y_bc) is nonzero.  See the 
c     'evaluatesurface' subroutine for more information.
      cmap(1,:)= (/1,2,3/)
      cmap(2,:)= (/1,4,5/)
      cmap(3,:)= (/2,4,6/)
      cmap(4,:)= (/3,5,6/)
c     A4 permutational symmetry.
      qps= 24
      qp(1 ,:)= (/1,2,3,4,5,6/)
      qp(2 ,:)= (/1,3,2,5,4,6/)
      qp(3 ,:)= (/2,1,3,4,6,5/)
      qp(4 ,:)= (/2,3,1,6,4,5/)
      qp(5 ,:)= (/3,1,2,5,6,4/)
      qp(6 ,:)= (/3,2,1,6,5,4/)
      qp(7 ,:)= (/1,4,5,2,3,6/)
      qp(8 ,:)= (/1,5,4,3,2,6/)
      qp(9 ,:)= (/4,1,5,2,6,3/)
      qp(10,:)= (/4,5,1,6,2,3/)
      qp(11,:)= (/5,1,4,3,6,2/)
      qp(12,:)= (/5,4,1,6,3,2/)
      qp(13,:)= (/2,4,6,1,3,5/)
      qp(14,:)= (/2,6,4,3,1,5/)
      qp(15,:)= (/4,2,6,1,5,3/)
      qp(16,:)= (/4,6,2,5,1,3/)
      qp(17,:)= (/6,2,4,3,5,1/)
      qp(18,:)= (/6,4,2,5,3,1/)
      qp(19,:)= (/3,5,6,1,2,4/)
      qp(20,:)= (/3,6,5,2,1,4/)
      qp(21,:)= (/5,3,6,1,4,2/)
      qp(22,:)= (/5,6,3,4,1,2/)
      qp(23,:)= (/6,3,5,2,4,1/)
      qp(24,:)= (/6,5,3,4,2,1/)
c     Set 'ps'. Note: originally this was read from input.dat, but
c     we eventually removed that option.  'ps' does not appear to 
c     have a dramatic affect on fitting quality.
      ps= 4d0
c     Next read the pes.dat file.
      write(*,'(a)') 
     & 'Reading potential energy surface data from pes.dat ...'
      inquire(file='pes.dat',exist=ex)
      if (.not. ex) then
       write(*,'(a)') 'ERROR: No pes.dat file found.'
       stop
      end if
c     Read the parameter information from the first several lines of
c     the file.
      open(fid,file='pes.dat',action='read')
      read(fid,*)
      read(fid,*)
      read(fid,*)
      read(fid,*)
      read(fid,*)
c     Skip over the header lines
      do i=1,20
       read(fid,*)
      end do
c     End of header lines
      read(fid,*)
      read(fid,*)
      read(fid,*)
      read(fid,*) moltype,pesform
      read(fid,*)
      read(fid,*) n,m,eta
      read(fid,*)
      read(fid,*) pnu,epsnu
      read(fid,*)
      read(fid,*) (aa(l),l=1,6)
      read(fid,*)
      read(fid,*) (qeq(l),l=1,6)
      read(fid,*)
      read(fid,*)
      read(fid,*)
      read(fid,*) nma,nplmax
      read(fid,*)
      call readcrcparameters(fid)
      read(fid,*)
      write(*,'(a,i10,a)') ' PES uses ',n,' unmasked data points.'
c     Read the data points.
      nall= n+nma
      allocate(qi(n,6),aji(n,m))
      read(fid,*)
      read(fid,*)
      j= 0
      if (pesform== 1) then
c      Use default coordinate system format
       do i=1,nall
        read(fid,*) oridval,e,(t(l),l=1,6),maskval
        if (maskval== 0) then
         j= j+1
         call default2cartesian(
     &    t(1),t(2),t(3),t(4),t(5),t(6),y)
         call cartesian2rawdist(y,qr)
         call rawdist2rawmorse(qr,qi(j,:),qeq,aa)
        end if
       end do
      else
       write(*,'(a)') 
     &  'ERROR: pesform /= 1 is not supported in this code.'
       stop
      end if
      if (j /= n) then
       write(*,'(a)') 'ERROR: Bad pes.dat file.'//
     & ' Inconsistent number of unmasked points.'
       stop
      end if
c     Read the polynomial coefficients aji.
      read(fid,*)
      do i= 1,n
       do j= 1,m
        read(fid,*) aji(i,j)
       end do
      end do
      close(fid)
      write(*,'(a)') ' Done.'
      write(*,'(a)')
      end subroutine readpes

c     !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
c     Reads the key information about a cutoff radius correlation
c     (CRC).  This includes allocating the appropriate size of the
c     crc vector.  This subroutine is called, for example, by the
c     subroutines 'readcrc' and 'readpes'.
      subroutine readcrcparameters(fid)
      use falcons_vars_eval
      use falcons_vars_main
      implicit none
      integer :: fid
      read(fid,*)
      read(fid,*)
      read(fid,*) nmincrc,mcrc
      if (allocated(crc)) then
c      Clear the crc vector, if it was already defined earlier. This
c      was added as a safety check, when conducting multiple tests
c      in succession.
       deallocate(crc)
      end if
      allocate(crc(mcrc))
      read(fid,*)
      read(fid,*) (crc(l),l=1,mcrc)
      read(fid,*)
      read(fid,*) ntarmin,ntarmax,ntar,crcmult,nitcrc,rwfa,rwfb
      end subroutine readcrcparameters
