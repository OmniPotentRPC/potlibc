subroutine prepot ()
use bemsa
implicit none
integer :: i
integer, parameter:: dp=kind(0.d0)                   ! double precision
real(dp) :: xyz(5,3)
real(dp) :: v
real(dp) :: a1,a2
real(dp) :: coeff(1376)
real(dp) :: x(10)
integer ::  ncall
data ncall/1/
save ncall, coeff, a1, a2

a1 = 2.0_dp
a2 = 2.5_dp

open (10,FILE='coeff_HOCO-Ar_under1.5_12432_C.dat')

!a1=3.3609107575013510_dp
!a2=1.9251839808848890_dp

if(ncall.eq.1) then

do i = 1, 1376

  read (10,*) coeff (i)

enddo

  return
end if

close (10)

entry pot(xyz,v)

    x(1)=sqrt((xyz(1,1)-xyz(2,1))**2+(xyz(1,2)-xyz(2,2))**2+(xyz(1,3)-xyz(2,3))**2)
    x(2)=sqrt((xyz(1,1)-xyz(3,1))**2+(xyz(1,2)-xyz(3,2))**2+(xyz(1,3)-xyz(3,3))**2)
    x(3)=sqrt((xyz(1,1)-xyz(4,1))**2+(xyz(1,2)-xyz(4,2))**2+(xyz(1,3)-xyz(4,3))**2)
    x(4)=sqrt((xyz(1,1)-xyz(5,1))**2+(xyz(1,2)-xyz(5,2))**2+(xyz(1,3)-xyz(5,3))**2)
    x(5)=sqrt((xyz(2,1)-xyz(3,1))**2+(xyz(2,2)-xyz(3,2))**2+(xyz(2,3)-xyz(3,3))**2)
    x(6)=sqrt((xyz(2,1)-xyz(4,1))**2+(xyz(2,2)-xyz(4,2))**2+(xyz(2,3)-xyz(4,3))**2)
    x(7)=sqrt((xyz(2,1)-xyz(5,1))**2+(xyz(2,2)-xyz(5,2))**2+(xyz(2,3)-xyz(5,3))**2)
    x(8)=sqrt((xyz(3,1)-xyz(4,1))**2+(xyz(3,2)-xyz(4,2))**2+(xyz(3,3)-xyz(4,3))**2)
    x(9)=sqrt((xyz(3,1)-xyz(5,1))**2+(xyz(3,2)-xyz(5,2))**2+(xyz(3,3)-xyz(5,3))**2)
    x(10)=sqrt((xyz(4,1)-xyz(5,1))**2+(xyz(4,2)-xyz(5,2))**2+(xyz(4,3)-xyz(5,3))**2)

      x(1)=x(1)/0.5291772083_dp
      x(1)=exp(-x(1)/a1)
      x(2)=x(2)/0.5291772083_dp
      x(2)=exp(-x(2)/a1)
      x(3)=x(3)/0.5291772083_dp
      x(3)=exp(-x(3)/a1)
      x(4)=x(4)/0.5291772083_dp
      x(4)=exp(-x(4)/a2)
      x(5)=x(5)/0.5291772083_dp
      x(5)=exp(-x(5)/a1)
      x(6)=x(6)/0.5291772083_dp
      x(6)=exp(-x(6)/a1)
      x(7)=x(7)/0.5291772083_dp
      x(7)=exp(-x(7)/a2)
      x(8)=x(8)/0.5291772083_dp
      x(8)=exp(-x(8)/a1)
      x(9)=x(9)/0.5291772083_dp
      x(9)=exp(-x(9)/a2)
      x(10)=x(10)/0.5291772083_dp
      x(10)=exp(-x(10)/a2)

    v=emsav(x,coeff)
end  subroutine
