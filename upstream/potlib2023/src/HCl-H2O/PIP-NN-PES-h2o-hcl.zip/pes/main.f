      program main
      implicit none
      integer ndata,ndata2,i,j,k,natom
      real*8 xt2(1:3,1:5)
      real*8 v0,v1,v,vp,rmse,delta,delta2
      character*10 symb

      rmse=0d0
      ndata=1
      v0=-536.734975058642d0-0.000000006271d0

      call pes_init
      open(98,file='test-h2ohcl.txt')
      rewind(98)

      do i=1,ndata
       read(98,*)natom
       read(98,*)v
       do k=1,natom
        read(98,*)symb,xt2(:,k)
       enddo

       call evvdvdx(xt2,vp)
       v=(v-v0)*27.2114d0  !--->to eV 
       delta=v-vp
       rmse=rmse+delta**2
      enddo

      rmse=dsqrt(rmse/ndata)

      write(*,*) 'rmse=',rmse
      write(*,*) 'done*****'

      close(98)
      end program main
