        include "c2h2o_pes.f"

        program main
        implicit none
        integer :: n 
        character*2 :: atom(5)
        character*4 :: geom
        double precision :: q(3,5),vpes,vpes_kcal
        double precision :: vab,deltaV,v_r
        double precision,parameter :: Veq=-152.3326252d0 ! H2CCO(3A") in hartree

        call pes_init

        n=0 
        open(51,file='test.xyz',status='old')
        open(61,file='test.txt',status='replace')

        write(61,'(5H=====,20H ===================,20H =================
     $==,20H ===================,20H ===================)')
        write(61,'(A5,4A20)')'Geom','Vab/eV','Vpes/eV','Vpes_rel/kcal
     $*mol-1','deltaV/kcal*mol-1'
        write(61,'(5H=====,20H ===================,20H =================
     $==,20H ===================,20H ===================)')

        do while(.true.)
           read(51,*,end=100) geom
           read(51,*)vab ! eV
           read(51,*)atom(1),q(:,1) !--> O
           read(51,*)atom(2),q(:,2) !--> C
           read(51,*)atom(3),q(:,3) !--> C
           read(51,*)atom(4),q(:,4) !--> H
           read(51,*)atom(5),q(:,5) !--> H
! vpes is energy relatived to H2CCO(3A") in eV.
           call c2h2o_pes_interface(q,vpes)
! energy related to reactant asymptote in kcal/mol.
           n=n+1 
           if (n.eq.1) then
              v_r=vpes
           endif
           vpes_kcal=(vpes-v_r)*23.0605d0 ! eV to kcal/mol
           vab=(vab-Veq)*27.21138d0
           deltaV=abs(vpes-vab)*23.0605d0 ! eV to kcal/mol
           write(61,'(A5,4f20.8)')geom,vab,vpes,vpes_kcal,deltaV
        enddo
100     continue
        write(61,'(5H=====,20H ===================,20H =================
     $==,20H ===================,20H ===================)')
        close(51)
        close(61)

        end program main
