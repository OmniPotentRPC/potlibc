!********************************************************************** 
!   System:                     C2H2O
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                C2H2O
!   Number of derivatives:      0
!   Number of bodies:           5
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: J. Zuo, Q. Chen, X. Hu, H. Guo, and  D. Xie "Dissection
!   of the multichannel reaction of acetylene with atomic oxygen: from
!   the global potential energy surface to rate coefficients and
!   branching dynamics"
!   Phys. Chem. Chem. Phys. 2019, 21, 1408-1416.
!
!   Notes: see below
!
!**********************************************************************

****************************************************************************
* PIP-NN PES for ground triplet state OC2H2 system at UCCSD(T)-F12b/VTZ-F12
  level.
* Reference: Phys. Chem. Chem. Phys. 2019, 21 (3), 1408-1416.
****************************************************************************
                            
These files are for the PES of O+C2H2 reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: c2h2o_pes.f

To use this PES, as shown in the test.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call c2h2o_pes_interface(q,vpes)
     where,
       q:    XYZ cartesian coordinate in OCCHH order and angstrom unit.
       vpes: the potential in eV.
