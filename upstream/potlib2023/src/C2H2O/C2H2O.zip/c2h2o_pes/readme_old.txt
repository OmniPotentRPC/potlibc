****************************************************************************
* PIP-NN PES for ground triplet state OC2H2 system at UCCSD(T)-F12b/VTZ-F12
  level.
* Reference: Phys. Chem. Chem. Phys. 2019, 21 (3), 1408-1416.
****************************************************************************
                            
These files are for the PES of O+C2H2 reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: c2h2o_pes.f

To use this PES, as shown in the test.f, please be sure to do:
  1. Initialization:
       call pes_init 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call c2h2o_pes_interface(q,vpes)
     where,
       q:    XYZ cartesian coordinate in OCCHH order and angstrom unit.
       vpes: the potential in eV.
