      program main
      implicit none
      real*8 c(3,4),vpes,vab,rmse,rch,rhcl,xvec(3,2)
      integer ndata,i,itmp,ns
      real*8 c2(3,4),rccl,rmses
      character*8 asymb
      
      call pes_init()

      ndata=3
      open(11,file='test.xyz',status='old')
      do i=1,ndata
       read(11,*)itmp
       read(11,*)vab
       vab=(vab+114.158373618668d0)*27.2114d0
       read(11,*)asymb,c(:,1)
       read(11,*)asymb,c(:,2)
       read(11,*)asymb,c(:,3)
       read(11,*)asymb,c(:,4)

       call ch2opipNN(c,vpes) 
       write(6,'(3f16.8)')vab,vpes,vpes-vab
      enddo

      end  
