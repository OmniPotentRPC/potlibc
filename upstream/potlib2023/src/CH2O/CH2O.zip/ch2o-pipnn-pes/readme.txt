!********************************************************************** 
!   System:                     CH2O
!   Functional form:            permutationally invariant polynomials-neural network
!   Common name:                CH2O
!   Number of derivatives:      0
!   Number of bodies:           4
!   Number of electronic surfaces: 1
!   Interface: Section-2
!**********************************************************************
!
!   References: 
!   “Kinetics and dynamics of the C(3P) + H2O reaction on a full-dimensional  
!   accurate triplet state potential energy surface”,
!   Jun Li*, Changjian Xie, and Hua Guo, 
!   Physical Chemistry Chemical Physics, 2017, 19, 23280-23288.
!
!   Notes: see below
!
!**********************************************************************

****************************************************************************
* PIP-NN PES for C + H2O system at CCSD(T)-F12a/AVTZ level.
* Reference: Physical Chemistry Chemical Physics, 2017, 19, 23280-23288.
****************************************************************************
                            
These files are for the PES of C + H2O reaction, including
  1. Parameter files: biases*.txt, weights*.txt
  2. Main fortran file containing subroutines: ch2o-pipnn.f

To use this PES, as shown in the main.f, please be sure to do:
  1. Initialization:
       call pes_init() 
     Note: call once and only once in the main code.
  2. Calculate potential energy:
       call ch2opipNN(c,vpes)
     where,
       c: XYZ cartesian coordinate in HHCO order and angstrom unit, shown in test.xyz
       vpes:  the potential energy(in eV) relative to the reactant asymptote.
